var group__cofpeerstatuslistener =
[
    [ "Peer Status Codes", "group__cpeerstatus.html", "group__cpeerstatus" ],
    [ "Connection Pool Health Status Codes", "group__cpoolhealth.html", "group__cpoolhealth" ],
    [ "ofpeerstatus_health_p", "group__cofpeerstatuslistener.html#ga7eca073903dc68f7e84116471e5594fc", null ],
    [ "ofpeerstatus_peer_p", "group__cofpeerstatuslistener.html#gaa8598c7630f2fbeb322d98ae4f30765d", null ],
    [ "ofpeerstatuslistener_p", "group__cofpeerstatuslistener.html#ga15eae0d545a149cbfd2e3efdc2f15158", null ],
    [ "ofpeerstatuslistener_create", "group__cofpeerstatuslistener.html#ga6a937aa46db8cefe370bed90b013207e", null ],
    [ "ofpeerstatuslistener_destroy", "group__cofpeerstatuslistener.html#ga7e9504c6cee99ae1ae71f588e5b86a84", null ]
];