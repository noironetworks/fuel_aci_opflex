var group__cofframework =
[
    [ "offramework_p", "group__cofframework.html#ga41041246cebc7eb4f42fca52ea492642", null ],
    [ "ofpeerstatuslistener_p", "group__cofframework.html#ga15eae0d545a149cbfd2e3efdc2f15158", null ],
    [ "offramework_add_peer", "group__cofframework.html#gad09e1dfc0e3351e6eac1431e2fc27301", null ],
    [ "offramework_create", "group__cofframework.html#ga12d18f00b223f8de2e54400b6a2a353a", null ],
    [ "offramework_destroy", "group__cofframework.html#ga481bf68e399326102bb79560474e9fa1", null ],
    [ "offramework_register_peerstatuslistener", "group__cofframework.html#ga8c2602b8d0cbe1b76b2a3396047241d2", null ],
    [ "offramework_set_model", "group__cofframework.html#ga755cc9a1350b7fcaf3a72f3876c8b013", null ],
    [ "offramework_set_opflex_identity", "group__cofframework.html#ga2273f33f7b304f9dbb6916fa70d19e6d", null ],
    [ "offramework_start", "group__cofframework.html#ga989eccbcc61bdc76838c864c3a966b05", null ],
    [ "offramework_stop", "group__cofframework.html#ga836adda6f9a3be7bc5a159db309f9bcc", null ]
];