var classopflex_1_1modb_1_1ModelMetadata =
[
    [ "ModelMetadata", "classopflex_1_1modb_1_1ModelMetadata.html#a1d614d95ddd3dca560a7e9b5d22f1f80", null ],
    [ "~ModelMetadata", "classopflex_1_1modb_1_1ModelMetadata.html#a7d7f0fedfd849803da7976b8fd34e8b7", null ],
    [ "getClasses", "classopflex_1_1modb_1_1ModelMetadata.html#aecc5ae7a1d9366234bb367523a539dd5", null ],
    [ "getName", "classopflex_1_1modb_1_1ModelMetadata.html#a6f37e1a1511ce6f5e7d0dd24388f8e5d", null ]
];