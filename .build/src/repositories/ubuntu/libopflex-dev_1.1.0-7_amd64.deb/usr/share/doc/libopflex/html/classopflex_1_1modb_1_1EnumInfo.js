var classopflex_1_1modb_1_1EnumInfo =
[
    [ "EnumInfo", "classopflex_1_1modb_1_1EnumInfo.html#a2b808affd3324ec90296157ecb4a2c56", null ],
    [ "EnumInfo", "classopflex_1_1modb_1_1EnumInfo.html#ae436330aaca7d045b21a201fce54990e", null ],
    [ "~EnumInfo", "classopflex_1_1modb_1_1EnumInfo.html#a2c4015c4bddb50dbfb73c75ec7d489a5", null ],
    [ "getConsts", "classopflex_1_1modb_1_1EnumInfo.html#ada55025ab2e870f00ac36e2df02f3491", null ],
    [ "getIdByName", "classopflex_1_1modb_1_1EnumInfo.html#a77b6558ac06cf937effc151747e38dc8", null ],
    [ "getName", "classopflex_1_1modb_1_1EnumInfo.html#a7e4b2e4717fa6fbaae85485a2146cf77", null ],
    [ "getNameById", "classopflex_1_1modb_1_1EnumInfo.html#aca425dc233390bd776c1b6d882ad8f3b", null ]
];