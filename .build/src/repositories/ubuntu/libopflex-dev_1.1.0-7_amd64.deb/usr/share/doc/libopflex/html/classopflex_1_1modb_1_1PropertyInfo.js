var classopflex_1_1modb_1_1PropertyInfo =
[
    [ "cardinality_t", "classopflex_1_1modb_1_1PropertyInfo.html#ab3190c2483db718c1dcb3722f689e850", [
      [ "SCALAR", "classopflex_1_1modb_1_1PropertyInfo.html#ab3190c2483db718c1dcb3722f689e850adf866c24651a17f8e061f7726ec58e32", null ],
      [ "VECTOR", "classopflex_1_1modb_1_1PropertyInfo.html#ab3190c2483db718c1dcb3722f689e850a6727ff2e4513e9f651937845236d41e9", null ]
    ] ],
    [ "property_type_t", "classopflex_1_1modb_1_1PropertyInfo.html#a5b5adc48d929341f599b63916e7c9402", [
      [ "COMPOSITE", "classopflex_1_1modb_1_1PropertyInfo.html#a5b5adc48d929341f599b63916e7c9402adfdf8d4974bccf5fbb9c02fda10dd4cf", null ],
      [ "REFERENCE", "classopflex_1_1modb_1_1PropertyInfo.html#a5b5adc48d929341f599b63916e7c9402a32a15577cfd9856bb295ae72ee8be34e", null ],
      [ "STRING", "classopflex_1_1modb_1_1PropertyInfo.html#a5b5adc48d929341f599b63916e7c9402a35e2b9a40d7b569ebfe5e9ca0a2e2f98", null ],
      [ "S64", "classopflex_1_1modb_1_1PropertyInfo.html#a5b5adc48d929341f599b63916e7c9402a5f20fa752928d1c68a3e8fc61542b414", null ],
      [ "U64", "classopflex_1_1modb_1_1PropertyInfo.html#a5b5adc48d929341f599b63916e7c9402a9e6efabf8b6d0632baab125fac6169af", null ],
      [ "MAC", "classopflex_1_1modb_1_1PropertyInfo.html#a5b5adc48d929341f599b63916e7c9402a6300128057217552e69293cab76ea187", null ],
      [ "ENUM8", "classopflex_1_1modb_1_1PropertyInfo.html#a5b5adc48d929341f599b63916e7c9402a04560f140926acc80dd58993abf506e5", null ],
      [ "ENUM16", "classopflex_1_1modb_1_1PropertyInfo.html#a5b5adc48d929341f599b63916e7c9402a724f8a5f5fb6a2f527e329e477598d87", null ],
      [ "ENUM32", "classopflex_1_1modb_1_1PropertyInfo.html#a5b5adc48d929341f599b63916e7c9402a87e22ab30fbe83caa6e4da95266ca855", null ],
      [ "ENUM64", "classopflex_1_1modb_1_1PropertyInfo.html#a5b5adc48d929341f599b63916e7c9402a80209a23459cc2d0c91759977e938741", null ]
    ] ],
    [ "PropertyInfo", "classopflex_1_1modb_1_1PropertyInfo.html#a4c92250ddedf8307c862a00e40198a79", null ],
    [ "PropertyInfo", "classopflex_1_1modb_1_1PropertyInfo.html#a03751dba838c50cd81507765a7c05a0a", null ],
    [ "PropertyInfo", "classopflex_1_1modb_1_1PropertyInfo.html#a10899931dba752f73c9c254044ce2935", null ],
    [ "PropertyInfo", "classopflex_1_1modb_1_1PropertyInfo.html#aae14a9405e14cdbba9f450788eefd1c4", null ],
    [ "~PropertyInfo", "classopflex_1_1modb_1_1PropertyInfo.html#a068bf12baea2fb924241b0a1f4296a96", null ],
    [ "getCardinality", "classopflex_1_1modb_1_1PropertyInfo.html#aa58f55500c3c0fa5f53fa126dab35fc9", null ],
    [ "getClassId", "classopflex_1_1modb_1_1PropertyInfo.html#a8332a8f7e5fc8f17164e7a921210e5ff", null ],
    [ "getEnumInfo", "classopflex_1_1modb_1_1PropertyInfo.html#adf636dfd0d6619f6545365858ff4ceef", null ],
    [ "getId", "classopflex_1_1modb_1_1PropertyInfo.html#a03da955a1ae8756f5f4b4cb4dfcd874d", null ],
    [ "getName", "classopflex_1_1modb_1_1PropertyInfo.html#ae0b15858e4f513b437f1e1d6c4fa1b74", null ],
    [ "getType", "classopflex_1_1modb_1_1PropertyInfo.html#a817d91eeafcbbb4e890af3a82303c236", null ]
];