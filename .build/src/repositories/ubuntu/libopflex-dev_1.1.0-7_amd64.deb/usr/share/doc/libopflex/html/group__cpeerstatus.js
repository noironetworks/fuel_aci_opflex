var group__cpeerstatus =
[
    [ "OF_PEERSTATUS_CLOSING", "group__cpeerstatus.html#ga95eb94670df6e1c85424b9c8e993fee0", null ],
    [ "OF_PEERSTATUS_CONNECTED", "group__cpeerstatus.html#gaf1429d8f0e491016ae33bd251fe37f73", null ],
    [ "OF_PEERSTATUS_CONNECTING", "group__cpeerstatus.html#ga2c97db0cb5eb3a41b4f48fa264d87bd8", null ],
    [ "OF_PEERSTATUS_DISCONNECTED", "group__cpeerstatus.html#gaa4efd85bb79d30163356bbdef5d5416d", null ],
    [ "OF_PEERSTATUS_ERROR", "group__cpeerstatus.html#ga4aaf0ba13304ea3db8ac55bca7256d00", null ],
    [ "OF_PEERSTATUS_READY", "group__cpeerstatus.html#gaad520485b5838ffaad4544d3a9b7ec7f", null ]
];