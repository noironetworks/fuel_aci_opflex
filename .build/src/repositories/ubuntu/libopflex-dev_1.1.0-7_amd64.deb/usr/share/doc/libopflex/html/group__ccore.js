var group__ccore =
[
    [ "Definitions", "group__cdefs.html", "group__cdefs" ],
    [ "Opflex Framework Object", "group__cofframework.html", "group__cofframework" ],
    [ "Peer Status Listener", "group__cofpeerstatuslistener.html", "group__cofpeerstatuslistener" ]
];