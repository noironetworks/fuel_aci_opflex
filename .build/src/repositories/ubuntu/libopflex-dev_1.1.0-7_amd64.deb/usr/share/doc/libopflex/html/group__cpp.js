var group__cpp =
[
    [ "Logging", "group__logging.html", "group__logging" ],
    [ "Managed Objects", "group__modb.html", "group__modb" ],
    [ "Model Metadata", "group__metadata.html", "group__metadata" ],
    [ "Core", "group__ofcore.html", "group__ofcore" ]
];