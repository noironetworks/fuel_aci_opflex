var group__cofobjectlistener =
[
    [ "ofnotify_p", "group__cofobjectlistener.html#gac346f2c22bc9b52e1e5457dfab4f9433", null ],
    [ "ofobjectlistener_p", "group__cofobjectlistener.html#gae09dd7511b1a553373e8564d5beb573b", null ],
    [ "ofobjectlistener_create", "group__cofobjectlistener.html#ga9608f2fad7119c1a4f5b240d7cade689", null ],
    [ "ofobjectlistener_destroy", "group__cofobjectlistener.html#gaf27e3a4dd9fdb5b33933374caaf46ac1", null ]
];