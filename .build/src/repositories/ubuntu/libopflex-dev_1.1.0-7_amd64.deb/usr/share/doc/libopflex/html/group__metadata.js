var group__metadata =
[
    [ "ClassInfo", "classopflex_1_1modb_1_1ClassInfo.html", [
      [ "property_map_t", "classopflex_1_1modb_1_1ClassInfo.html#a99807edd2d816786bec2a534655f4bcd", null ],
      [ "class_type_t", "classopflex_1_1modb_1_1ClassInfo.html#a3d29abf148878257027a561a5635d256", [
        [ "POLICY", "classopflex_1_1modb_1_1ClassInfo.html#a3d29abf148878257027a561a5635d256a3ae75495e13c7624c93e51dbe87a9aee", null ],
        [ "REMOTE_ENDPOINT", "classopflex_1_1modb_1_1ClassInfo.html#a3d29abf148878257027a561a5635d256ae44f49aae9d66f95d712955e3fd3fa3b", null ],
        [ "LOCAL_ENDPOINT", "classopflex_1_1modb_1_1ClassInfo.html#a3d29abf148878257027a561a5635d256aea44d99f7c5540e8d149aa9330d4e29c", null ],
        [ "OBSERVABLE", "classopflex_1_1modb_1_1ClassInfo.html#a3d29abf148878257027a561a5635d256aba1da6f5c59497fd299f9208e7d30b08", null ],
        [ "LOCAL_ONLY", "classopflex_1_1modb_1_1ClassInfo.html#a3d29abf148878257027a561a5635d256aa4d88701a58fd30ae1d9be2b445f4b6d", null ],
        [ "RESOLVER", "classopflex_1_1modb_1_1ClassInfo.html#a3d29abf148878257027a561a5635d256a1813b2d5614d4a80a4ec5ed7f48752d5", null ],
        [ "RELATIONSHIP", "classopflex_1_1modb_1_1ClassInfo.html#a3d29abf148878257027a561a5635d256a71996a733154c3ae24bbaf7422cf27eb", null ],
        [ "REVERSE_RELATIONSHIP", "classopflex_1_1modb_1_1ClassInfo.html#a3d29abf148878257027a561a5635d256aef4461938be31c2fc84879793fe87249", null ]
      ] ],
      [ "ClassInfo", "classopflex_1_1modb_1_1ClassInfo.html#a380910dbdb53257d3aae6bc529c0a798", null ],
      [ "ClassInfo", "classopflex_1_1modb_1_1ClassInfo.html#a9a652ce1fc6b5805510f99913b762b7e", null ],
      [ "~ClassInfo", "classopflex_1_1modb_1_1ClassInfo.html#ab7278c55bfb013a98756c04438d4ac72", null ],
      [ "getId", "classopflex_1_1modb_1_1ClassInfo.html#a60c914bee3bffd6f4073eb24179032ee", null ],
      [ "getName", "classopflex_1_1modb_1_1ClassInfo.html#a7b88381d8517f4edbe8622341ab7147f", null ],
      [ "getNamingProps", "classopflex_1_1modb_1_1ClassInfo.html#ac77389530ad759f0044fa2cd86f26e0c", null ],
      [ "getOwner", "classopflex_1_1modb_1_1ClassInfo.html#a35b03952a203372918a16989b272310b", null ],
      [ "getProperties", "classopflex_1_1modb_1_1ClassInfo.html#ae9359f735a3019c435fccdb0857e16f2", null ],
      [ "getProperty", "classopflex_1_1modb_1_1ClassInfo.html#a987b0fe03ae13a5a9b2324b69848cab8", null ],
      [ "getProperty", "classopflex_1_1modb_1_1ClassInfo.html#a5cca258cc2faa7c39cd1ae499bb30ba6", null ],
      [ "getType", "classopflex_1_1modb_1_1ClassInfo.html#a43ad0a604e837bba7823ad3f61606563", null ]
    ] ],
    [ "ConstInfo", "classopflex_1_1modb_1_1ConstInfo.html", [
      [ "ConstInfo", "classopflex_1_1modb_1_1ConstInfo.html#a42774563ea9ebd1d063205c2fca834c6", null ],
      [ "~ConstInfo", "classopflex_1_1modb_1_1ConstInfo.html#a1ac69f8bc8c24e6d1e02e9211f70911b", null ],
      [ "getId", "classopflex_1_1modb_1_1ConstInfo.html#a7a0261ebbe307216c6bc759f43a516e1", null ],
      [ "getName", "classopflex_1_1modb_1_1ConstInfo.html#ac04d1773eb481e0c34037e9e12811ba3", null ]
    ] ],
    [ "EnumInfo", "classopflex_1_1modb_1_1EnumInfo.html", [
      [ "EnumInfo", "classopflex_1_1modb_1_1EnumInfo.html#a2b808affd3324ec90296157ecb4a2c56", null ],
      [ "EnumInfo", "classopflex_1_1modb_1_1EnumInfo.html#ae436330aaca7d045b21a201fce54990e", null ],
      [ "~EnumInfo", "classopflex_1_1modb_1_1EnumInfo.html#a2c4015c4bddb50dbfb73c75ec7d489a5", null ],
      [ "getConsts", "classopflex_1_1modb_1_1EnumInfo.html#ada55025ab2e870f00ac36e2df02f3491", null ],
      [ "getIdByName", "classopflex_1_1modb_1_1EnumInfo.html#a77b6558ac06cf937effc151747e38dc8", null ],
      [ "getName", "classopflex_1_1modb_1_1EnumInfo.html#a7e4b2e4717fa6fbaae85485a2146cf77", null ],
      [ "getNameById", "classopflex_1_1modb_1_1EnumInfo.html#aca425dc233390bd776c1b6d882ad8f3b", null ]
    ] ],
    [ "ModelMetadata", "classopflex_1_1modb_1_1ModelMetadata.html", [
      [ "ModelMetadata", "classopflex_1_1modb_1_1ModelMetadata.html#a1d614d95ddd3dca560a7e9b5d22f1f80", null ],
      [ "~ModelMetadata", "classopflex_1_1modb_1_1ModelMetadata.html#a7d7f0fedfd849803da7976b8fd34e8b7", null ],
      [ "getClasses", "classopflex_1_1modb_1_1ModelMetadata.html#aecc5ae7a1d9366234bb367523a539dd5", null ],
      [ "getName", "classopflex_1_1modb_1_1ModelMetadata.html#a6f37e1a1511ce6f5e7d0dd24388f8e5d", null ]
    ] ],
    [ "PropertyInfo", "classopflex_1_1modb_1_1PropertyInfo.html", [
      [ "cardinality_t", "classopflex_1_1modb_1_1PropertyInfo.html#ab3190c2483db718c1dcb3722f689e850", [
        [ "SCALAR", "classopflex_1_1modb_1_1PropertyInfo.html#ab3190c2483db718c1dcb3722f689e850adf866c24651a17f8e061f7726ec58e32", null ],
        [ "VECTOR", "classopflex_1_1modb_1_1PropertyInfo.html#ab3190c2483db718c1dcb3722f689e850a6727ff2e4513e9f651937845236d41e9", null ]
      ] ],
      [ "property_type_t", "classopflex_1_1modb_1_1PropertyInfo.html#a5b5adc48d929341f599b63916e7c9402", [
        [ "COMPOSITE", "classopflex_1_1modb_1_1PropertyInfo.html#a5b5adc48d929341f599b63916e7c9402adfdf8d4974bccf5fbb9c02fda10dd4cf", null ],
        [ "REFERENCE", "classopflex_1_1modb_1_1PropertyInfo.html#a5b5adc48d929341f599b63916e7c9402a32a15577cfd9856bb295ae72ee8be34e", null ],
        [ "STRING", "classopflex_1_1modb_1_1PropertyInfo.html#a5b5adc48d929341f599b63916e7c9402a35e2b9a40d7b569ebfe5e9ca0a2e2f98", null ],
        [ "S64", "classopflex_1_1modb_1_1PropertyInfo.html#a5b5adc48d929341f599b63916e7c9402a5f20fa752928d1c68a3e8fc61542b414", null ],
        [ "U64", "classopflex_1_1modb_1_1PropertyInfo.html#a5b5adc48d929341f599b63916e7c9402a9e6efabf8b6d0632baab125fac6169af", null ],
        [ "MAC", "classopflex_1_1modb_1_1PropertyInfo.html#a5b5adc48d929341f599b63916e7c9402a6300128057217552e69293cab76ea187", null ],
        [ "ENUM8", "classopflex_1_1modb_1_1PropertyInfo.html#a5b5adc48d929341f599b63916e7c9402a04560f140926acc80dd58993abf506e5", null ],
        [ "ENUM16", "classopflex_1_1modb_1_1PropertyInfo.html#a5b5adc48d929341f599b63916e7c9402a724f8a5f5fb6a2f527e329e477598d87", null ],
        [ "ENUM32", "classopflex_1_1modb_1_1PropertyInfo.html#a5b5adc48d929341f599b63916e7c9402a87e22ab30fbe83caa6e4da95266ca855", null ],
        [ "ENUM64", "classopflex_1_1modb_1_1PropertyInfo.html#a5b5adc48d929341f599b63916e7c9402a80209a23459cc2d0c91759977e938741", null ]
      ] ],
      [ "PropertyInfo", "classopflex_1_1modb_1_1PropertyInfo.html#a4c92250ddedf8307c862a00e40198a79", null ],
      [ "PropertyInfo", "classopflex_1_1modb_1_1PropertyInfo.html#a03751dba838c50cd81507765a7c05a0a", null ],
      [ "PropertyInfo", "classopflex_1_1modb_1_1PropertyInfo.html#a10899931dba752f73c9c254044ce2935", null ],
      [ "PropertyInfo", "classopflex_1_1modb_1_1PropertyInfo.html#aae14a9405e14cdbba9f450788eefd1c4", null ],
      [ "~PropertyInfo", "classopflex_1_1modb_1_1PropertyInfo.html#a068bf12baea2fb924241b0a1f4296a96", null ],
      [ "getCardinality", "classopflex_1_1modb_1_1PropertyInfo.html#aa58f55500c3c0fa5f53fa126dab35fc9", null ],
      [ "getClassId", "classopflex_1_1modb_1_1PropertyInfo.html#a8332a8f7e5fc8f17164e7a921210e5ff", null ],
      [ "getEnumInfo", "classopflex_1_1modb_1_1PropertyInfo.html#adf636dfd0d6619f6545365858ff4ceef", null ],
      [ "getId", "classopflex_1_1modb_1_1PropertyInfo.html#a03da955a1ae8756f5f4b4cb4dfcd874d", null ],
      [ "getName", "classopflex_1_1modb_1_1PropertyInfo.html#ae0b15858e4f513b437f1e1d6c4fa1b74", null ],
      [ "getType", "classopflex_1_1modb_1_1PropertyInfo.html#a817d91eeafcbbb4e890af3a82303c236", null ]
    ] ],
    [ "class_id_t", "group__metadata.html#ga45e2099e227bffc3f27e05802d66d806", null ],
    [ "prop_id_t", "group__metadata.html#ga3e101cfece1b15ec4732286822a10440", null ]
];