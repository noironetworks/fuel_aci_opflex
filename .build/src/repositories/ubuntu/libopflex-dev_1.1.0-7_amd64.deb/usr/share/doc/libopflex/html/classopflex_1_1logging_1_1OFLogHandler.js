var classopflex_1_1logging_1_1OFLogHandler =
[
    [ "Level", "classopflex_1_1logging_1_1OFLogHandler.html#a51e1a13de264f65ea8721e21b62753f3", [
      [ "TRACE", "classopflex_1_1logging_1_1OFLogHandler.html#a51e1a13de264f65ea8721e21b62753f3aefcd63efb4b8b3869cf151eb0d01a665", null ],
      [ "DEBUG7", "classopflex_1_1logging_1_1OFLogHandler.html#a51e1a13de264f65ea8721e21b62753f3a54c7396c2bb68a948ad669ad58de4bc3", null ],
      [ "DEBUG6", "classopflex_1_1logging_1_1OFLogHandler.html#a51e1a13de264f65ea8721e21b62753f3a01e7d77c5b37313323307d4520ea7425", null ],
      [ "DEBUG5", "classopflex_1_1logging_1_1OFLogHandler.html#a51e1a13de264f65ea8721e21b62753f3a6bdf00555a98398422c8c22bafbc81b1", null ],
      [ "DEBUG4", "classopflex_1_1logging_1_1OFLogHandler.html#a51e1a13de264f65ea8721e21b62753f3a4e038e86da61966475bcd465ff4aad51", null ],
      [ "DEBUG3", "classopflex_1_1logging_1_1OFLogHandler.html#a51e1a13de264f65ea8721e21b62753f3a70b0c5e98ed74133a5a463b275a6858a", null ],
      [ "DEBUG2", "classopflex_1_1logging_1_1OFLogHandler.html#a51e1a13de264f65ea8721e21b62753f3ab350e9096f1300fb3ab2cb9f92cca559", null ],
      [ "DEBUG1", "classopflex_1_1logging_1_1OFLogHandler.html#a51e1a13de264f65ea8721e21b62753f3a7765264c2facfb619748c3b73a549819", null ],
      [ "DEBUG0", "classopflex_1_1logging_1_1OFLogHandler.html#a51e1a13de264f65ea8721e21b62753f3a0920dc7fb3eff17453d63c8baff8dfce", null ],
      [ "INFO", "classopflex_1_1logging_1_1OFLogHandler.html#a51e1a13de264f65ea8721e21b62753f3ad6392e435f2c735c010da06d7ccf4546", null ],
      [ "WARNING", "classopflex_1_1logging_1_1OFLogHandler.html#a51e1a13de264f65ea8721e21b62753f3ab66f3587ce0f06447aa9c7ea40033544", null ],
      [ "ERROR", "classopflex_1_1logging_1_1OFLogHandler.html#a51e1a13de264f65ea8721e21b62753f3a4b1a45a33987311f2e7238e7b1f38699", null ],
      [ "FATAL", "classopflex_1_1logging_1_1OFLogHandler.html#a51e1a13de264f65ea8721e21b62753f3a0bad5316ff4676afad4f4e1587b89c29", null ],
      [ "NO_LOGGING", "classopflex_1_1logging_1_1OFLogHandler.html#a51e1a13de264f65ea8721e21b62753f3a9a23cae1639a1bbb729495850c6eb10c", null ]
    ] ],
    [ "OFLogHandler", "classopflex_1_1logging_1_1OFLogHandler.html#a1f31c310eadaba5810fee3e232e10517", null ],
    [ "~OFLogHandler", "classopflex_1_1logging_1_1OFLogHandler.html#a1a662b9e5e9a60903ba362738632a472", null ],
    [ "handleMessage", "classopflex_1_1logging_1_1OFLogHandler.html#ab6d66d5b909480c85cfac06bf2a77267", null ],
    [ "shouldEmit", "classopflex_1_1logging_1_1OFLogHandler.html#ad4ad96dcb97cebf82232fc3425a85ae4", null ],
    [ "logLevel_", "classopflex_1_1logging_1_1OFLogHandler.html#a8e99c3c842d65d8f6675930b4953a79e", null ]
];