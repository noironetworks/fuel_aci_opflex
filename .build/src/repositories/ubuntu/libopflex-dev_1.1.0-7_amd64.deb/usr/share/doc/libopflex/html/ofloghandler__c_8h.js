var ofloghandler__c_8h =
[
    [ "LOG_DEBUG1", "ofloghandler__c_8h.html#ga86b83e67e838f35b174e0b09e38c02f4", null ],
    [ "LOG_DEBUG2", "ofloghandler__c_8h.html#ga173816c382b4ec16b3c8ff8d25974b70", null ],
    [ "LOG_DEBUG3", "ofloghandler__c_8h.html#gab1a4bdfb9a07ba0fc565aa7cef8d8033", null ],
    [ "LOG_DEBUG4", "ofloghandler__c_8h.html#ga4ae785e7226c52ff7076f153a1e95f84", null ],
    [ "LOG_ERROR", "ofloghandler__c_8h.html#gaced66975c154ea0e2a8ec3bc818b4e08", null ],
    [ "LOG_FATAL", "ofloghandler__c_8h.html#gac2164369b4d2bf72296f8ba6ea576ecf", null ],
    [ "LOG_INFO", "ofloghandler__c_8h.html#gaeb4f36db01bd128c7afeac5889dac311", null ],
    [ "LOG_TRACE", "ofloghandler__c_8h.html#gaf7abc145380f1916838e42f9272aa0f6", null ],
    [ "LOG_WARNING", "ofloghandler__c_8h.html#gadf4476a6a4ea6c74231c826e899d7189", null ],
    [ "loghandler_p", "ofloghandler__c_8h.html#gad4556069023611421da2d70ec278117f", null ],
    [ "ofloghandler_register", "ofloghandler__c_8h.html#gab6c66eadd5112c5b75c71ad728293b99", null ]
];