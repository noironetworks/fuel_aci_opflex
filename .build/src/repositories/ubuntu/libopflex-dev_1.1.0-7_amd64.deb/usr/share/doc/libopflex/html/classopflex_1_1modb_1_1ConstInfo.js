var classopflex_1_1modb_1_1ConstInfo =
[
    [ "ConstInfo", "classopflex_1_1modb_1_1ConstInfo.html#a42774563ea9ebd1d063205c2fca834c6", null ],
    [ "~ConstInfo", "classopflex_1_1modb_1_1ConstInfo.html#a1ac69f8bc8c24e6d1e02e9211f70911b", null ],
    [ "getId", "classopflex_1_1modb_1_1ConstInfo.html#a7a0261ebbe307216c6bc759f43a516e1", null ],
    [ "getName", "classopflex_1_1modb_1_1ConstInfo.html#ac04d1773eb481e0c34037e9e12811ba3", null ]
];