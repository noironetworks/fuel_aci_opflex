var classopflex_1_1ofcore_1_1OFConstants =
[
    [ "OpflexRole", "classopflex_1_1ofcore_1_1OFConstants.html#ac09325d3e39d97c822dcf165412beaff", [
      [ "BOOTSTRAP", "classopflex_1_1ofcore_1_1OFConstants.html#ac09325d3e39d97c822dcf165412beaffa5f8c8c2e7d9ec4fa47d05f2cc4949ea9", null ],
      [ "POLICY_ELEMENT", "classopflex_1_1ofcore_1_1OFConstants.html#ac09325d3e39d97c822dcf165412beaffa0662e920dfdffdfd334738b9d740875f", null ],
      [ "POLICY_REPOSITORY", "classopflex_1_1ofcore_1_1OFConstants.html#ac09325d3e39d97c822dcf165412beaffad667d7f14350b346b64ff62d7a8449ab", null ],
      [ "ENDPOINT_REGISTRY", "classopflex_1_1ofcore_1_1OFConstants.html#ac09325d3e39d97c822dcf165412beaffaecc4e1797f57c5613ddec4d75242b383", null ],
      [ "OBSERVER", "classopflex_1_1ofcore_1_1OFConstants.html#ac09325d3e39d97c822dcf165412beaffa2648e3c78a6fb4f5eed8ab12e83f699d", null ]
    ] ]
];