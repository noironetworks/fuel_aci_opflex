var group__cmutator =
[
    [ "ofmutator_p", "group__cmutator.html#gadba4c3fe1867edbe2e3fdde55f3bc918", null ],
    [ "ofmutator_commit", "group__cmutator.html#ga735c3450d28b808053e37a818a5fe3d5", null ],
    [ "ofmutator_create", "group__cmutator.html#ga1762a4449f9d9816bbab8cc3bdb7ad13", null ],
    [ "ofmutator_destroy", "group__cmutator.html#gaf9c47016410016d580502ac4ecfd9958", null ]
];