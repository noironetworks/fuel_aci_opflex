var classopflex_1_1ofcore_1_1PeerStatusListener =
[
    [ "Health", "classopflex_1_1ofcore_1_1PeerStatusListener.html#a74ec86aed9aab8278606c51ba5a62171", [
      [ "DOWN", "classopflex_1_1ofcore_1_1PeerStatusListener.html#a74ec86aed9aab8278606c51ba5a62171aa129765a5e6c91c9218bcd77dd4fa8fb", null ],
      [ "DEGRADED", "classopflex_1_1ofcore_1_1PeerStatusListener.html#a74ec86aed9aab8278606c51ba5a62171a0a8ad576c1f0be1d78da353b47edc751", null ],
      [ "HEALTHY", "classopflex_1_1ofcore_1_1PeerStatusListener.html#a74ec86aed9aab8278606c51ba5a62171a865cbd2b30454048ca3ad6ced0d3e692", null ]
    ] ],
    [ "PeerStatus", "classopflex_1_1ofcore_1_1PeerStatusListener.html#a05bea1d9e74798db0e368e07ada21e70", [
      [ "DISCONNECTED", "classopflex_1_1ofcore_1_1PeerStatusListener.html#a05bea1d9e74798db0e368e07ada21e70a2f3c1c5c770c077e4744c53d8733bca4", null ],
      [ "CONNECTING", "classopflex_1_1ofcore_1_1PeerStatusListener.html#a05bea1d9e74798db0e368e07ada21e70aa4a2db59f53a8e949d524d11fbd94e2e", null ],
      [ "CONNECTED", "classopflex_1_1ofcore_1_1PeerStatusListener.html#a05bea1d9e74798db0e368e07ada21e70ac898845b108a8833eb6b3cd278e403dd", null ],
      [ "READY", "classopflex_1_1ofcore_1_1PeerStatusListener.html#a05bea1d9e74798db0e368e07ada21e70a7cde81aa2711b390ce7f3b3dfe8bf5ba", null ],
      [ "CLOSING", "classopflex_1_1ofcore_1_1PeerStatusListener.html#a05bea1d9e74798db0e368e07ada21e70a431217d509dff3eafeea56dee5bdf828", null ]
    ] ],
    [ "healthUpdated", "classopflex_1_1ofcore_1_1PeerStatusListener.html#a8363389a3c4fdd7f7c37e179640193b5", null ],
    [ "peerStatusUpdated", "classopflex_1_1ofcore_1_1PeerStatusListener.html#a672f8900eff741f1e028c7818888a87b", null ]
];