var group__cpoolhealth =
[
    [ "OF_POOLHEALTH_DEGRADED", "group__cpoolhealth.html#ga2f34a2517cc4c65a46a63c0867f0d3b4", null ],
    [ "OF_POOLHEALTH_DOWN", "group__cpoolhealth.html#ga8a277cf3346869cbe42b6f0b29490197", null ],
    [ "OF_POOLHEALTH_ERROR", "group__cpoolhealth.html#ga657e9f9b0b8392e61d14fed678ea75bb", null ],
    [ "OF_POOLHEALTH_HEALTHY", "group__cpoolhealth.html#gab8b9e918f9a13a66b2490892d3ba6838", null ]
];