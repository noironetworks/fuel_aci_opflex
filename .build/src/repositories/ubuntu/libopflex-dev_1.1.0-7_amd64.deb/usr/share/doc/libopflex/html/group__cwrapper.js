var group__cwrapper =
[
    [ "Core", "group__ccore.html", "group__ccore" ],
    [ "Model Metadata", "group__cmetadata.html", "group__cmetadata" ],
    [ "Logging", "group__clogging.html", "group__clogging" ],
    [ "Managed Objects", "group__cmodb.html", "group__cmodb" ]
];