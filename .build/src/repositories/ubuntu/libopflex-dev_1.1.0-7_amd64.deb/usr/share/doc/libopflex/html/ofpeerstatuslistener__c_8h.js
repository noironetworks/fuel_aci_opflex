var ofpeerstatuslistener__c_8h =
[
    [ "OF_PEERSTATUS_CLOSING", "ofpeerstatuslistener__c_8h.html#ga95eb94670df6e1c85424b9c8e993fee0", null ],
    [ "OF_PEERSTATUS_CONNECTED", "ofpeerstatuslistener__c_8h.html#gaf1429d8f0e491016ae33bd251fe37f73", null ],
    [ "OF_PEERSTATUS_CONNECTING", "ofpeerstatuslistener__c_8h.html#ga2c97db0cb5eb3a41b4f48fa264d87bd8", null ],
    [ "OF_PEERSTATUS_DISCONNECTED", "ofpeerstatuslistener__c_8h.html#gaa4efd85bb79d30163356bbdef5d5416d", null ],
    [ "OF_PEERSTATUS_ERROR", "ofpeerstatuslistener__c_8h.html#ga4aaf0ba13304ea3db8ac55bca7256d00", null ],
    [ "OF_PEERSTATUS_READY", "ofpeerstatuslistener__c_8h.html#gaad520485b5838ffaad4544d3a9b7ec7f", null ],
    [ "OF_POOLHEALTH_DEGRADED", "ofpeerstatuslistener__c_8h.html#ga2f34a2517cc4c65a46a63c0867f0d3b4", null ],
    [ "OF_POOLHEALTH_DOWN", "ofpeerstatuslistener__c_8h.html#ga8a277cf3346869cbe42b6f0b29490197", null ],
    [ "OF_POOLHEALTH_ERROR", "ofpeerstatuslistener__c_8h.html#ga657e9f9b0b8392e61d14fed678ea75bb", null ],
    [ "OF_POOLHEALTH_HEALTHY", "ofpeerstatuslistener__c_8h.html#gab8b9e918f9a13a66b2490892d3ba6838", null ],
    [ "ofpeerstatus_health_p", "ofpeerstatuslistener__c_8h.html#ga7eca073903dc68f7e84116471e5594fc", null ],
    [ "ofpeerstatus_peer_p", "ofpeerstatuslistener__c_8h.html#gaa8598c7630f2fbeb322d98ae4f30765d", null ],
    [ "ofpeerstatuslistener_p", "ofpeerstatuslistener__c_8h.html#ga15eae0d545a149cbfd2e3efdc2f15158", null ],
    [ "ofpeerstatuslistener_create", "ofpeerstatuslistener__c_8h.html#ga6a937aa46db8cefe370bed90b013207e", null ],
    [ "ofpeerstatuslistener_destroy", "ofpeerstatuslistener__c_8h.html#ga7e9504c6cee99ae1ae71f588e5b86a84", null ]
];