var group__cdefs =
[
    [ "OF_EFAILED", "group__cdefs.html#ga8374400f35a2c06632352bbbe9291739", null ],
    [ "OF_EINVALID_ARG", "group__cdefs.html#gafcc75d9e3ce27df5c1def429a5247064", null ],
    [ "OF_ELOGIC", "group__cdefs.html#ga0fb753729d1416ea5540f9ac026b1db3", null ],
    [ "OF_EMEMORY", "group__cdefs.html#gabfa25e2be625da42446204796f929a38", null ],
    [ "OF_EOUTOFRANGE", "group__cdefs.html#gabbdd34947cd65213f6968c3fe46bd5bb", null ],
    [ "OF_ERUNTIME", "group__cdefs.html#ga17bad552f271fb87af83a6bce11fc638", null ],
    [ "OF_ESUCCESS", "group__cdefs.html#gaea4ac8c38bfc40983f456c4b82ae5677", null ],
    [ "OF_IS_FAILURE", "group__cdefs.html#gad1d0549f4b3483debe0b9e2196238d93", null ],
    [ "OF_IS_SUCCESS", "group__cdefs.html#gaa13d444a2e222de112e295ecfe73523b", null ],
    [ "class_id_t", "group__cdefs.html#ga6b23acac15a740a1814c9d53ae9d8e21", null ],
    [ "ofobj_p", "group__cdefs.html#ga8b1cdee6af511be2badff03236508574", null ],
    [ "ofstatus", "group__cdefs.html#ga0552910a7b6c38abfd81c1a33177f652", null ]
];