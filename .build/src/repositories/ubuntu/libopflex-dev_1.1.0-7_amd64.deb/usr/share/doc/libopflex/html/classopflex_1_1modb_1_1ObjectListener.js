var classopflex_1_1modb_1_1ObjectListener =
[
    [ "~ObjectListener", "classopflex_1_1modb_1_1ObjectListener.html#ad5dd29b9a4f1ceebfd3dbd1d8380981a", null ],
    [ "objectUpdated", "classopflex_1_1modb_1_1ObjectListener.html#aec56f972881f4c07db28c73595239f76", null ]
];