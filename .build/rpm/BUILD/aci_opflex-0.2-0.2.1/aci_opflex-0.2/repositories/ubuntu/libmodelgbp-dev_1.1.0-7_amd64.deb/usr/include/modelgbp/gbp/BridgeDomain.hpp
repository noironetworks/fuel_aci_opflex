/**
 * 
 * SOME COPYRIGHT
 * 
 * BridgeDomain.hpp
 * 
 * generated BridgeDomain.hpp file genie code generation framework free of license.
 *  
 */
#pragma once
#ifndef GI_GBP_BRIDGEDOMAIN_HPP
#define GI_GBP_BRIDGEDOMAIN_HPP

#include <boost/optional.hpp>
#include "opflex/modb/URIBuilder.h"
#include "opflex/modb/mo-internal/MO.h"
/*
 * contains: item:mclass(gbpe/InstContext)
 */
#include "modelgbp/gbpe/InstContext.hpp"
/*
 * contains: item:mclass(gbp/EpGroupFromNetworkRTgt)
 */
#include "modelgbp/gbp/EpGroupFromNetworkRTgt.hpp"
/*
 * contains: item:mclass(gbp/BridgeDomainToNetworkRSrc)
 */
#include "modelgbp/gbp/BridgeDomainToNetworkRSrc.hpp"
/*
 * contains: item:mclass(gbp/FloodDomainFromNetworkRTgt)
 */
#include "modelgbp/gbp/FloodDomainFromNetworkRTgt.hpp"
/*
 * contains: item:mclass(gbp/ForwardingBehavioralGroupToSubnetsRSrc)
 */
#include "modelgbp/gbp/ForwardingBehavioralGroupToSubnetsRSrc.hpp"

namespace modelgbp {
namespace gbp {

class BridgeDomain
    : public opflex::modb::mointernal::MO
{
public:

    /**
     * The unique class ID for BridgeDomain
     */
    static const opflex::modb::class_id_t CLASS_ID = 132;

    /**
     * Check whether name has been set
     * @return true if name has been set
     */
    bool isNameSet()
    {
        return getObjectInstance().isSet(4325377ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of name if it has been set.
     * @return the value of name or boost::none if not set
     */
    boost::optional<const std::string&> getName()
    {
        if (isNameSet())
            return getObjectInstance().getString(4325377ul);
        return boost::none;
    }

    /**
     * Get the value of name if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of name if set, otherwise the value of default passed in
     */
    const std::string& getName(const std::string& defaultValue)
    {
        return getName().get_value_or(defaultValue);
    }

    /**
     * Set name to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::BridgeDomain& setName(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(4325377ul, newValue);
        return *this;
    }

    /**
     * Unset name in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::BridgeDomain& unsetName()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(4325377ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether routingMode has been set
     * @return true if routingMode has been set
     */
    bool isRoutingModeSet()
    {
        return getObjectInstance().isSet(4325378ul, opflex::modb::PropertyInfo::ENUM8);
    }

    /**
     * Get the value of routingMode if it has been set.
     * @return the value of routingMode or boost::none if not set
     */
    boost::optional<const uint8_t> getRoutingMode()
    {
        if (isRoutingModeSet())
            return (const uint8_t)getObjectInstance().getUInt64(4325378ul);
        return boost::none;
    }

    /**
     * Get the value of routingMode if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of routingMode if set, otherwise the value of default passed in
     */
    const uint8_t getRoutingMode(const uint8_t defaultValue)
    {
        return getRoutingMode().get_value_or(defaultValue);
    }

    /**
     * Set routingMode to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::BridgeDomain& setRoutingMode(const uint8_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(4325378ul, newValue);
        return *this;
    }

    /**
     * Unset routingMode in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::BridgeDomain& unsetRoutingMode()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(4325378ul, opflex::modb::PropertyInfo::ENUM8, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Retrieve an instance of BridgeDomain from the managed
     * object store.  If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::BridgeDomain> > resolve(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::gbp::BridgeDomain>(framework, CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of BridgeDomain from the managed
     * object store using the default framework instance.  If the 
     * object does not exist in the local store, returns boost::none. 
     * Note that even though it may not exist locally, it may still 
     * exist remotely.
     * 
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::BridgeDomain> > resolve(
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::gbp::BridgeDomain>(opflex::ofcore::OFFramework::defaultInstance(), CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of BridgeDomain from the managed
     * object store by constructing its URI from the path elements
     * that lead to it.  If the object does not exist in the local
     * store, returns boost::none.  Note that even though it may not
     * exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpBridgeDomain/[gbpBridgeDomainName]
     * 
     * @param framework the framework instance to use 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpBridgeDomainName the value of gbpBridgeDomainName,
     * a naming property for BridgeDomain
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::BridgeDomain> > resolve(
        opflex::ofcore::OFFramework& framework,
        const std::string& policySpaceName,
        const std::string& gbpBridgeDomainName)
    {
        return resolve(framework,opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PolicySpace").addElement(policySpaceName).addElement("GbpBridgeDomain").addElement(gbpBridgeDomainName).build());
    }

    /**
     * Retrieve an instance of BridgeDomain from the 
     * default managed object store by constructing its URI from the
     * path elements that lead to it.  If the object does not exist in
     * the local store, returns boost::none.  Note that even though it
     * may not exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpBridgeDomain/[gbpBridgeDomainName]
     * 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpBridgeDomainName the value of gbpBridgeDomainName,
     * a naming property for BridgeDomain
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::BridgeDomain> > resolve(
        const std::string& policySpaceName,
        const std::string& gbpBridgeDomainName)
    {
        return resolve(opflex::ofcore::OFFramework::defaultInstance(),policySpaceName,gbpBridgeDomainName);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbpe::InstContext> > resolveGbpeInstContext(
        )
    {
        return modelgbp::gbpe::InstContext::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpeInstContext").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbpe::InstContext> addGbpeInstContext(
        )
    {
        boost::shared_ptr<modelgbp::gbpe::InstContext> result = addChild<modelgbp::gbpe::InstContext>(
            CLASS_ID, getURI(), 2151809053ul, 29,
            opflex::modb::URIBuilder(getURI()).addElement("GbpeInstContext").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param gbpEpGroupFromNetworkRTgtSource the value of gbpEpGroupFromNetworkRTgtSource,
     * a naming property for EpGroupFromNetworkRTgt
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::EpGroupFromNetworkRTgt> > resolveGbpEpGroupFromNetworkRTgt(
        const std::string& gbpEpGroupFromNetworkRTgtSource)
    {
        return modelgbp::gbp::EpGroupFromNetworkRTgt::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpEpGroupFromNetworkRTgt").addElement(gbpEpGroupFromNetworkRTgtSource).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param gbpEpGroupFromNetworkRTgtSource the value of gbpEpGroupFromNetworkRTgtSource,
     * a naming property for EpGroupFromNetworkRTgt
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::EpGroupFromNetworkRTgt> addGbpEpGroupFromNetworkRTgt(
        const std::string& gbpEpGroupFromNetworkRTgtSource)
    {
        boost::shared_ptr<modelgbp::gbp::EpGroupFromNetworkRTgt> result = addChild<modelgbp::gbp::EpGroupFromNetworkRTgt>(
            CLASS_ID, getURI(), 2151809132ul, 108,
            opflex::modb::URIBuilder(getURI()).addElement("GbpEpGroupFromNetworkRTgt").addElement(gbpEpGroupFromNetworkRTgtSource).build()
            );
        result->setSource(gbpEpGroupFromNetworkRTgtSource);
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::gbp::EpGroupFromNetworkRTgt
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveGbpEpGroupFromNetworkRTgt(/* out */ std::vector<boost::shared_ptr<modelgbp::gbp::EpGroupFromNetworkRTgt> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::gbp::EpGroupFromNetworkRTgt>(
            getFramework(), CLASS_ID, getURI(), 2151809132ul, 108, out);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::BridgeDomainToNetworkRSrc> > resolveGbpBridgeDomainToNetworkRSrc(
        )
    {
        return modelgbp::gbp::BridgeDomainToNetworkRSrc::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpBridgeDomainToNetworkRSrc").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::BridgeDomainToNetworkRSrc> addGbpBridgeDomainToNetworkRSrc(
        )
    {
        boost::shared_ptr<modelgbp::gbp::BridgeDomainToNetworkRSrc> result = addChild<modelgbp::gbp::BridgeDomainToNetworkRSrc>(
            CLASS_ID, getURI(), 2151809157ul, 133,
            opflex::modb::URIBuilder(getURI()).addElement("GbpBridgeDomainToNetworkRSrc").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param gbpFloodDomainFromNetworkRTgtSource the value of gbpFloodDomainFromNetworkRTgtSource,
     * a naming property for FloodDomainFromNetworkRTgt
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::FloodDomainFromNetworkRTgt> > resolveGbpFloodDomainFromNetworkRTgt(
        const std::string& gbpFloodDomainFromNetworkRTgtSource)
    {
        return modelgbp::gbp::FloodDomainFromNetworkRTgt::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpFloodDomainFromNetworkRTgt").addElement(gbpFloodDomainFromNetworkRTgtSource).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param gbpFloodDomainFromNetworkRTgtSource the value of gbpFloodDomainFromNetworkRTgtSource,
     * a naming property for FloodDomainFromNetworkRTgt
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::FloodDomainFromNetworkRTgt> addGbpFloodDomainFromNetworkRTgt(
        const std::string& gbpFloodDomainFromNetworkRTgtSource)
    {
        boost::shared_ptr<modelgbp::gbp::FloodDomainFromNetworkRTgt> result = addChild<modelgbp::gbp::FloodDomainFromNetworkRTgt>(
            CLASS_ID, getURI(), 2151809162ul, 138,
            opflex::modb::URIBuilder(getURI()).addElement("GbpFloodDomainFromNetworkRTgt").addElement(gbpFloodDomainFromNetworkRTgtSource).build()
            );
        result->setSource(gbpFloodDomainFromNetworkRTgtSource);
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::gbp::FloodDomainFromNetworkRTgt
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveGbpFloodDomainFromNetworkRTgt(/* out */ std::vector<boost::shared_ptr<modelgbp::gbp::FloodDomainFromNetworkRTgt> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::gbp::FloodDomainFromNetworkRTgt>(
            getFramework(), CLASS_ID, getURI(), 2151809162ul, 138, out);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::ForwardingBehavioralGroupToSubnetsRSrc> > resolveGbpForwardingBehavioralGroupToSubnetsRSrc(
        )
    {
        return modelgbp::gbp::ForwardingBehavioralGroupToSubnetsRSrc::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpForwardingBehavioralGroupToSubnetsRSrc").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::ForwardingBehavioralGroupToSubnetsRSrc> addGbpForwardingBehavioralGroupToSubnetsRSrc(
        )
    {
        boost::shared_ptr<modelgbp::gbp::ForwardingBehavioralGroupToSubnetsRSrc> result = addChild<modelgbp::gbp::ForwardingBehavioralGroupToSubnetsRSrc>(
            CLASS_ID, getURI(), 2151809174ul, 150,
            opflex::modb::URIBuilder(getURI()).addElement("GbpForwardingBehavioralGroupToSubnetsRSrc").build()
            );
        return result;
    }

    /**
     * Remove this instance using the currently-active mutator.  If
     * the object does not exist, then this will be a no-op.  If this
     * object has any children, they will be garbage-collected at some
     * future time.
     * 
     * @throws std::logic_error if no mutator is active
     */
    void remove()
    {
        getTLMutator().remove(CLASS_ID, getURI());
    }

    /**
     * Remove the BridgeDomain object with the specified URI
     * using the currently-active mutator.  If the object does not exist,
     * then this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(opflex::ofcore::OFFramework& framework,
                       const opflex::modb::URI& uri)
    {
        MO::remove(framework, CLASS_ID, uri);
    }

    /**
     * Remove the BridgeDomain object with the specified URI 
     * using the currently-active mutator and the default framework 
     * instance.  If the object does not exist, then this will be a
     * no-op.  If this object has any children, they will be 
     * garbage-collected at some future time.
     * 
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(const opflex::modb::URI& uri)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(), uri);
    }

    /**
     * Remove the BridgeDomain object with the specified path
     * elements from the managed object store.  If the object does
     * not exist, then this will be a no-op.  If this object has any
     * children, they will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpBridgeDomain/[gbpBridgeDomainName]
     * 
     * @param framework the framework instance to use
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpBridgeDomainName the value of gbpBridgeDomainName,
     * a naming property for BridgeDomain
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        opflex::ofcore::OFFramework& framework,
        const std::string& policySpaceName,
        const std::string& gbpBridgeDomainName)
    {
        MO::remove(framework, CLASS_ID, opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PolicySpace").addElement(policySpaceName).addElement("GbpBridgeDomain").addElement(gbpBridgeDomainName).build());
    }

    /**
     * Remove the BridgeDomain object with the specified path
     * elements from the managed object store using the default
     * framework instance.  If the object does not exist, then
     * this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpBridgeDomain/[gbpBridgeDomainName]
     * 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpBridgeDomainName the value of gbpBridgeDomainName,
     * a naming property for BridgeDomain
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        const std::string& policySpaceName,
        const std::string& gbpBridgeDomainName)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(),policySpaceName,gbpBridgeDomainName);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class.  This listener will be called for any modifications
     * of this class or any transitive children of this class.
     * 
     * @param framework the framework instance 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::registerListener(framework, listener, CLASS_ID);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class with the default framework instance.  This listener
     * will be called for any modifications of this class or any
     * transitive children of this class.
     * 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::modb::ObjectListener* listener)
    {
        registerListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Unregister a listener from updates to this class.
     * 
     * @param framework the framework instance 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::unregisterListener(framework, listener, CLASS_ID);
    }

    /**
     * Unregister a listener from updates to this class from the
     * default framework instance
     * 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::modb::ObjectListener* listener)
    {
        unregisterListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Construct an instance of BridgeDomain.
     * This should not typically be called from user code.
     */
    BridgeDomain(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri,
        const boost::shared_ptr<const opflex::modb::mointernal::ObjectInstance>& oi)
        : MO(framework, CLASS_ID, uri, oi) { }
}; // class BridgeDomain

} // namespace gbp
} // namespace modelgbp
#endif // GI_GBP_BRIDGEDOMAIN_HPP
