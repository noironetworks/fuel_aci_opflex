/**
 * 
 * SOME COPYRIGHT
 * 
 * DstSummary.hpp
 * 
 * generated DstSummary.hpp file genie code generation framework free of license.
 *  
 */
#pragma once
#ifndef GI_SPAN_DSTSUMMARY_HPP
#define GI_SPAN_DSTSUMMARY_HPP

#include <boost/optional.hpp>
#include "opflex/modb/URIBuilder.h"
#include "opflex/modb/mo-internal/MO.h"

namespace modelgbp {
namespace span {

class DstSummary
    : public opflex::modb::mointernal::MO
{
public:

    /**
     * The unique class ID for DstSummary
     */
    static const opflex::modb::class_id_t CLASS_ID = 61;

    /**
     * Check whether dest has been set
     * @return true if dest has been set
     */
    bool isDestSet()
    {
        return getObjectInstance().isSet(1998849ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of dest if it has been set.
     * @return the value of dest or boost::none if not set
     */
    boost::optional<const std::string&> getDest()
    {
        if (isDestSet())
            return getObjectInstance().getString(1998849ul);
        return boost::none;
    }

    /**
     * Get the value of dest if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of dest if set, otherwise the value of default passed in
     */
    const std::string& getDest(const std::string& defaultValue)
    {
        return getDest().get_value_or(defaultValue);
    }

    /**
     * Set dest to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::span::DstSummary& setDest(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(1998849ul, newValue);
        return *this;
    }

    /**
     * Unset dest in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::span::DstSummary& unsetDest()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1998849ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether dscp has been set
     * @return true if dscp has been set
     */
    bool isDscpSet()
    {
        return getObjectInstance().isSet(1998856ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of dscp if it has been set.
     * @return the value of dscp or boost::none if not set
     */
    boost::optional<const uint8_t> getDscp()
    {
        if (isDscpSet())
            return (const uint8_t)getObjectInstance().getUInt64(1998856ul);
        return boost::none;
    }

    /**
     * Get the value of dscp if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of dscp if set, otherwise the value of default passed in
     */
    const uint8_t getDscp(const uint8_t defaultValue)
    {
        return getDscp().get_value_or(defaultValue);
    }

    /**
     * Set dscp to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::span::DstSummary& setDscp(const uint8_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(1998856ul, newValue);
        return *this;
    }

    /**
     * Unset dscp in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::span::DstSummary& unsetDscp()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1998856ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether flowId has been set
     * @return true if flowId has been set
     */
    bool isFlowIdSet()
    {
        return getObjectInstance().isSet(1998852ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of flowId if it has been set.
     * @return the value of flowId or boost::none if not set
     */
    boost::optional<uint16_t> getFlowId()
    {
        if (isFlowIdSet())
            return (uint16_t)getObjectInstance().getUInt64(1998852ul);
        return boost::none;
    }

    /**
     * Get the value of flowId if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of flowId if set, otherwise the value of default passed in
     */
    uint16_t getFlowId(uint16_t defaultValue)
    {
        return getFlowId().get_value_or(defaultValue);
    }

    /**
     * Set flowId to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::span::DstSummary& setFlowId(uint16_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(1998852ul, newValue);
        return *this;
    }

    /**
     * Unset flowId in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::span::DstSummary& unsetFlowId()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1998852ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether mode has been set
     * @return true if mode has been set
     */
    bool isModeSet()
    {
        return getObjectInstance().isSet(1998857ul, opflex::modb::PropertyInfo::ENUM8);
    }

    /**
     * Get the value of mode if it has been set.
     * @return the value of mode or boost::none if not set
     */
    boost::optional<const uint8_t> getMode()
    {
        if (isModeSet())
            return (const uint8_t)getObjectInstance().getUInt64(1998857ul);
        return boost::none;
    }

    /**
     * Get the value of mode if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of mode if set, otherwise the value of default passed in
     */
    const uint8_t getMode(const uint8_t defaultValue)
    {
        return getMode().get_value_or(defaultValue);
    }

    /**
     * Set mode to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::span::DstSummary& setMode(const uint8_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(1998857ul, newValue);
        return *this;
    }

    /**
     * Unset mode in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::span::DstSummary& unsetMode()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1998857ul, opflex::modb::PropertyInfo::ENUM8, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether mtu has been set
     * @return true if mtu has been set
     */
    bool isMtuSet()
    {
        return getObjectInstance().isSet(1998855ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of mtu if it has been set.
     * @return the value of mtu or boost::none if not set
     */
    boost::optional<uint32_t> getMtu()
    {
        if (isMtuSet())
            return (uint32_t)getObjectInstance().getUInt64(1998855ul);
        return boost::none;
    }

    /**
     * Get the value of mtu if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of mtu if set, otherwise the value of default passed in
     */
    uint32_t getMtu(uint32_t defaultValue)
    {
        return getMtu().get_value_or(defaultValue);
    }

    /**
     * Set mtu to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::span::DstSummary& setMtu(uint32_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(1998855ul, newValue);
        return *this;
    }

    /**
     * Unset mtu in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::span::DstSummary& unsetMtu()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1998855ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether srcPrefix has been set
     * @return true if srcPrefix has been set
     */
    bool isSrcPrefixSet()
    {
        return getObjectInstance().isSet(1998850ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of srcPrefix if it has been set.
     * @return the value of srcPrefix or boost::none if not set
     */
    boost::optional<const std::string&> getSrcPrefix()
    {
        if (isSrcPrefixSet())
            return getObjectInstance().getString(1998850ul);
        return boost::none;
    }

    /**
     * Get the value of srcPrefix if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of srcPrefix if set, otherwise the value of default passed in
     */
    const std::string& getSrcPrefix(const std::string& defaultValue)
    {
        return getSrcPrefix().get_value_or(defaultValue);
    }

    /**
     * Set srcPrefix to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::span::DstSummary& setSrcPrefix(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(1998850ul, newValue);
        return *this;
    }

    /**
     * Unset srcPrefix in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::span::DstSummary& unsetSrcPrefix()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1998850ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether ttl has been set
     * @return true if ttl has been set
     */
    bool isTtlSet()
    {
        return getObjectInstance().isSet(1998853ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of ttl if it has been set.
     * @return the value of ttl or boost::none if not set
     */
    boost::optional<const uint8_t> getTtl()
    {
        if (isTtlSet())
            return (const uint8_t)getObjectInstance().getUInt64(1998853ul);
        return boost::none;
    }

    /**
     * Get the value of ttl if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of ttl if set, otherwise the value of default passed in
     */
    const uint8_t getTtl(const uint8_t defaultValue)
    {
        return getTtl().get_value_or(defaultValue);
    }

    /**
     * Set ttl to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::span::DstSummary& setTtl(const uint8_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(1998853ul, newValue);
        return *this;
    }

    /**
     * Unset ttl in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::span::DstSummary& unsetTtl()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1998853ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether version has been set
     * @return true if version has been set
     */
    bool isVersionSet()
    {
        return getObjectInstance().isSet(1998851ul, opflex::modb::PropertyInfo::ENUM8);
    }

    /**
     * Get the value of version if it has been set.
     * @return the value of version or boost::none if not set
     */
    boost::optional<const uint8_t> getVersion()
    {
        if (isVersionSet())
            return (const uint8_t)getObjectInstance().getUInt64(1998851ul);
        return boost::none;
    }

    /**
     * Get the value of version if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of version if set, otherwise the value of default passed in
     */
    const uint8_t getVersion(const uint8_t defaultValue)
    {
        return getVersion().get_value_or(defaultValue);
    }

    /**
     * Set version to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::span::DstSummary& setVersion(const uint8_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(1998851ul, newValue);
        return *this;
    }

    /**
     * Unset version in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::span::DstSummary& unsetVersion()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1998851ul, opflex::modb::PropertyInfo::ENUM8, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether vrfName has been set
     * @return true if vrfName has been set
     */
    bool isVrfNameSet()
    {
        return getObjectInstance().isSet(1998854ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of vrfName if it has been set.
     * @return the value of vrfName or boost::none if not set
     */
    boost::optional<const std::string&> getVrfName()
    {
        if (isVrfNameSet())
            return getObjectInstance().getString(1998854ul);
        return boost::none;
    }

    /**
     * Get the value of vrfName if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of vrfName if set, otherwise the value of default passed in
     */
    const std::string& getVrfName(const std::string& defaultValue)
    {
        return getVrfName().get_value_or(defaultValue);
    }

    /**
     * Set vrfName to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::span::DstSummary& setVrfName(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(1998854ul, newValue);
        return *this;
    }

    /**
     * Unset vrfName in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::span::DstSummary& unsetVrfName()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1998854ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Retrieve an instance of DstSummary from the managed
     * object store.  If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::span::DstSummary> > resolve(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::span::DstSummary>(framework, CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of DstSummary from the managed
     * object store using the default framework instance.  If the 
     * object does not exist in the local store, returns boost::none. 
     * Note that even though it may not exist locally, it may still 
     * exist remotely.
     * 
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::span::DstSummary> > resolve(
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::span::DstSummary>(opflex::ofcore::OFFramework::defaultInstance(), CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of DstSummary from the managed
     * object store by constructing its URI from the path elements
     * that lead to it.  If the object does not exist in the local
     * store, returns boost::none.  Note that even though it may not
     * exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PlatformConfig/[platformConfigName]/SpanSrcGrp/[spanSrcGrpName]/SpanDstMember/[spanDstMemberName]/SpanDstSummary
     * 
     * @param framework the framework instance to use 
     * @param platformConfigName the value of platformConfigName,
     * a naming property for Config
     * @param spanSrcGrpName the value of spanSrcGrpName,
     * a naming property for SrcGrp
     * @param spanDstMemberName the value of spanDstMemberName,
     * a naming property for DstMember
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::span::DstSummary> > resolveUnderPolicyUniversePlatformConfigSpanSrcGrpSpanDstMember(
        opflex::ofcore::OFFramework& framework,
        const std::string& platformConfigName,
        const std::string& spanSrcGrpName,
        const std::string& spanDstMemberName)
    {
        return resolve(framework,opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PlatformConfig").addElement(platformConfigName).addElement("SpanSrcGrp").addElement(spanSrcGrpName).addElement("SpanDstMember").addElement(spanDstMemberName).addElement("SpanDstSummary").build());
    }

    /**
     * Retrieve an instance of DstSummary from the 
     * default managed object store by constructing its URI from the
     * path elements that lead to it.  If the object does not exist in
     * the local store, returns boost::none.  Note that even though it
     * may not exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PlatformConfig/[platformConfigName]/SpanSrcGrp/[spanSrcGrpName]/SpanDstMember/[spanDstMemberName]/SpanDstSummary
     * 
     * @param platformConfigName the value of platformConfigName,
     * a naming property for Config
     * @param spanSrcGrpName the value of spanSrcGrpName,
     * a naming property for SrcGrp
     * @param spanDstMemberName the value of spanDstMemberName,
     * a naming property for DstMember
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::span::DstSummary> > resolveUnderPolicyUniversePlatformConfigSpanSrcGrpSpanDstMember(
        const std::string& platformConfigName,
        const std::string& spanSrcGrpName,
        const std::string& spanDstMemberName)
    {
        return resolveUnderPolicyUniversePlatformConfigSpanSrcGrpSpanDstMember(opflex::ofcore::OFFramework::defaultInstance(),platformConfigName,spanSrcGrpName,spanDstMemberName);
    }

    /**
     * Retrieve an instance of DstSummary from the managed
     * object store by constructing its URI from the path elements
     * that lead to it.  If the object does not exist in the local
     * store, returns boost::none.  Note that even though it may not
     * exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PlatformConfig/[platformConfigName]/SpanDstGrp/[spanDstGrpName]/SpanDstMember/[spanDstMemberName]/SpanDstSummary
     * 
     * @param framework the framework instance to use 
     * @param platformConfigName the value of platformConfigName,
     * a naming property for Config
     * @param spanDstGrpName the value of spanDstGrpName,
     * a naming property for DstGrp
     * @param spanDstMemberName the value of spanDstMemberName,
     * a naming property for DstMember
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::span::DstSummary> > resolveUnderPolicyUniversePlatformConfigSpanDstGrpSpanDstMember(
        opflex::ofcore::OFFramework& framework,
        const std::string& platformConfigName,
        const std::string& spanDstGrpName,
        const std::string& spanDstMemberName)
    {
        return resolve(framework,opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PlatformConfig").addElement(platformConfigName).addElement("SpanDstGrp").addElement(spanDstGrpName).addElement("SpanDstMember").addElement(spanDstMemberName).addElement("SpanDstSummary").build());
    }

    /**
     * Retrieve an instance of DstSummary from the 
     * default managed object store by constructing its URI from the
     * path elements that lead to it.  If the object does not exist in
     * the local store, returns boost::none.  Note that even though it
     * may not exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PlatformConfig/[platformConfigName]/SpanDstGrp/[spanDstGrpName]/SpanDstMember/[spanDstMemberName]/SpanDstSummary
     * 
     * @param platformConfigName the value of platformConfigName,
     * a naming property for Config
     * @param spanDstGrpName the value of spanDstGrpName,
     * a naming property for DstGrp
     * @param spanDstMemberName the value of spanDstMemberName,
     * a naming property for DstMember
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::span::DstSummary> > resolveUnderPolicyUniversePlatformConfigSpanDstGrpSpanDstMember(
        const std::string& platformConfigName,
        const std::string& spanDstGrpName,
        const std::string& spanDstMemberName)
    {
        return resolveUnderPolicyUniversePlatformConfigSpanDstGrpSpanDstMember(opflex::ofcore::OFFramework::defaultInstance(),platformConfigName,spanDstGrpName,spanDstMemberName);
    }

    /**
     * Remove this instance using the currently-active mutator.  If
     * the object does not exist, then this will be a no-op.  If this
     * object has any children, they will be garbage-collected at some
     * future time.
     * 
     * @throws std::logic_error if no mutator is active
     */
    void remove()
    {
        getTLMutator().remove(CLASS_ID, getURI());
    }

    /**
     * Remove the DstSummary object with the specified URI
     * using the currently-active mutator.  If the object does not exist,
     * then this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(opflex::ofcore::OFFramework& framework,
                       const opflex::modb::URI& uri)
    {
        MO::remove(framework, CLASS_ID, uri);
    }

    /**
     * Remove the DstSummary object with the specified URI 
     * using the currently-active mutator and the default framework 
     * instance.  If the object does not exist, then this will be a
     * no-op.  If this object has any children, they will be 
     * garbage-collected at some future time.
     * 
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(const opflex::modb::URI& uri)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(), uri);
    }

    /**
     * Remove the DstSummary object with the specified path
     * elements from the managed object store.  If the object does
     * not exist, then this will be a no-op.  If this object has any
     * children, they will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PlatformConfig/[platformConfigName]/SpanSrcGrp/[spanSrcGrpName]/SpanDstMember/[spanDstMemberName]/SpanDstSummary
     * 
     * @param framework the framework instance to use
     * @param platformConfigName the value of platformConfigName,
     * a naming property for Config
     * @param spanSrcGrpName the value of spanSrcGrpName,
     * a naming property for SrcGrp
     * @param spanDstMemberName the value of spanDstMemberName,
     * a naming property for DstMember
     * @throws std::logic_error if no mutator is active
     */
    static void removeUnderPolicyUniversePlatformConfigSpanSrcGrpSpanDstMember(
        opflex::ofcore::OFFramework& framework,
        const std::string& platformConfigName,
        const std::string& spanSrcGrpName,
        const std::string& spanDstMemberName)
    {
        MO::remove(framework, CLASS_ID, opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PlatformConfig").addElement(platformConfigName).addElement("SpanSrcGrp").addElement(spanSrcGrpName).addElement("SpanDstMember").addElement(spanDstMemberName).addElement("SpanDstSummary").build());
    }

    /**
     * Remove the DstSummary object with the specified path
     * elements from the managed object store using the default
     * framework instance.  If the object does not exist, then
     * this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PlatformConfig/[platformConfigName]/SpanSrcGrp/[spanSrcGrpName]/SpanDstMember/[spanDstMemberName]/SpanDstSummary
     * 
     * @param platformConfigName the value of platformConfigName,
     * a naming property for Config
     * @param spanSrcGrpName the value of spanSrcGrpName,
     * a naming property for SrcGrp
     * @param spanDstMemberName the value of spanDstMemberName,
     * a naming property for DstMember
     * @throws std::logic_error if no mutator is active
     */
    static void removeUnderPolicyUniversePlatformConfigSpanSrcGrpSpanDstMember(
        const std::string& platformConfigName,
        const std::string& spanSrcGrpName,
        const std::string& spanDstMemberName)
    {
        removeUnderPolicyUniversePlatformConfigSpanSrcGrpSpanDstMember(opflex::ofcore::OFFramework::defaultInstance(),platformConfigName,spanSrcGrpName,spanDstMemberName);
    }

    /**
     * Remove the DstSummary object with the specified path
     * elements from the managed object store.  If the object does
     * not exist, then this will be a no-op.  If this object has any
     * children, they will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PlatformConfig/[platformConfigName]/SpanDstGrp/[spanDstGrpName]/SpanDstMember/[spanDstMemberName]/SpanDstSummary
     * 
     * @param framework the framework instance to use
     * @param platformConfigName the value of platformConfigName,
     * a naming property for Config
     * @param spanDstGrpName the value of spanDstGrpName,
     * a naming property for DstGrp
     * @param spanDstMemberName the value of spanDstMemberName,
     * a naming property for DstMember
     * @throws std::logic_error if no mutator is active
     */
    static void removeUnderPolicyUniversePlatformConfigSpanDstGrpSpanDstMember(
        opflex::ofcore::OFFramework& framework,
        const std::string& platformConfigName,
        const std::string& spanDstGrpName,
        const std::string& spanDstMemberName)
    {
        MO::remove(framework, CLASS_ID, opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PlatformConfig").addElement(platformConfigName).addElement("SpanDstGrp").addElement(spanDstGrpName).addElement("SpanDstMember").addElement(spanDstMemberName).addElement("SpanDstSummary").build());
    }

    /**
     * Remove the DstSummary object with the specified path
     * elements from the managed object store using the default
     * framework instance.  If the object does not exist, then
     * this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PlatformConfig/[platformConfigName]/SpanDstGrp/[spanDstGrpName]/SpanDstMember/[spanDstMemberName]/SpanDstSummary
     * 
     * @param platformConfigName the value of platformConfigName,
     * a naming property for Config
     * @param spanDstGrpName the value of spanDstGrpName,
     * a naming property for DstGrp
     * @param spanDstMemberName the value of spanDstMemberName,
     * a naming property for DstMember
     * @throws std::logic_error if no mutator is active
     */
    static void removeUnderPolicyUniversePlatformConfigSpanDstGrpSpanDstMember(
        const std::string& platformConfigName,
        const std::string& spanDstGrpName,
        const std::string& spanDstMemberName)
    {
        removeUnderPolicyUniversePlatformConfigSpanDstGrpSpanDstMember(opflex::ofcore::OFFramework::defaultInstance(),platformConfigName,spanDstGrpName,spanDstMemberName);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class.  This listener will be called for any modifications
     * of this class or any transitive children of this class.
     * 
     * @param framework the framework instance 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::registerListener(framework, listener, CLASS_ID);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class with the default framework instance.  This listener
     * will be called for any modifications of this class or any
     * transitive children of this class.
     * 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::modb::ObjectListener* listener)
    {
        registerListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Unregister a listener from updates to this class.
     * 
     * @param framework the framework instance 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::unregisterListener(framework, listener, CLASS_ID);
    }

    /**
     * Unregister a listener from updates to this class from the
     * default framework instance
     * 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::modb::ObjectListener* listener)
    {
        unregisterListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Construct an instance of DstSummary.
     * This should not typically be called from user code.
     */
    DstSummary(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri,
        const boost::shared_ptr<const opflex::modb::mointernal::ObjectInstance>& oi)
        : MO(framework, CLASS_ID, uri, oi) { }
}; // class DstSummary

} // namespace span
} // namespace modelgbp
#endif // GI_SPAN_DSTSUMMARY_HPP
