/**
 * 
 * SOME COPYRIGHT
 * 
 * Subnet.hpp
 * 
 * generated Subnet.hpp file genie code generation framework free of license.
 *  
 */
#pragma once
#ifndef GI_GBP_SUBNET_HPP
#define GI_GBP_SUBNET_HPP

#include <boost/optional.hpp>
#include "opflex/modb/URIBuilder.h"
#include "opflex/modb/mo-internal/MO.h"

namespace modelgbp {
namespace gbp {

class Subnet
    : public opflex::modb::mointernal::MO
{
public:

    /**
     * The unique class ID for Subnet
     */
    static const opflex::modb::class_id_t CLASS_ID = 146;

    /**
     * Check whether address has been set
     * @return true if address has been set
     */
    bool isAddressSet()
    {
        return getObjectInstance().isSet(4784130ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of address if it has been set.
     * @return the value of address or boost::none if not set
     */
    boost::optional<const std::string&> getAddress()
    {
        if (isAddressSet())
            return getObjectInstance().getString(4784130ul);
        return boost::none;
    }

    /**
     * Get the value of address if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of address if set, otherwise the value of default passed in
     */
    const std::string& getAddress(const std::string& defaultValue)
    {
        return getAddress().get_value_or(defaultValue);
    }

    /**
     * Set address to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::Subnet& setAddress(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(4784130ul, newValue);
        return *this;
    }

    /**
     * Unset address in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::Subnet& unsetAddress()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(4784130ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether ipv6AdvAutonomousFlag has been set
     * @return true if ipv6AdvAutonomousFlag has been set
     */
    bool isIpv6AdvAutonomousFlagSet()
    {
        return getObjectInstance().isSet(4784134ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of ipv6AdvAutonomousFlag if it has been set.
     * @return the value of ipv6AdvAutonomousFlag or boost::none if not set
     */
    boost::optional<const uint8_t> getIpv6AdvAutonomousFlag()
    {
        if (isIpv6AdvAutonomousFlagSet())
            return (const uint8_t)getObjectInstance().getUInt64(4784134ul);
        return boost::none;
    }

    /**
     * Get the value of ipv6AdvAutonomousFlag if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of ipv6AdvAutonomousFlag if set, otherwise the value of default passed in
     */
    const uint8_t getIpv6AdvAutonomousFlag(const uint8_t defaultValue)
    {
        return getIpv6AdvAutonomousFlag().get_value_or(defaultValue);
    }

    /**
     * Set ipv6AdvAutonomousFlag to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::Subnet& setIpv6AdvAutonomousFlag(const uint8_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(4784134ul, newValue);
        return *this;
    }

    /**
     * Unset ipv6AdvAutonomousFlag in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::Subnet& unsetIpv6AdvAutonomousFlag()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(4784134ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether ipv6AdvPreferredLifetime has been set
     * @return true if ipv6AdvPreferredLifetime has been set
     */
    bool isIpv6AdvPreferredLifetimeSet()
    {
        return getObjectInstance().isSet(4784135ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of ipv6AdvPreferredLifetime if it has been set.
     * @return the value of ipv6AdvPreferredLifetime or boost::none if not set
     */
    boost::optional<uint32_t> getIpv6AdvPreferredLifetime()
    {
        if (isIpv6AdvPreferredLifetimeSet())
            return (uint32_t)getObjectInstance().getUInt64(4784135ul);
        return boost::none;
    }

    /**
     * Get the value of ipv6AdvPreferredLifetime if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of ipv6AdvPreferredLifetime if set, otherwise the value of default passed in
     */
    uint32_t getIpv6AdvPreferredLifetime(uint32_t defaultValue)
    {
        return getIpv6AdvPreferredLifetime().get_value_or(defaultValue);
    }

    /**
     * Set ipv6AdvPreferredLifetime to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::Subnet& setIpv6AdvPreferredLifetime(uint32_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(4784135ul, newValue);
        return *this;
    }

    /**
     * Unset ipv6AdvPreferredLifetime in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::Subnet& unsetIpv6AdvPreferredLifetime()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(4784135ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether ipv6AdvValidLifetime has been set
     * @return true if ipv6AdvValidLifetime has been set
     */
    bool isIpv6AdvValidLifetimeSet()
    {
        return getObjectInstance().isSet(4784133ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of ipv6AdvValidLifetime if it has been set.
     * @return the value of ipv6AdvValidLifetime or boost::none if not set
     */
    boost::optional<uint32_t> getIpv6AdvValidLifetime()
    {
        if (isIpv6AdvValidLifetimeSet())
            return (uint32_t)getObjectInstance().getUInt64(4784133ul);
        return boost::none;
    }

    /**
     * Get the value of ipv6AdvValidLifetime if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of ipv6AdvValidLifetime if set, otherwise the value of default passed in
     */
    uint32_t getIpv6AdvValidLifetime(uint32_t defaultValue)
    {
        return getIpv6AdvValidLifetime().get_value_or(defaultValue);
    }

    /**
     * Set ipv6AdvValidLifetime to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::Subnet& setIpv6AdvValidLifetime(uint32_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(4784133ul, newValue);
        return *this;
    }

    /**
     * Unset ipv6AdvValidLifetime in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::Subnet& unsetIpv6AdvValidLifetime()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(4784133ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether name has been set
     * @return true if name has been set
     */
    bool isNameSet()
    {
        return getObjectInstance().isSet(4784129ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of name if it has been set.
     * @return the value of name or boost::none if not set
     */
    boost::optional<const std::string&> getName()
    {
        if (isNameSet())
            return getObjectInstance().getString(4784129ul);
        return boost::none;
    }

    /**
     * Get the value of name if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of name if set, otherwise the value of default passed in
     */
    const std::string& getName(const std::string& defaultValue)
    {
        return getName().get_value_or(defaultValue);
    }

    /**
     * Set name to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::Subnet& setName(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(4784129ul, newValue);
        return *this;
    }

    /**
     * Unset name in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::Subnet& unsetName()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(4784129ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether prefixLen has been set
     * @return true if prefixLen has been set
     */
    bool isPrefixLenSet()
    {
        return getObjectInstance().isSet(4784131ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of prefixLen if it has been set.
     * @return the value of prefixLen or boost::none if not set
     */
    boost::optional<const uint8_t> getPrefixLen()
    {
        if (isPrefixLenSet())
            return (const uint8_t)getObjectInstance().getUInt64(4784131ul);
        return boost::none;
    }

    /**
     * Get the value of prefixLen if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of prefixLen if set, otherwise the value of default passed in
     */
    const uint8_t getPrefixLen(const uint8_t defaultValue)
    {
        return getPrefixLen().get_value_or(defaultValue);
    }

    /**
     * Set prefixLen to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::Subnet& setPrefixLen(const uint8_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(4784131ul, newValue);
        return *this;
    }

    /**
     * Unset prefixLen in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::Subnet& unsetPrefixLen()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(4784131ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether virtualRouterIp has been set
     * @return true if virtualRouterIp has been set
     */
    bool isVirtualRouterIpSet()
    {
        return getObjectInstance().isSet(4784132ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of virtualRouterIp if it has been set.
     * @return the value of virtualRouterIp or boost::none if not set
     */
    boost::optional<const std::string&> getVirtualRouterIp()
    {
        if (isVirtualRouterIpSet())
            return getObjectInstance().getString(4784132ul);
        return boost::none;
    }

    /**
     * Get the value of virtualRouterIp if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of virtualRouterIp if set, otherwise the value of default passed in
     */
    const std::string& getVirtualRouterIp(const std::string& defaultValue)
    {
        return getVirtualRouterIp().get_value_or(defaultValue);
    }

    /**
     * Set virtualRouterIp to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::Subnet& setVirtualRouterIp(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(4784132ul, newValue);
        return *this;
    }

    /**
     * Unset virtualRouterIp in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::Subnet& unsetVirtualRouterIp()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(4784132ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Retrieve an instance of Subnet from the managed
     * object store.  If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::Subnet> > resolve(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::gbp::Subnet>(framework, CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of Subnet from the managed
     * object store using the default framework instance.  If the 
     * object does not exist in the local store, returns boost::none. 
     * Note that even though it may not exist locally, it may still 
     * exist remotely.
     * 
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::Subnet> > resolve(
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::gbp::Subnet>(opflex::ofcore::OFFramework::defaultInstance(), CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of Subnet from the managed
     * object store by constructing its URI from the path elements
     * that lead to it.  If the object does not exist in the local
     * store, returns boost::none.  Note that even though it may not
     * exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpSubnets/[gbpSubnetsName]/GbpSubnet/[gbpSubnetName]
     * 
     * @param framework the framework instance to use 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpSubnetsName the value of gbpSubnetsName,
     * a naming property for Subnets
     * @param gbpSubnetName the value of gbpSubnetName,
     * a naming property for Subnet
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::Subnet> > resolve(
        opflex::ofcore::OFFramework& framework,
        const std::string& policySpaceName,
        const std::string& gbpSubnetsName,
        const std::string& gbpSubnetName)
    {
        return resolve(framework,opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PolicySpace").addElement(policySpaceName).addElement("GbpSubnets").addElement(gbpSubnetsName).addElement("GbpSubnet").addElement(gbpSubnetName).build());
    }

    /**
     * Retrieve an instance of Subnet from the 
     * default managed object store by constructing its URI from the
     * path elements that lead to it.  If the object does not exist in
     * the local store, returns boost::none.  Note that even though it
     * may not exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpSubnets/[gbpSubnetsName]/GbpSubnet/[gbpSubnetName]
     * 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpSubnetsName the value of gbpSubnetsName,
     * a naming property for Subnets
     * @param gbpSubnetName the value of gbpSubnetName,
     * a naming property for Subnet
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::Subnet> > resolve(
        const std::string& policySpaceName,
        const std::string& gbpSubnetsName,
        const std::string& gbpSubnetName)
    {
        return resolve(opflex::ofcore::OFFramework::defaultInstance(),policySpaceName,gbpSubnetsName,gbpSubnetName);
    }

    /**
     * Remove this instance using the currently-active mutator.  If
     * the object does not exist, then this will be a no-op.  If this
     * object has any children, they will be garbage-collected at some
     * future time.
     * 
     * @throws std::logic_error if no mutator is active
     */
    void remove()
    {
        getTLMutator().remove(CLASS_ID, getURI());
    }

    /**
     * Remove the Subnet object with the specified URI
     * using the currently-active mutator.  If the object does not exist,
     * then this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(opflex::ofcore::OFFramework& framework,
                       const opflex::modb::URI& uri)
    {
        MO::remove(framework, CLASS_ID, uri);
    }

    /**
     * Remove the Subnet object with the specified URI 
     * using the currently-active mutator and the default framework 
     * instance.  If the object does not exist, then this will be a
     * no-op.  If this object has any children, they will be 
     * garbage-collected at some future time.
     * 
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(const opflex::modb::URI& uri)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(), uri);
    }

    /**
     * Remove the Subnet object with the specified path
     * elements from the managed object store.  If the object does
     * not exist, then this will be a no-op.  If this object has any
     * children, they will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpSubnets/[gbpSubnetsName]/GbpSubnet/[gbpSubnetName]
     * 
     * @param framework the framework instance to use
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpSubnetsName the value of gbpSubnetsName,
     * a naming property for Subnets
     * @param gbpSubnetName the value of gbpSubnetName,
     * a naming property for Subnet
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        opflex::ofcore::OFFramework& framework,
        const std::string& policySpaceName,
        const std::string& gbpSubnetsName,
        const std::string& gbpSubnetName)
    {
        MO::remove(framework, CLASS_ID, opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PolicySpace").addElement(policySpaceName).addElement("GbpSubnets").addElement(gbpSubnetsName).addElement("GbpSubnet").addElement(gbpSubnetName).build());
    }

    /**
     * Remove the Subnet object with the specified path
     * elements from the managed object store using the default
     * framework instance.  If the object does not exist, then
     * this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpSubnets/[gbpSubnetsName]/GbpSubnet/[gbpSubnetName]
     * 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpSubnetsName the value of gbpSubnetsName,
     * a naming property for Subnets
     * @param gbpSubnetName the value of gbpSubnetName,
     * a naming property for Subnet
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        const std::string& policySpaceName,
        const std::string& gbpSubnetsName,
        const std::string& gbpSubnetName)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(),policySpaceName,gbpSubnetsName,gbpSubnetName);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class.  This listener will be called for any modifications
     * of this class or any transitive children of this class.
     * 
     * @param framework the framework instance 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::registerListener(framework, listener, CLASS_ID);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class with the default framework instance.  This listener
     * will be called for any modifications of this class or any
     * transitive children of this class.
     * 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::modb::ObjectListener* listener)
    {
        registerListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Unregister a listener from updates to this class.
     * 
     * @param framework the framework instance 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::unregisterListener(framework, listener, CLASS_ID);
    }

    /**
     * Unregister a listener from updates to this class from the
     * default framework instance
     * 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::modb::ObjectListener* listener)
    {
        unregisterListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Construct an instance of Subnet.
     * This should not typically be called from user code.
     */
    Subnet(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri,
        const boost::shared_ptr<const opflex::modb::mointernal::ObjectInstance>& oi)
        : MO(framework, CLASS_ID, uri, oi) { }
}; // class Subnet

} // namespace gbp
} // namespace modelgbp
#endif // GI_GBP_SUBNET_HPP
