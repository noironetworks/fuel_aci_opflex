var classmodelgbp_1_1gbp_1_1ForwardingBehavioralGroupToSubnetsRRes =
[
    [ "ForwardingBehavioralGroupToSubnetsRRes", "classmodelgbp_1_1gbp_1_1ForwardingBehavioralGroupToSubnetsRRes.html#aaf5a643f9e754b8d60474142f4a22e46", null ],
    [ "getRole", "classmodelgbp_1_1gbp_1_1ForwardingBehavioralGroupToSubnetsRRes.html#a6762bab8c7212cf14557d3780e3febc2", null ],
    [ "getRole", "classmodelgbp_1_1gbp_1_1ForwardingBehavioralGroupToSubnetsRRes.html#a51c82aefe7bace400e24de8bd1c07745", null ],
    [ "getType", "classmodelgbp_1_1gbp_1_1ForwardingBehavioralGroupToSubnetsRRes.html#a732160fdd71fa431e42144886fcc0827", null ],
    [ "getType", "classmodelgbp_1_1gbp_1_1ForwardingBehavioralGroupToSubnetsRRes.html#a4d15174c15d021f692268b0888506cc3", null ],
    [ "isRoleSet", "classmodelgbp_1_1gbp_1_1ForwardingBehavioralGroupToSubnetsRRes.html#a99b48e87976b4d28df184f199afa45f2", null ],
    [ "isTypeSet", "classmodelgbp_1_1gbp_1_1ForwardingBehavioralGroupToSubnetsRRes.html#a197e1ed13f7f72977a43aa552493d536", null ],
    [ "remove", "classmodelgbp_1_1gbp_1_1ForwardingBehavioralGroupToSubnetsRRes.html#a62e846c1871f2bba93f3e264057f92b7", null ],
    [ "setRole", "classmodelgbp_1_1gbp_1_1ForwardingBehavioralGroupToSubnetsRRes.html#ae5e8c4483fd58b2a71cbd964adbba7a4", null ],
    [ "setType", "classmodelgbp_1_1gbp_1_1ForwardingBehavioralGroupToSubnetsRRes.html#a27d9a1d2bb819859bd211e743703058c", null ],
    [ "unsetRole", "classmodelgbp_1_1gbp_1_1ForwardingBehavioralGroupToSubnetsRRes.html#a51c77c29880f22e8b62a4c2e63d4ae32", null ],
    [ "unsetType", "classmodelgbp_1_1gbp_1_1ForwardingBehavioralGroupToSubnetsRRes.html#a153d7af4afeff5c2c3a62c3ba14ae21b", null ]
];