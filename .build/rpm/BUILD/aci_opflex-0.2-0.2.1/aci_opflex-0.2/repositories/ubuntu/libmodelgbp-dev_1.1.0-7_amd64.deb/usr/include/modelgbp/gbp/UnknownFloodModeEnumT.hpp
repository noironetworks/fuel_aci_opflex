/**
 * 
 * SOME COPYRIGHT
 * 
 * UnknownFloodModeEnumT.hpp
 * 
 * generated UnknownFloodModeEnumT.hpp file genie code generation framework free of license.
 *  
 */
#include <boost/cstdint.hpp>
#include <cstddef>
namespace modelgbp {
namespace gbp {
    struct UnknownFloodModeEnumT {
        static const uint8_t CONST_DROP = 0;
        static const uint8_t CONST_FLOOD = 1;
    };
}
}
