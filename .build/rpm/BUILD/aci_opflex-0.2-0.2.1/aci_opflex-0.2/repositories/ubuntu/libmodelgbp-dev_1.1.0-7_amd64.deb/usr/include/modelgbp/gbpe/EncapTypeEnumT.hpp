/**
 * 
 * SOME COPYRIGHT
 * 
 * EncapTypeEnumT.hpp
 * 
 * generated EncapTypeEnumT.hpp file genie code generation framework free of license.
 *  
 */
#include <boost/cstdint.hpp>
#include <cstddef>
namespace modelgbp {
namespace gbpe {
    struct EncapTypeEnumT {
        static const uint8_t CONST_UNKNOWN = 0;
        static const uint8_t CONST_VLAN = 1;
        static const uint8_t CONST_VXLAN = 2;
    };
}
}
