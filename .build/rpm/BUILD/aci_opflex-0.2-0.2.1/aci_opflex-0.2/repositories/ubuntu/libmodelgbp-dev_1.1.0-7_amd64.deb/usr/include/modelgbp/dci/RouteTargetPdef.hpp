/**
 * 
 * SOME COPYRIGHT
 * 
 * RouteTargetPdef.hpp
 * 
 * generated RouteTargetPdef.hpp file genie code generation framework free of license.
 *  
 */
#pragma once
#ifndef GI_DCI_ROUTETARGETPDEF_HPP
#define GI_DCI_ROUTETARGETPDEF_HPP

#include <boost/optional.hpp>
#include "opflex/modb/URIBuilder.h"
#include "opflex/modb/mo-internal/MO.h"
/*
 * contains: item:mclass(dci/RouteTargetDef)
 */
#include "modelgbp/dci/RouteTargetDef.hpp"

namespace modelgbp {
namespace dci {

class RouteTargetPdef
    : public opflex::modb::mointernal::MO
{
public:

    /**
     * The unique class ID for RouteTargetPdef
     */
    static const opflex::modb::class_id_t CLASS_ID = 73;

    /**
     * Check whether af has been set
     * @return true if af has been set
     */
    bool isAfSet()
    {
        return getObjectInstance().isSet(2392066ul, opflex::modb::PropertyInfo::ENUM8);
    }

    /**
     * Get the value of af if it has been set.
     * @return the value of af or boost::none if not set
     */
    boost::optional<const uint8_t> getAf()
    {
        if (isAfSet())
            return (const uint8_t)getObjectInstance().getUInt64(2392066ul);
        return boost::none;
    }

    /**
     * Get the value of af if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of af if set, otherwise the value of default passed in
     */
    const uint8_t getAf(const uint8_t defaultValue)
    {
        return getAf().get_value_or(defaultValue);
    }

    /**
     * Set af to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::dci::RouteTargetPdef& setAf(const uint8_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(2392066ul, newValue);
        return *this;
    }

    /**
     * Unset af in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::dci::RouteTargetPdef& unsetAf()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(2392066ul, opflex::modb::PropertyInfo::ENUM8, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether name has been set
     * @return true if name has been set
     */
    bool isNameSet()
    {
        return getObjectInstance().isSet(2392065ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of name if it has been set.
     * @return the value of name or boost::none if not set
     */
    boost::optional<const std::string&> getName()
    {
        if (isNameSet())
            return getObjectInstance().getString(2392065ul);
        return boost::none;
    }

    /**
     * Get the value of name if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of name if set, otherwise the value of default passed in
     */
    const std::string& getName(const std::string& defaultValue)
    {
        return getName().get_value_or(defaultValue);
    }

    /**
     * Set name to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::dci::RouteTargetPdef& setName(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(2392065ul, newValue);
        return *this;
    }

    /**
     * Unset name in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::dci::RouteTargetPdef& unsetName()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(2392065ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Retrieve an instance of RouteTargetPdef from the managed
     * object store.  If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::dci::RouteTargetPdef> > resolve(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::dci::RouteTargetPdef>(framework, CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of RouteTargetPdef from the managed
     * object store using the default framework instance.  If the 
     * object does not exist in the local store, returns boost::none. 
     * Note that even though it may not exist locally, it may still 
     * exist remotely.
     * 
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::dci::RouteTargetPdef> > resolve(
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::dci::RouteTargetPdef>(opflex::ofcore::OFFramework::defaultInstance(), CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of RouteTargetPdef from the managed
     * object store by constructing its URI from the path elements
     * that lead to it.  If the object does not exist in the local
     * store, returns boost::none.  Note that even though it may not
     * exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpRoutingDomain/[gbpRoutingDomainName]/DciRouteTargetPdef/[dciRouteTargetPdefName]
     * 
     * @param framework the framework instance to use 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpRoutingDomainName the value of gbpRoutingDomainName,
     * a naming property for RoutingDomain
     * @param dciRouteTargetPdefName the value of dciRouteTargetPdefName,
     * a naming property for RouteTargetPdef
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::dci::RouteTargetPdef> > resolve(
        opflex::ofcore::OFFramework& framework,
        const std::string& policySpaceName,
        const std::string& gbpRoutingDomainName,
        const std::string& dciRouteTargetPdefName)
    {
        return resolve(framework,opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PolicySpace").addElement(policySpaceName).addElement("GbpRoutingDomain").addElement(gbpRoutingDomainName).addElement("DciRouteTargetPdef").addElement(dciRouteTargetPdefName).build());
    }

    /**
     * Retrieve an instance of RouteTargetPdef from the 
     * default managed object store by constructing its URI from the
     * path elements that lead to it.  If the object does not exist in
     * the local store, returns boost::none.  Note that even though it
     * may not exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpRoutingDomain/[gbpRoutingDomainName]/DciRouteTargetPdef/[dciRouteTargetPdefName]
     * 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpRoutingDomainName the value of gbpRoutingDomainName,
     * a naming property for RoutingDomain
     * @param dciRouteTargetPdefName the value of dciRouteTargetPdefName,
     * a naming property for RouteTargetPdef
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::dci::RouteTargetPdef> > resolve(
        const std::string& policySpaceName,
        const std::string& gbpRoutingDomainName,
        const std::string& dciRouteTargetPdefName)
    {
        return resolve(opflex::ofcore::OFFramework::defaultInstance(),policySpaceName,gbpRoutingDomainName,dciRouteTargetPdefName);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param dciRouteTargetDefName the value of dciRouteTargetDefName,
     * a naming property for RouteTargetDef
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::dci::RouteTargetDef> > resolveDciRouteTargetDef(
        const std::string& dciRouteTargetDefName)
    {
        return modelgbp::dci::RouteTargetDef::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("DciRouteTargetDef").addElement(dciRouteTargetDefName).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param dciRouteTargetDefName the value of dciRouteTargetDefName,
     * a naming property for RouteTargetDef
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::dci::RouteTargetDef> addDciRouteTargetDef(
        const std::string& dciRouteTargetDefName)
    {
        boost::shared_ptr<modelgbp::dci::RouteTargetDef> result = addChild<modelgbp::dci::RouteTargetDef>(
            CLASS_ID, getURI(), 2149875786ul, 74,
            opflex::modb::URIBuilder(getURI()).addElement("DciRouteTargetDef").addElement(dciRouteTargetDefName).build()
            );
        result->setName(dciRouteTargetDefName);
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::dci::RouteTargetDef
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveDciRouteTargetDef(/* out */ std::vector<boost::shared_ptr<modelgbp::dci::RouteTargetDef> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::dci::RouteTargetDef>(
            getFramework(), CLASS_ID, getURI(), 2149875786ul, 74, out);
    }

    /**
     * Remove this instance using the currently-active mutator.  If
     * the object does not exist, then this will be a no-op.  If this
     * object has any children, they will be garbage-collected at some
     * future time.
     * 
     * @throws std::logic_error if no mutator is active
     */
    void remove()
    {
        getTLMutator().remove(CLASS_ID, getURI());
    }

    /**
     * Remove the RouteTargetPdef object with the specified URI
     * using the currently-active mutator.  If the object does not exist,
     * then this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(opflex::ofcore::OFFramework& framework,
                       const opflex::modb::URI& uri)
    {
        MO::remove(framework, CLASS_ID, uri);
    }

    /**
     * Remove the RouteTargetPdef object with the specified URI 
     * using the currently-active mutator and the default framework 
     * instance.  If the object does not exist, then this will be a
     * no-op.  If this object has any children, they will be 
     * garbage-collected at some future time.
     * 
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(const opflex::modb::URI& uri)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(), uri);
    }

    /**
     * Remove the RouteTargetPdef object with the specified path
     * elements from the managed object store.  If the object does
     * not exist, then this will be a no-op.  If this object has any
     * children, they will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpRoutingDomain/[gbpRoutingDomainName]/DciRouteTargetPdef/[dciRouteTargetPdefName]
     * 
     * @param framework the framework instance to use
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpRoutingDomainName the value of gbpRoutingDomainName,
     * a naming property for RoutingDomain
     * @param dciRouteTargetPdefName the value of dciRouteTargetPdefName,
     * a naming property for RouteTargetPdef
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        opflex::ofcore::OFFramework& framework,
        const std::string& policySpaceName,
        const std::string& gbpRoutingDomainName,
        const std::string& dciRouteTargetPdefName)
    {
        MO::remove(framework, CLASS_ID, opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PolicySpace").addElement(policySpaceName).addElement("GbpRoutingDomain").addElement(gbpRoutingDomainName).addElement("DciRouteTargetPdef").addElement(dciRouteTargetPdefName).build());
    }

    /**
     * Remove the RouteTargetPdef object with the specified path
     * elements from the managed object store using the default
     * framework instance.  If the object does not exist, then
     * this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpRoutingDomain/[gbpRoutingDomainName]/DciRouteTargetPdef/[dciRouteTargetPdefName]
     * 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpRoutingDomainName the value of gbpRoutingDomainName,
     * a naming property for RoutingDomain
     * @param dciRouteTargetPdefName the value of dciRouteTargetPdefName,
     * a naming property for RouteTargetPdef
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        const std::string& policySpaceName,
        const std::string& gbpRoutingDomainName,
        const std::string& dciRouteTargetPdefName)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(),policySpaceName,gbpRoutingDomainName,dciRouteTargetPdefName);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class.  This listener will be called for any modifications
     * of this class or any transitive children of this class.
     * 
     * @param framework the framework instance 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::registerListener(framework, listener, CLASS_ID);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class with the default framework instance.  This listener
     * will be called for any modifications of this class or any
     * transitive children of this class.
     * 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::modb::ObjectListener* listener)
    {
        registerListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Unregister a listener from updates to this class.
     * 
     * @param framework the framework instance 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::unregisterListener(framework, listener, CLASS_ID);
    }

    /**
     * Unregister a listener from updates to this class from the
     * default framework instance
     * 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::modb::ObjectListener* listener)
    {
        unregisterListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Construct an instance of RouteTargetPdef.
     * This should not typically be called from user code.
     */
    RouteTargetPdef(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri,
        const boost::shared_ptr<const opflex::modb::mointernal::ObjectInstance>& oi)
        : MO(framework, CLASS_ID, uri, oi) { }
}; // class RouteTargetPdef

} // namespace dci
} // namespace modelgbp
#endif // GI_DCI_ROUTETARGETPDEF_HPP
