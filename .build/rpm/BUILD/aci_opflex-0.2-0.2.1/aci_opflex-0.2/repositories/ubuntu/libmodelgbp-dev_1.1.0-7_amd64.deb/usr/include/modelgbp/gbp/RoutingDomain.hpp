/**
 * 
 * SOME COPYRIGHT
 * 
 * RoutingDomain.hpp
 * 
 * generated RoutingDomain.hpp file genie code generation framework free of license.
 *  
 */
#pragma once
#ifndef GI_GBP_ROUTINGDOMAIN_HPP
#define GI_GBP_ROUTINGDOMAIN_HPP

#include <boost/optional.hpp>
#include "opflex/modb/URIBuilder.h"
#include "opflex/modb/mo-internal/MO.h"
/*
 * contains: item:mclass(gbpe/InstContext)
 */
#include "modelgbp/gbpe/InstContext.hpp"
/*
 * contains: item:mclass(dci/DomainFromNetworkRTgt)
 */
#include "modelgbp/dci/DomainFromNetworkRTgt.hpp"
/*
 * contains: item:mclass(dci/RouteTargetPdef)
 */
#include "modelgbp/dci/RouteTargetPdef.hpp"
/*
 * contains: item:mclass(gbp/EpGroupFromNetworkRTgt)
 */
#include "modelgbp/gbp/EpGroupFromNetworkRTgt.hpp"
/*
 * contains: item:mclass(gbp/L3ExternalDomain)
 */
#include "modelgbp/gbp/L3ExternalDomain.hpp"
/*
 * contains: item:mclass(gbp/BridgeDomainFromNetworkRTgt)
 */
#include "modelgbp/gbp/BridgeDomainFromNetworkRTgt.hpp"
/*
 * contains: item:mclass(gbp/RoutingDomainToIntSubnetsRSrc)
 */
#include "modelgbp/gbp/RoutingDomainToIntSubnetsRSrc.hpp"
/*
 * contains: item:mclass(gbp/ForwardingBehavioralGroupToSubnetsRSrc)
 */
#include "modelgbp/gbp/ForwardingBehavioralGroupToSubnetsRSrc.hpp"

namespace modelgbp {
namespace gbp {

class RoutingDomain
    : public opflex::modb::mointernal::MO
{
public:

    /**
     * The unique class ID for RoutingDomain
     */
    static const opflex::modb::class_id_t CLASS_ID = 141;

    /**
     * Check whether globalName has been set
     * @return true if globalName has been set
     */
    bool isGlobalNameSet()
    {
        return getObjectInstance().isSet(4620291ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of globalName if it has been set.
     * @return the value of globalName or boost::none if not set
     */
    boost::optional<const std::string&> getGlobalName()
    {
        if (isGlobalNameSet())
            return getObjectInstance().getString(4620291ul);
        return boost::none;
    }

    /**
     * Get the value of globalName if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of globalName if set, otherwise the value of default passed in
     */
    const std::string& getGlobalName(const std::string& defaultValue)
    {
        return getGlobalName().get_value_or(defaultValue);
    }

    /**
     * Set globalName to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::RoutingDomain& setGlobalName(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(4620291ul, newValue);
        return *this;
    }

    /**
     * Unset globalName in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::RoutingDomain& unsetGlobalName()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(4620291ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether ipv6Autoconfig has been set
     * @return true if ipv6Autoconfig has been set
     */
    bool isIpv6AutoconfigSet()
    {
        return getObjectInstance().isSet(4620290ul, opflex::modb::PropertyInfo::ENUM8);
    }

    /**
     * Get the value of ipv6Autoconfig if it has been set.
     * @return the value of ipv6Autoconfig or boost::none if not set
     */
    boost::optional<const uint8_t> getIpv6Autoconfig()
    {
        if (isIpv6AutoconfigSet())
            return (const uint8_t)getObjectInstance().getUInt64(4620290ul);
        return boost::none;
    }

    /**
     * Get the value of ipv6Autoconfig if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of ipv6Autoconfig if set, otherwise the value of default passed in
     */
    const uint8_t getIpv6Autoconfig(const uint8_t defaultValue)
    {
        return getIpv6Autoconfig().get_value_or(defaultValue);
    }

    /**
     * Set ipv6Autoconfig to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::RoutingDomain& setIpv6Autoconfig(const uint8_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(4620290ul, newValue);
        return *this;
    }

    /**
     * Unset ipv6Autoconfig in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::RoutingDomain& unsetIpv6Autoconfig()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(4620290ul, opflex::modb::PropertyInfo::ENUM8, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether name has been set
     * @return true if name has been set
     */
    bool isNameSet()
    {
        return getObjectInstance().isSet(4620289ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of name if it has been set.
     * @return the value of name or boost::none if not set
     */
    boost::optional<const std::string&> getName()
    {
        if (isNameSet())
            return getObjectInstance().getString(4620289ul);
        return boost::none;
    }

    /**
     * Get the value of name if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of name if set, otherwise the value of default passed in
     */
    const std::string& getName(const std::string& defaultValue)
    {
        return getName().get_value_or(defaultValue);
    }

    /**
     * Set name to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::RoutingDomain& setName(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(4620289ul, newValue);
        return *this;
    }

    /**
     * Unset name in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::RoutingDomain& unsetName()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(4620289ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Retrieve an instance of RoutingDomain from the managed
     * object store.  If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::RoutingDomain> > resolve(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::gbp::RoutingDomain>(framework, CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of RoutingDomain from the managed
     * object store using the default framework instance.  If the 
     * object does not exist in the local store, returns boost::none. 
     * Note that even though it may not exist locally, it may still 
     * exist remotely.
     * 
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::RoutingDomain> > resolve(
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::gbp::RoutingDomain>(opflex::ofcore::OFFramework::defaultInstance(), CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of RoutingDomain from the managed
     * object store by constructing its URI from the path elements
     * that lead to it.  If the object does not exist in the local
     * store, returns boost::none.  Note that even though it may not
     * exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpRoutingDomain/[gbpRoutingDomainName]
     * 
     * @param framework the framework instance to use 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpRoutingDomainName the value of gbpRoutingDomainName,
     * a naming property for RoutingDomain
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::RoutingDomain> > resolve(
        opflex::ofcore::OFFramework& framework,
        const std::string& policySpaceName,
        const std::string& gbpRoutingDomainName)
    {
        return resolve(framework,opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PolicySpace").addElement(policySpaceName).addElement("GbpRoutingDomain").addElement(gbpRoutingDomainName).build());
    }

    /**
     * Retrieve an instance of RoutingDomain from the 
     * default managed object store by constructing its URI from the
     * path elements that lead to it.  If the object does not exist in
     * the local store, returns boost::none.  Note that even though it
     * may not exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpRoutingDomain/[gbpRoutingDomainName]
     * 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpRoutingDomainName the value of gbpRoutingDomainName,
     * a naming property for RoutingDomain
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::RoutingDomain> > resolve(
        const std::string& policySpaceName,
        const std::string& gbpRoutingDomainName)
    {
        return resolve(opflex::ofcore::OFFramework::defaultInstance(),policySpaceName,gbpRoutingDomainName);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbpe::InstContext> > resolveGbpeInstContext(
        )
    {
        return modelgbp::gbpe::InstContext::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpeInstContext").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbpe::InstContext> addGbpeInstContext(
        )
    {
        boost::shared_ptr<modelgbp::gbpe::InstContext> result = addChild<modelgbp::gbpe::InstContext>(
            CLASS_ID, getURI(), 2152103965ul, 29,
            opflex::modb::URIBuilder(getURI()).addElement("GbpeInstContext").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param dciDomainFromNetworkRTgtSource the value of dciDomainFromNetworkRTgtSource,
     * a naming property for DomainFromNetworkRTgt
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::dci::DomainFromNetworkRTgt> > resolveDciDomainFromNetworkRTgt(
        const std::string& dciDomainFromNetworkRTgtSource)
    {
        return modelgbp::dci::DomainFromNetworkRTgt::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("DciDomainFromNetworkRTgt").addElement(dciDomainFromNetworkRTgtSource).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param dciDomainFromNetworkRTgtSource the value of dciDomainFromNetworkRTgtSource,
     * a naming property for DomainFromNetworkRTgt
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::dci::DomainFromNetworkRTgt> addDciDomainFromNetworkRTgt(
        const std::string& dciDomainFromNetworkRTgtSource)
    {
        boost::shared_ptr<modelgbp::dci::DomainFromNetworkRTgt> result = addChild<modelgbp::dci::DomainFromNetworkRTgt>(
            CLASS_ID, getURI(), 2152104007ul, 71,
            opflex::modb::URIBuilder(getURI()).addElement("DciDomainFromNetworkRTgt").addElement(dciDomainFromNetworkRTgtSource).build()
            );
        result->setSource(dciDomainFromNetworkRTgtSource);
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::dci::DomainFromNetworkRTgt
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveDciDomainFromNetworkRTgt(/* out */ std::vector<boost::shared_ptr<modelgbp::dci::DomainFromNetworkRTgt> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::dci::DomainFromNetworkRTgt>(
            getFramework(), CLASS_ID, getURI(), 2152104007ul, 71, out);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param dciRouteTargetPdefName the value of dciRouteTargetPdefName,
     * a naming property for RouteTargetPdef
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::dci::RouteTargetPdef> > resolveDciRouteTargetPdef(
        const std::string& dciRouteTargetPdefName)
    {
        return modelgbp::dci::RouteTargetPdef::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("DciRouteTargetPdef").addElement(dciRouteTargetPdefName).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param dciRouteTargetPdefName the value of dciRouteTargetPdefName,
     * a naming property for RouteTargetPdef
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::dci::RouteTargetPdef> addDciRouteTargetPdef(
        const std::string& dciRouteTargetPdefName)
    {
        boost::shared_ptr<modelgbp::dci::RouteTargetPdef> result = addChild<modelgbp::dci::RouteTargetPdef>(
            CLASS_ID, getURI(), 2152104009ul, 73,
            opflex::modb::URIBuilder(getURI()).addElement("DciRouteTargetPdef").addElement(dciRouteTargetPdefName).build()
            );
        result->setName(dciRouteTargetPdefName);
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::dci::RouteTargetPdef
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveDciRouteTargetPdef(/* out */ std::vector<boost::shared_ptr<modelgbp::dci::RouteTargetPdef> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::dci::RouteTargetPdef>(
            getFramework(), CLASS_ID, getURI(), 2152104009ul, 73, out);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param gbpEpGroupFromNetworkRTgtSource the value of gbpEpGroupFromNetworkRTgtSource,
     * a naming property for EpGroupFromNetworkRTgt
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::EpGroupFromNetworkRTgt> > resolveGbpEpGroupFromNetworkRTgt(
        const std::string& gbpEpGroupFromNetworkRTgtSource)
    {
        return modelgbp::gbp::EpGroupFromNetworkRTgt::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpEpGroupFromNetworkRTgt").addElement(gbpEpGroupFromNetworkRTgtSource).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param gbpEpGroupFromNetworkRTgtSource the value of gbpEpGroupFromNetworkRTgtSource,
     * a naming property for EpGroupFromNetworkRTgt
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::EpGroupFromNetworkRTgt> addGbpEpGroupFromNetworkRTgt(
        const std::string& gbpEpGroupFromNetworkRTgtSource)
    {
        boost::shared_ptr<modelgbp::gbp::EpGroupFromNetworkRTgt> result = addChild<modelgbp::gbp::EpGroupFromNetworkRTgt>(
            CLASS_ID, getURI(), 2152104044ul, 108,
            opflex::modb::URIBuilder(getURI()).addElement("GbpEpGroupFromNetworkRTgt").addElement(gbpEpGroupFromNetworkRTgtSource).build()
            );
        result->setSource(gbpEpGroupFromNetworkRTgtSource);
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::gbp::EpGroupFromNetworkRTgt
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveGbpEpGroupFromNetworkRTgt(/* out */ std::vector<boost::shared_ptr<modelgbp::gbp::EpGroupFromNetworkRTgt> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::gbp::EpGroupFromNetworkRTgt>(
            getFramework(), CLASS_ID, getURI(), 2152104044ul, 108, out);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param gbpL3ExternalDomainName the value of gbpL3ExternalDomainName,
     * a naming property for L3ExternalDomain
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::L3ExternalDomain> > resolveGbpL3ExternalDomain(
        const std::string& gbpL3ExternalDomainName)
    {
        return modelgbp::gbp::L3ExternalDomain::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpL3ExternalDomain").addElement(gbpL3ExternalDomainName).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param gbpL3ExternalDomainName the value of gbpL3ExternalDomainName,
     * a naming property for L3ExternalDomain
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::L3ExternalDomain> addGbpL3ExternalDomain(
        const std::string& gbpL3ExternalDomainName)
    {
        boost::shared_ptr<modelgbp::gbp::L3ExternalDomain> result = addChild<modelgbp::gbp::L3ExternalDomain>(
            CLASS_ID, getURI(), 2152104055ul, 119,
            opflex::modb::URIBuilder(getURI()).addElement("GbpL3ExternalDomain").addElement(gbpL3ExternalDomainName).build()
            );
        result->setName(gbpL3ExternalDomainName);
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::gbp::L3ExternalDomain
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveGbpL3ExternalDomain(/* out */ std::vector<boost::shared_ptr<modelgbp::gbp::L3ExternalDomain> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::gbp::L3ExternalDomain>(
            getFramework(), CLASS_ID, getURI(), 2152104055ul, 119, out);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param gbpBridgeDomainFromNetworkRTgtSource the value of gbpBridgeDomainFromNetworkRTgtSource,
     * a naming property for BridgeDomainFromNetworkRTgt
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::BridgeDomainFromNetworkRTgt> > resolveGbpBridgeDomainFromNetworkRTgt(
        const std::string& gbpBridgeDomainFromNetworkRTgtSource)
    {
        return modelgbp::gbp::BridgeDomainFromNetworkRTgt::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpBridgeDomainFromNetworkRTgt").addElement(gbpBridgeDomainFromNetworkRTgtSource).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param gbpBridgeDomainFromNetworkRTgtSource the value of gbpBridgeDomainFromNetworkRTgtSource,
     * a naming property for BridgeDomainFromNetworkRTgt
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::BridgeDomainFromNetworkRTgt> addGbpBridgeDomainFromNetworkRTgt(
        const std::string& gbpBridgeDomainFromNetworkRTgtSource)
    {
        boost::shared_ptr<modelgbp::gbp::BridgeDomainFromNetworkRTgt> result = addChild<modelgbp::gbp::BridgeDomainFromNetworkRTgt>(
            CLASS_ID, getURI(), 2152104070ul, 134,
            opflex::modb::URIBuilder(getURI()).addElement("GbpBridgeDomainFromNetworkRTgt").addElement(gbpBridgeDomainFromNetworkRTgtSource).build()
            );
        result->setSource(gbpBridgeDomainFromNetworkRTgtSource);
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::gbp::BridgeDomainFromNetworkRTgt
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveGbpBridgeDomainFromNetworkRTgt(/* out */ std::vector<boost::shared_ptr<modelgbp::gbp::BridgeDomainFromNetworkRTgt> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::gbp::BridgeDomainFromNetworkRTgt>(
            getFramework(), CLASS_ID, getURI(), 2152104070ul, 134, out);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param gbpRoutingDomainToIntSubnetsRSrcTargetClass the value of gbpRoutingDomainToIntSubnetsRSrcTargetClass,
     * a naming property for RoutingDomainToIntSubnetsRSrc
     * @param gbpRoutingDomainToIntSubnetsRSrcTargetName the value of gbpRoutingDomainToIntSubnetsRSrcTargetName,
     * a naming property for RoutingDomainToIntSubnetsRSrc
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::RoutingDomainToIntSubnetsRSrc> > resolveGbpRoutingDomainToIntSubnetsRSrc(
        const std::string& gbpRoutingDomainToIntSubnetsRSrcTargetName)
    {
        opflex::modb::class_id_t gbpRoutingDomainToIntSubnetsRSrcTargetClass = 147;
        return modelgbp::gbp::RoutingDomainToIntSubnetsRSrc::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpRoutingDomainToIntSubnetsRSrc").addElement(gbpRoutingDomainToIntSubnetsRSrcTargetClass).addElement(gbpRoutingDomainToIntSubnetsRSrcTargetName).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param gbpRoutingDomainToIntSubnetsRSrcTargetClass the value of gbpRoutingDomainToIntSubnetsRSrcTargetClass,
     * a naming property for RoutingDomainToIntSubnetsRSrc
     * @param gbpRoutingDomainToIntSubnetsRSrcTargetName the value of gbpRoutingDomainToIntSubnetsRSrcTargetName,
     * a naming property for RoutingDomainToIntSubnetsRSrc
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::RoutingDomainToIntSubnetsRSrc> addGbpRoutingDomainToIntSubnetsRSrc(
        const std::string& gbpRoutingDomainToIntSubnetsRSrcTargetName)
    {
        opflex::modb::class_id_t gbpRoutingDomainToIntSubnetsRSrcTargetClass = 147;
        boost::shared_ptr<modelgbp::gbp::RoutingDomainToIntSubnetsRSrc> result = addChild<modelgbp::gbp::RoutingDomainToIntSubnetsRSrc>(
            CLASS_ID, getURI(), 2152104078ul, 142,
            opflex::modb::URIBuilder(getURI()).addElement("GbpRoutingDomainToIntSubnetsRSrc").addElement(gbpRoutingDomainToIntSubnetsRSrcTargetClass).addElement(gbpRoutingDomainToIntSubnetsRSrcTargetName).build()
            );
        result->setTargetSubnets(opflex::modb::URI(gbpRoutingDomainToIntSubnetsRSrcTargetName));
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::gbp::RoutingDomainToIntSubnetsRSrc
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveGbpRoutingDomainToIntSubnetsRSrc(/* out */ std::vector<boost::shared_ptr<modelgbp::gbp::RoutingDomainToIntSubnetsRSrc> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::gbp::RoutingDomainToIntSubnetsRSrc>(
            getFramework(), CLASS_ID, getURI(), 2152104078ul, 142, out);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::ForwardingBehavioralGroupToSubnetsRSrc> > resolveGbpForwardingBehavioralGroupToSubnetsRSrc(
        )
    {
        return modelgbp::gbp::ForwardingBehavioralGroupToSubnetsRSrc::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpForwardingBehavioralGroupToSubnetsRSrc").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::ForwardingBehavioralGroupToSubnetsRSrc> addGbpForwardingBehavioralGroupToSubnetsRSrc(
        )
    {
        boost::shared_ptr<modelgbp::gbp::ForwardingBehavioralGroupToSubnetsRSrc> result = addChild<modelgbp::gbp::ForwardingBehavioralGroupToSubnetsRSrc>(
            CLASS_ID, getURI(), 2152104086ul, 150,
            opflex::modb::URIBuilder(getURI()).addElement("GbpForwardingBehavioralGroupToSubnetsRSrc").build()
            );
        return result;
    }

    /**
     * Remove this instance using the currently-active mutator.  If
     * the object does not exist, then this will be a no-op.  If this
     * object has any children, they will be garbage-collected at some
     * future time.
     * 
     * @throws std::logic_error if no mutator is active
     */
    void remove()
    {
        getTLMutator().remove(CLASS_ID, getURI());
    }

    /**
     * Remove the RoutingDomain object with the specified URI
     * using the currently-active mutator.  If the object does not exist,
     * then this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(opflex::ofcore::OFFramework& framework,
                       const opflex::modb::URI& uri)
    {
        MO::remove(framework, CLASS_ID, uri);
    }

    /**
     * Remove the RoutingDomain object with the specified URI 
     * using the currently-active mutator and the default framework 
     * instance.  If the object does not exist, then this will be a
     * no-op.  If this object has any children, they will be 
     * garbage-collected at some future time.
     * 
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(const opflex::modb::URI& uri)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(), uri);
    }

    /**
     * Remove the RoutingDomain object with the specified path
     * elements from the managed object store.  If the object does
     * not exist, then this will be a no-op.  If this object has any
     * children, they will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpRoutingDomain/[gbpRoutingDomainName]
     * 
     * @param framework the framework instance to use
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpRoutingDomainName the value of gbpRoutingDomainName,
     * a naming property for RoutingDomain
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        opflex::ofcore::OFFramework& framework,
        const std::string& policySpaceName,
        const std::string& gbpRoutingDomainName)
    {
        MO::remove(framework, CLASS_ID, opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PolicySpace").addElement(policySpaceName).addElement("GbpRoutingDomain").addElement(gbpRoutingDomainName).build());
    }

    /**
     * Remove the RoutingDomain object with the specified path
     * elements from the managed object store using the default
     * framework instance.  If the object does not exist, then
     * this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpRoutingDomain/[gbpRoutingDomainName]
     * 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpRoutingDomainName the value of gbpRoutingDomainName,
     * a naming property for RoutingDomain
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        const std::string& policySpaceName,
        const std::string& gbpRoutingDomainName)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(),policySpaceName,gbpRoutingDomainName);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class.  This listener will be called for any modifications
     * of this class or any transitive children of this class.
     * 
     * @param framework the framework instance 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::registerListener(framework, listener, CLASS_ID);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class with the default framework instance.  This listener
     * will be called for any modifications of this class or any
     * transitive children of this class.
     * 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::modb::ObjectListener* listener)
    {
        registerListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Unregister a listener from updates to this class.
     * 
     * @param framework the framework instance 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::unregisterListener(framework, listener, CLASS_ID);
    }

    /**
     * Unregister a listener from updates to this class from the
     * default framework instance
     * 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::modb::ObjectListener* listener)
    {
        unregisterListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Construct an instance of RoutingDomain.
     * This should not typically be called from user code.
     */
    RoutingDomain(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri,
        const boost::shared_ptr<const opflex::modb::mointernal::ObjectInstance>& oi)
        : MO(framework, CLASS_ID, uri, oi) { }
}; // class RoutingDomain

} // namespace gbp
} // namespace modelgbp
#endif // GI_GBP_ROUTINGDOMAIN_HPP
