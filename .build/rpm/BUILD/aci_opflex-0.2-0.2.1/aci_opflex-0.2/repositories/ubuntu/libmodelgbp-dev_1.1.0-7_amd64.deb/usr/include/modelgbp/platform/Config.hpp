/**
 * 
 * SOME COPYRIGHT
 * 
 * Config.hpp
 * 
 * generated Config.hpp file genie code generation framework free of license.
 *  
 */
#pragma once
#ifndef GI_PLATFORM_CONFIG_HPP
#define GI_PLATFORM_CONFIG_HPP

#include <boost/optional.hpp>
#include "opflex/modb/URIBuilder.h"
#include "opflex/modb/mo-internal/MO.h"
/*
 * contains: item:mclass(gbpe/SNATIPPool)
 */
#include "modelgbp/gbpe/SNATIPPool.hpp"
/*
 * contains: item:mclass(cdp/Config)
 */
#include "modelgbp/cdp/Config.hpp"
/*
 * contains: item:mclass(dfw/Config)
 */
#include "modelgbp/dfw/Config.hpp"
/*
 * contains: item:mclass(domain/ConfigFromConfigRTgt)
 */
#include "modelgbp/domain/ConfigFromConfigRTgt.hpp"
/*
 * contains: item:mclass(l2/Config)
 */
#include "modelgbp/l2/Config.hpp"
/*
 * contains: item:mclass(lacp/Config)
 */
#include "modelgbp/lacp/Config.hpp"
/*
 * contains: item:mclass(lldp/Config)
 */
#include "modelgbp/lldp/Config.hpp"
/*
 * contains: item:mclass(span/SrcGrp)
 */
#include "modelgbp/span/SrcGrp.hpp"
/*
 * contains: item:mclass(span/DstGrp)
 */
#include "modelgbp/span/DstGrp.hpp"
/*
 * contains: item:mclass(span/LocalEp)
 */
#include "modelgbp/span/LocalEp.hpp"
/*
 * contains: item:mclass(stp/Config)
 */
#include "modelgbp/stp/Config.hpp"

namespace modelgbp {
namespace platform {

class Config
    : public opflex::modb::mointernal::MO
{
public:

    /**
     * The unique class ID for Config
     */
    static const opflex::modb::class_id_t CLASS_ID = 36;

    /**
     * Check whether encapType has been set
     * @return true if encapType has been set
     */
    bool isEncapTypeSet()
    {
        return getObjectInstance().isSet(1179650ul, opflex::modb::PropertyInfo::ENUM8);
    }

    /**
     * Get the value of encapType if it has been set.
     * @return the value of encapType or boost::none if not set
     */
    boost::optional<const uint8_t> getEncapType()
    {
        if (isEncapTypeSet())
            return (const uint8_t)getObjectInstance().getUInt64(1179650ul);
        return boost::none;
    }

    /**
     * Get the value of encapType if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of encapType if set, otherwise the value of default passed in
     */
    const uint8_t getEncapType(const uint8_t defaultValue)
    {
        return getEncapType().get_value_or(defaultValue);
    }

    /**
     * Set encapType to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::platform::Config& setEncapType(const uint8_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(1179650ul, newValue);
        return *this;
    }

    /**
     * Unset encapType in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::platform::Config& unsetEncapType()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1179650ul, opflex::modb::PropertyInfo::ENUM8, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether mode has been set
     * @return true if mode has been set
     */
    bool isModeSet()
    {
        return getObjectInstance().isSet(1179651ul, opflex::modb::PropertyInfo::ENUM8);
    }

    /**
     * Get the value of mode if it has been set.
     * @return the value of mode or boost::none if not set
     */
    boost::optional<const uint8_t> getMode()
    {
        if (isModeSet())
            return (const uint8_t)getObjectInstance().getUInt64(1179651ul);
        return boost::none;
    }

    /**
     * Get the value of mode if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of mode if set, otherwise the value of default passed in
     */
    const uint8_t getMode(const uint8_t defaultValue)
    {
        return getMode().get_value_or(defaultValue);
    }

    /**
     * Set mode to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::platform::Config& setMode(const uint8_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(1179651ul, newValue);
        return *this;
    }

    /**
     * Unset mode in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::platform::Config& unsetMode()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1179651ul, opflex::modb::PropertyInfo::ENUM8, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether multicastGroupIP has been set
     * @return true if multicastGroupIP has been set
     */
    bool isMulticastGroupIPSet()
    {
        return getObjectInstance().isSet(1179652ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of multicastGroupIP if it has been set.
     * @return the value of multicastGroupIP or boost::none if not set
     */
    boost::optional<const std::string&> getMulticastGroupIP()
    {
        if (isMulticastGroupIPSet())
            return getObjectInstance().getString(1179652ul);
        return boost::none;
    }

    /**
     * Get the value of multicastGroupIP if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of multicastGroupIP if set, otherwise the value of default passed in
     */
    const std::string& getMulticastGroupIP(const std::string& defaultValue)
    {
        return getMulticastGroupIP().get_value_or(defaultValue);
    }

    /**
     * Set multicastGroupIP to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::platform::Config& setMulticastGroupIP(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(1179652ul, newValue);
        return *this;
    }

    /**
     * Unset multicastGroupIP in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::platform::Config& unsetMulticastGroupIP()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1179652ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether name has been set
     * @return true if name has been set
     */
    bool isNameSet()
    {
        return getObjectInstance().isSet(1179649ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of name if it has been set.
     * @return the value of name or boost::none if not set
     */
    boost::optional<const std::string&> getName()
    {
        if (isNameSet())
            return getObjectInstance().getString(1179649ul);
        return boost::none;
    }

    /**
     * Get the value of name if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of name if set, otherwise the value of default passed in
     */
    const std::string& getName(const std::string& defaultValue)
    {
        return getName().get_value_or(defaultValue);
    }

    /**
     * Set name to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::platform::Config& setName(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(1179649ul, newValue);
        return *this;
    }

    /**
     * Unset name in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::platform::Config& unsetName()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1179649ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Retrieve an instance of Config from the managed
     * object store.  If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::platform::Config> > resolve(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::platform::Config>(framework, CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of Config from the managed
     * object store using the default framework instance.  If the 
     * object does not exist in the local store, returns boost::none. 
     * Note that even though it may not exist locally, it may still 
     * exist remotely.
     * 
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::platform::Config> > resolve(
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::platform::Config>(opflex::ofcore::OFFramework::defaultInstance(), CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of Config from the managed
     * object store by constructing its URI from the path elements
     * that lead to it.  If the object does not exist in the local
     * store, returns boost::none.  Note that even though it may not
     * exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PlatformConfig/[platformConfigName]
     * 
     * @param framework the framework instance to use 
     * @param platformConfigName the value of platformConfigName,
     * a naming property for Config
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::platform::Config> > resolve(
        opflex::ofcore::OFFramework& framework,
        const std::string& platformConfigName)
    {
        return resolve(framework,opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PlatformConfig").addElement(platformConfigName).build());
    }

    /**
     * Retrieve an instance of Config from the 
     * default managed object store by constructing its URI from the
     * path elements that lead to it.  If the object does not exist in
     * the local store, returns boost::none.  Note that even though it
     * may not exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PlatformConfig/[platformConfigName]
     * 
     * @param platformConfigName the value of platformConfigName,
     * a naming property for Config
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::platform::Config> > resolve(
        const std::string& platformConfigName)
    {
        return resolve(opflex::ofcore::OFFramework::defaultInstance(),platformConfigName);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param gbpeSNATIPPoolName the value of gbpeSNATIPPoolName,
     * a naming property for SNATIPPool
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbpe::SNATIPPool> > resolveGbpeSNATIPPool(
        const std::string& gbpeSNATIPPoolName)
    {
        return modelgbp::gbpe::SNATIPPool::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpeSNATIPPool").addElement(gbpeSNATIPPoolName).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param gbpeSNATIPPoolName the value of gbpeSNATIPPoolName,
     * a naming property for SNATIPPool
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbpe::SNATIPPool> addGbpeSNATIPPool(
        const std::string& gbpeSNATIPPoolName)
    {
        boost::shared_ptr<modelgbp::gbpe::SNATIPPool> result = addChild<modelgbp::gbpe::SNATIPPool>(
            CLASS_ID, getURI(), 2148663331ul, 35,
            opflex::modb::URIBuilder(getURI()).addElement("GbpeSNATIPPool").addElement(gbpeSNATIPPoolName).build()
            );
        result->setName(gbpeSNATIPPoolName);
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::gbpe::SNATIPPool
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveGbpeSNATIPPool(/* out */ std::vector<boost::shared_ptr<modelgbp::gbpe::SNATIPPool> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::gbpe::SNATIPPool>(
            getFramework(), CLASS_ID, getURI(), 2148663331ul, 35, out);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::cdp::Config> > resolveCdpConfig(
        )
    {
        return modelgbp::cdp::Config::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("CdpConfig").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::cdp::Config> addCdpConfig(
        )
    {
        boost::shared_ptr<modelgbp::cdp::Config> result = addChild<modelgbp::cdp::Config>(
            CLASS_ID, getURI(), 2148663334ul, 38,
            opflex::modb::URIBuilder(getURI()).addElement("CdpConfig").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::dfw::Config> > resolveDfwConfig(
        )
    {
        return modelgbp::dfw::Config::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("DfwConfig").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::dfw::Config> addDfwConfig(
        )
    {
        boost::shared_ptr<modelgbp::dfw::Config> result = addChild<modelgbp::dfw::Config>(
            CLASS_ID, getURI(), 2148663335ul, 39,
            opflex::modb::URIBuilder(getURI()).addElement("DfwConfig").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param domainConfigFromConfigRTgtSource the value of domainConfigFromConfigRTgtSource,
     * a naming property for ConfigFromConfigRTgt
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::domain::ConfigFromConfigRTgt> > resolveDomainConfigFromConfigRTgt(
        const std::string& domainConfigFromConfigRTgtSource)
    {
        return modelgbp::domain::ConfigFromConfigRTgt::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("DomainConfigFromConfigRTgt").addElement(domainConfigFromConfigRTgtSource).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param domainConfigFromConfigRTgtSource the value of domainConfigFromConfigRTgtSource,
     * a naming property for ConfigFromConfigRTgt
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::domain::ConfigFromConfigRTgt> addDomainConfigFromConfigRTgt(
        const std::string& domainConfigFromConfigRTgtSource)
    {
        boost::shared_ptr<modelgbp::domain::ConfigFromConfigRTgt> result = addChild<modelgbp::domain::ConfigFromConfigRTgt>(
            CLASS_ID, getURI(), 2148663339ul, 43,
            opflex::modb::URIBuilder(getURI()).addElement("DomainConfigFromConfigRTgt").addElement(domainConfigFromConfigRTgtSource).build()
            );
        result->setSource(domainConfigFromConfigRTgtSource);
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::domain::ConfigFromConfigRTgt
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveDomainConfigFromConfigRTgt(/* out */ std::vector<boost::shared_ptr<modelgbp::domain::ConfigFromConfigRTgt> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::domain::ConfigFromConfigRTgt>(
            getFramework(), CLASS_ID, getURI(), 2148663339ul, 43, out);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::l2::Config> > resolveL2Config(
        )
    {
        return modelgbp::l2::Config::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("L2Config").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::l2::Config> addL2Config(
        )
    {
        boost::shared_ptr<modelgbp::l2::Config> result = addChild<modelgbp::l2::Config>(
            CLASS_ID, getURI(), 2148663341ul, 45,
            opflex::modb::URIBuilder(getURI()).addElement("L2Config").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::lacp::Config> > resolveLacpConfig(
        )
    {
        return modelgbp::lacp::Config::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("LacpConfig").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::lacp::Config> addLacpConfig(
        )
    {
        boost::shared_ptr<modelgbp::lacp::Config> result = addChild<modelgbp::lacp::Config>(
            CLASS_ID, getURI(), 2148663342ul, 46,
            opflex::modb::URIBuilder(getURI()).addElement("LacpConfig").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::lldp::Config> > resolveLldpConfig(
        )
    {
        return modelgbp::lldp::Config::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("LldpConfig").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::lldp::Config> addLldpConfig(
        )
    {
        boost::shared_ptr<modelgbp::lldp::Config> result = addChild<modelgbp::lldp::Config>(
            CLASS_ID, getURI(), 2148663343ul, 47,
            opflex::modb::URIBuilder(getURI()).addElement("LldpConfig").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param spanSrcGrpName the value of spanSrcGrpName,
     * a naming property for SrcGrp
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::span::SrcGrp> > resolveSpanSrcGrp(
        const std::string& spanSrcGrpName)
    {
        return modelgbp::span::SrcGrp::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("SpanSrcGrp").addElement(spanSrcGrpName).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param spanSrcGrpName the value of spanSrcGrpName,
     * a naming property for SrcGrp
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::span::SrcGrp> addSpanSrcGrp(
        const std::string& spanSrcGrpName)
    {
        boost::shared_ptr<modelgbp::span::SrcGrp> result = addChild<modelgbp::span::SrcGrp>(
            CLASS_ID, getURI(), 2148663345ul, 49,
            opflex::modb::URIBuilder(getURI()).addElement("SpanSrcGrp").addElement(spanSrcGrpName).build()
            );
        result->setName(spanSrcGrpName);
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::span::SrcGrp
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveSpanSrcGrp(/* out */ std::vector<boost::shared_ptr<modelgbp::span::SrcGrp> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::span::SrcGrp>(
            getFramework(), CLASS_ID, getURI(), 2148663345ul, 49, out);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param spanDstGrpName the value of spanDstGrpName,
     * a naming property for DstGrp
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::span::DstGrp> > resolveSpanDstGrp(
        const std::string& spanDstGrpName)
    {
        return modelgbp::span::DstGrp::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("SpanDstGrp").addElement(spanDstGrpName).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param spanDstGrpName the value of spanDstGrpName,
     * a naming property for DstGrp
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::span::DstGrp> addSpanDstGrp(
        const std::string& spanDstGrpName)
    {
        boost::shared_ptr<modelgbp::span::DstGrp> result = addChild<modelgbp::span::DstGrp>(
            CLASS_ID, getURI(), 2148663346ul, 50,
            opflex::modb::URIBuilder(getURI()).addElement("SpanDstGrp").addElement(spanDstGrpName).build()
            );
        result->setName(spanDstGrpName);
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::span::DstGrp
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveSpanDstGrp(/* out */ std::vector<boost::shared_ptr<modelgbp::span::DstGrp> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::span::DstGrp>(
            getFramework(), CLASS_ID, getURI(), 2148663346ul, 50, out);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param spanLocalEpName the value of spanLocalEpName,
     * a naming property for LocalEp
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::span::LocalEp> > resolveSpanLocalEp(
        const std::string& spanLocalEpName)
    {
        return modelgbp::span::LocalEp::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("SpanLocalEp").addElement(spanLocalEpName).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param spanLocalEpName the value of spanLocalEpName,
     * a naming property for LocalEp
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::span::LocalEp> addSpanLocalEp(
        const std::string& spanLocalEpName)
    {
        boost::shared_ptr<modelgbp::span::LocalEp> result = addChild<modelgbp::span::LocalEp>(
            CLASS_ID, getURI(), 2148663347ul, 51,
            opflex::modb::URIBuilder(getURI()).addElement("SpanLocalEp").addElement(spanLocalEpName).build()
            );
        result->setName(spanLocalEpName);
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::span::LocalEp
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveSpanLocalEp(/* out */ std::vector<boost::shared_ptr<modelgbp::span::LocalEp> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::span::LocalEp>(
            getFramework(), CLASS_ID, getURI(), 2148663347ul, 51, out);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::stp::Config> > resolveStpConfig(
        )
    {
        return modelgbp::stp::Config::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("StpConfig").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::stp::Config> addStpConfig(
        )
    {
        boost::shared_ptr<modelgbp::stp::Config> result = addChild<modelgbp::stp::Config>(
            CLASS_ID, getURI(), 2148663358ul, 62,
            opflex::modb::URIBuilder(getURI()).addElement("StpConfig").build()
            );
        return result;
    }

    /**
     * Remove this instance using the currently-active mutator.  If
     * the object does not exist, then this will be a no-op.  If this
     * object has any children, they will be garbage-collected at some
     * future time.
     * 
     * @throws std::logic_error if no mutator is active
     */
    void remove()
    {
        getTLMutator().remove(CLASS_ID, getURI());
    }

    /**
     * Remove the Config object with the specified URI
     * using the currently-active mutator.  If the object does not exist,
     * then this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(opflex::ofcore::OFFramework& framework,
                       const opflex::modb::URI& uri)
    {
        MO::remove(framework, CLASS_ID, uri);
    }

    /**
     * Remove the Config object with the specified URI 
     * using the currently-active mutator and the default framework 
     * instance.  If the object does not exist, then this will be a
     * no-op.  If this object has any children, they will be 
     * garbage-collected at some future time.
     * 
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(const opflex::modb::URI& uri)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(), uri);
    }

    /**
     * Remove the Config object with the specified path
     * elements from the managed object store.  If the object does
     * not exist, then this will be a no-op.  If this object has any
     * children, they will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PlatformConfig/[platformConfigName]
     * 
     * @param framework the framework instance to use
     * @param platformConfigName the value of platformConfigName,
     * a naming property for Config
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        opflex::ofcore::OFFramework& framework,
        const std::string& platformConfigName)
    {
        MO::remove(framework, CLASS_ID, opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PlatformConfig").addElement(platformConfigName).build());
    }

    /**
     * Remove the Config object with the specified path
     * elements from the managed object store using the default
     * framework instance.  If the object does not exist, then
     * this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PlatformConfig/[platformConfigName]
     * 
     * @param platformConfigName the value of platformConfigName,
     * a naming property for Config
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        const std::string& platformConfigName)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(),platformConfigName);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class.  This listener will be called for any modifications
     * of this class or any transitive children of this class.
     * 
     * @param framework the framework instance 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::registerListener(framework, listener, CLASS_ID);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class with the default framework instance.  This listener
     * will be called for any modifications of this class or any
     * transitive children of this class.
     * 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::modb::ObjectListener* listener)
    {
        registerListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Unregister a listener from updates to this class.
     * 
     * @param framework the framework instance 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::unregisterListener(framework, listener, CLASS_ID);
    }

    /**
     * Unregister a listener from updates to this class from the
     * default framework instance
     * 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::modb::ObjectListener* listener)
    {
        unregisterListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Construct an instance of Config.
     * This should not typically be called from user code.
     */
    Config(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri,
        const boost::shared_ptr<const opflex::modb::mointernal::ObjectInstance>& oi)
        : MO(framework, CLASS_ID, uri, oi) { }
}; // class Config

} // namespace platform
} // namespace modelgbp
#endif // GI_PLATFORM_CONFIG_HPP
