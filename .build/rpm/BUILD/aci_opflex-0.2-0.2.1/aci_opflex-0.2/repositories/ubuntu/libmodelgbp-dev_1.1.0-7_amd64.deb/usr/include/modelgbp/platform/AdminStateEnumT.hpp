/**
 * 
 * SOME COPYRIGHT
 * 
 * AdminStateEnumT.hpp
 * 
 * generated AdminStateEnumT.hpp file genie code generation framework free of license.
 *  
 */
#include <boost/cstdint.hpp>
#include <cstddef>
namespace modelgbp {
namespace platform {
    struct AdminStateEnumT {
        static const uint8_t CONST_OFF = 0;
        static const uint8_t CONST_ON = 1;
    };
}
}
