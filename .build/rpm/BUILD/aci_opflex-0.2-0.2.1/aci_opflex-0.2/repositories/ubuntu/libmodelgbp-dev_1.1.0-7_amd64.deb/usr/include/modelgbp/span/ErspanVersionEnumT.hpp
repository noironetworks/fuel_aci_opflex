/**
 * 
 * SOME COPYRIGHT
 * 
 * ErspanVersionEnumT.hpp
 * 
 * generated ErspanVersionEnumT.hpp file genie code generation framework free of license.
 *  
 */
#include <boost/cstdint.hpp>
#include <cstddef>
namespace modelgbp {
namespace span {
    struct ErspanVersionEnumT {
        static const uint8_t CONST_V1 = 1;
        static const uint8_t CONST_V2 = 2;
    };
}
}
