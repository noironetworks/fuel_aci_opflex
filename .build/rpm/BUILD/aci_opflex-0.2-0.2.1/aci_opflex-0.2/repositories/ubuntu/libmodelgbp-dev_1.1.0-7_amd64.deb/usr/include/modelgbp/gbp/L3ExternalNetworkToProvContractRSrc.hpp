/**
 * 
 * SOME COPYRIGHT
 * 
 * L3ExternalNetworkToProvContractRSrc.hpp
 * 
 * generated L3ExternalNetworkToProvContractRSrc.hpp file genie code generation framework free of license.
 *  
 */
#pragma once
#ifndef GI_GBP_L3EXTERNALNETWORKTOPROVCONTRACTRSRC_HPP
#define GI_GBP_L3EXTERNALNETWORKTOPROVCONTRACTRSRC_HPP

#include <boost/optional.hpp>
#include "opflex/modb/URIBuilder.h"
#include "opflex/modb/mo-internal/MO.h"

namespace modelgbp {
namespace gbp {

class L3ExternalNetworkToProvContractRSrc
    : public opflex::modb::mointernal::MO
{
public:

    /**
     * The unique class ID for L3ExternalNetworkToProvContractRSrc
     */
    static const opflex::modb::class_id_t CLASS_ID = 121;

    /**
     * Check whether role has been set
     * @return true if role has been set
     */
    bool isRoleSet()
    {
        return getObjectInstance().isSet(3964930ul, opflex::modb::PropertyInfo::ENUM8);
    }

    /**
     * Get the value of role if it has been set.
     * @return the value of role or boost::none if not set
     */
    boost::optional<const uint8_t> getRole()
    {
        if (isRoleSet())
            return (const uint8_t)getObjectInstance().getUInt64(3964930ul);
        return boost::none;
    }

    /**
     * Get the value of role if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of role if set, otherwise the value of default passed in
     */
    const uint8_t getRole(const uint8_t defaultValue)
    {
        return getRole().get_value_or(defaultValue);
    }

    /**
     * Set role to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::L3ExternalNetworkToProvContractRSrc& setRole(const uint8_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(3964930ul, newValue);
        return *this;
    }

    /**
     * Unset role in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::L3ExternalNetworkToProvContractRSrc& unsetRole()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(3964930ul, opflex::modb::PropertyInfo::ENUM8, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether target has been set
     * @return true if target has been set
     */
    bool isTargetSet()
    {
        return getObjectInstance().isSet(3964931ul, opflex::modb::PropertyInfo::REFERENCE);
    }

    /**
     * Get the value of targetClass if it has been set.
     * @return the value of targetClass or boost::none if not set
     */
    boost::optional<opflex::modb::class_id_t> getTargetClass()
    {
        if (isTargetSet())
            return getObjectInstance().getReference(3964931ul).first;
        return boost::none;
    }

    /**
     * Get the value of targetURI if it has been set.
     * @return the value of targetURI or boost::none if not set
     */
    boost::optional<opflex::modb::URI> getTargetURI()
    {
        if (isTargetSet())
            return getObjectInstance().getReference(3964931ul).second;
        return boost::none;
    }

    /**
     * Get the value of targetClass if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of targetClass if set, otherwise the value of default passed in
     */
    opflex::modb::class_id_t getTargetClass(opflex::modb::class_id_t defaultValue)
    {
        return getTargetClass().get_value_or(defaultValue);
    }

    /**
     * Get the value of targetURI if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of targetURI if set, otherwise the value of default passed in
     */
    opflex::modb::URI getTargetURI(opflex::modb::URI defaultValue)
    {
        return getTargetURI().get_value_or(defaultValue);
    }

    /**
     * Set the reference to point to an instance of Contract
     * with the specified URI
     * 
     * @param uri The URI of the reference to add
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::L3ExternalNetworkToProvContractRSrc& setTargetContract(const opflex::modb::URI& uri)
    {
        getTLMutator().modify(getClassId(), getURI())->setReference(3964931ul, 97, uri);
        return *this;
    }

    /**
     * Set the reference to point to an instance of Contract
     * in the currently-active mutator by constructing its URI from the
     * path elements that lead to it.
     * 
     * The reference URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpContract/[gbpContractName]
     * 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpContractName the value of gbpContractName,
     * a naming property for Contract
     * 
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::L3ExternalNetworkToProvContractRSrc& setTargetContract(
        const std::string& policySpaceName,
        const std::string& gbpContractName)
    {
        getTLMutator().modify(getClassId(), getURI())->setReference(3964931ul, 97, opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PolicySpace").addElement(policySpaceName).addElement("GbpContract").addElement(gbpContractName).build());
        return *this;
    }

    /**
     * Unset target in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::L3ExternalNetworkToProvContractRSrc& unsetTarget()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(3964931ul, opflex::modb::PropertyInfo::REFERENCE, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether type has been set
     * @return true if type has been set
     */
    bool isTypeSet()
    {
        return getObjectInstance().isSet(3964929ul, opflex::modb::PropertyInfo::ENUM8);
    }

    /**
     * Get the value of type if it has been set.
     * @return the value of type or boost::none if not set
     */
    boost::optional<const uint8_t> getType()
    {
        if (isTypeSet())
            return (const uint8_t)getObjectInstance().getUInt64(3964929ul);
        return boost::none;
    }

    /**
     * Get the value of type if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of type if set, otherwise the value of default passed in
     */
    const uint8_t getType(const uint8_t defaultValue)
    {
        return getType().get_value_or(defaultValue);
    }

    /**
     * Set type to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::L3ExternalNetworkToProvContractRSrc& setType(const uint8_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(3964929ul, newValue);
        return *this;
    }

    /**
     * Unset type in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::L3ExternalNetworkToProvContractRSrc& unsetType()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(3964929ul, opflex::modb::PropertyInfo::ENUM8, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Retrieve an instance of L3ExternalNetworkToProvContractRSrc from the managed
     * object store.  If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::L3ExternalNetworkToProvContractRSrc> > resolve(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::gbp::L3ExternalNetworkToProvContractRSrc>(framework, CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of L3ExternalNetworkToProvContractRSrc from the managed
     * object store using the default framework instance.  If the 
     * object does not exist in the local store, returns boost::none. 
     * Note that even though it may not exist locally, it may still 
     * exist remotely.
     * 
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::L3ExternalNetworkToProvContractRSrc> > resolve(
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::gbp::L3ExternalNetworkToProvContractRSrc>(opflex::ofcore::OFFramework::defaultInstance(), CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of L3ExternalNetworkToProvContractRSrc from the managed
     * object store by constructing its URI from the path elements
     * that lead to it.  If the object does not exist in the local
     * store, returns boost::none.  Note that even though it may not
     * exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpRoutingDomain/[gbpRoutingDomainName]/GbpL3ExternalDomain/[gbpL3ExternalDomainName]/GbpL3ExternalNetwork/[gbpL3ExternalNetworkName]/GbpL3ExternalNetworkToProvContractRSrc/[gbpL3ExternalNetworkToProvContractRSrcTargetClass]/[gbpL3ExternalNetworkToProvContractRSrcTargetName]
     * 
     * @param framework the framework instance to use 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpRoutingDomainName the value of gbpRoutingDomainName,
     * a naming property for RoutingDomain
     * @param gbpL3ExternalDomainName the value of gbpL3ExternalDomainName,
     * a naming property for L3ExternalDomain
     * @param gbpL3ExternalNetworkName the value of gbpL3ExternalNetworkName,
     * a naming property for L3ExternalNetwork
     * @param gbpL3ExternalNetworkToProvContractRSrcTargetClass the value of gbpL3ExternalNetworkToProvContractRSrcTargetClass,
     * a naming property for L3ExternalNetworkToProvContractRSrc
     * @param gbpL3ExternalNetworkToProvContractRSrcTargetName the value of gbpL3ExternalNetworkToProvContractRSrcTargetName,
     * a naming property for L3ExternalNetworkToProvContractRSrc
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::L3ExternalNetworkToProvContractRSrc> > resolve(
        opflex::ofcore::OFFramework& framework,
        const std::string& policySpaceName,
        const std::string& gbpRoutingDomainName,
        const std::string& gbpL3ExternalDomainName,
        const std::string& gbpL3ExternalNetworkName,
        uint16_t gbpL3ExternalNetworkToProvContractRSrcTargetClass,
        const std::string& gbpL3ExternalNetworkToProvContractRSrcTargetName)
    {
        return resolve(framework,opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PolicySpace").addElement(policySpaceName).addElement("GbpRoutingDomain").addElement(gbpRoutingDomainName).addElement("GbpL3ExternalDomain").addElement(gbpL3ExternalDomainName).addElement("GbpL3ExternalNetwork").addElement(gbpL3ExternalNetworkName).addElement("GbpL3ExternalNetworkToProvContractRSrc").addElement(gbpL3ExternalNetworkToProvContractRSrcTargetClass).addElement(gbpL3ExternalNetworkToProvContractRSrcTargetName).build());
    }

    /**
     * Retrieve an instance of L3ExternalNetworkToProvContractRSrc from the 
     * default managed object store by constructing its URI from the
     * path elements that lead to it.  If the object does not exist in
     * the local store, returns boost::none.  Note that even though it
     * may not exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpRoutingDomain/[gbpRoutingDomainName]/GbpL3ExternalDomain/[gbpL3ExternalDomainName]/GbpL3ExternalNetwork/[gbpL3ExternalNetworkName]/GbpL3ExternalNetworkToProvContractRSrc/[gbpL3ExternalNetworkToProvContractRSrcTargetClass]/[gbpL3ExternalNetworkToProvContractRSrcTargetName]
     * 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpRoutingDomainName the value of gbpRoutingDomainName,
     * a naming property for RoutingDomain
     * @param gbpL3ExternalDomainName the value of gbpL3ExternalDomainName,
     * a naming property for L3ExternalDomain
     * @param gbpL3ExternalNetworkName the value of gbpL3ExternalNetworkName,
     * a naming property for L3ExternalNetwork
     * @param gbpL3ExternalNetworkToProvContractRSrcTargetClass the value of gbpL3ExternalNetworkToProvContractRSrcTargetClass,
     * a naming property for L3ExternalNetworkToProvContractRSrc
     * @param gbpL3ExternalNetworkToProvContractRSrcTargetName the value of gbpL3ExternalNetworkToProvContractRSrcTargetName,
     * a naming property for L3ExternalNetworkToProvContractRSrc
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::L3ExternalNetworkToProvContractRSrc> > resolve(
        const std::string& policySpaceName,
        const std::string& gbpRoutingDomainName,
        const std::string& gbpL3ExternalDomainName,
        const std::string& gbpL3ExternalNetworkName,
        uint16_t gbpL3ExternalNetworkToProvContractRSrcTargetClass,
        const std::string& gbpL3ExternalNetworkToProvContractRSrcTargetName)
    {
        return resolve(opflex::ofcore::OFFramework::defaultInstance(),policySpaceName,gbpRoutingDomainName,gbpL3ExternalDomainName,gbpL3ExternalNetworkName,gbpL3ExternalNetworkToProvContractRSrcTargetClass,gbpL3ExternalNetworkToProvContractRSrcTargetName);
    }

    /**
     * Remove this instance using the currently-active mutator.  If
     * the object does not exist, then this will be a no-op.  If this
     * object has any children, they will be garbage-collected at some
     * future time.
     * 
     * @throws std::logic_error if no mutator is active
     */
    void remove()
    {
        getTLMutator().remove(CLASS_ID, getURI());
    }

    /**
     * Remove the L3ExternalNetworkToProvContractRSrc object with the specified URI
     * using the currently-active mutator.  If the object does not exist,
     * then this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(opflex::ofcore::OFFramework& framework,
                       const opflex::modb::URI& uri)
    {
        MO::remove(framework, CLASS_ID, uri);
    }

    /**
     * Remove the L3ExternalNetworkToProvContractRSrc object with the specified URI 
     * using the currently-active mutator and the default framework 
     * instance.  If the object does not exist, then this will be a
     * no-op.  If this object has any children, they will be 
     * garbage-collected at some future time.
     * 
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(const opflex::modb::URI& uri)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(), uri);
    }

    /**
     * Remove the L3ExternalNetworkToProvContractRSrc object with the specified path
     * elements from the managed object store.  If the object does
     * not exist, then this will be a no-op.  If this object has any
     * children, they will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpRoutingDomain/[gbpRoutingDomainName]/GbpL3ExternalDomain/[gbpL3ExternalDomainName]/GbpL3ExternalNetwork/[gbpL3ExternalNetworkName]/GbpL3ExternalNetworkToProvContractRSrc/[gbpL3ExternalNetworkToProvContractRSrcTargetClass]/[gbpL3ExternalNetworkToProvContractRSrcTargetName]
     * 
     * @param framework the framework instance to use
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpRoutingDomainName the value of gbpRoutingDomainName,
     * a naming property for RoutingDomain
     * @param gbpL3ExternalDomainName the value of gbpL3ExternalDomainName,
     * a naming property for L3ExternalDomain
     * @param gbpL3ExternalNetworkName the value of gbpL3ExternalNetworkName,
     * a naming property for L3ExternalNetwork
     * @param gbpL3ExternalNetworkToProvContractRSrcTargetClass the value of gbpL3ExternalNetworkToProvContractRSrcTargetClass,
     * a naming property for L3ExternalNetworkToProvContractRSrc
     * @param gbpL3ExternalNetworkToProvContractRSrcTargetName the value of gbpL3ExternalNetworkToProvContractRSrcTargetName,
     * a naming property for L3ExternalNetworkToProvContractRSrc
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        opflex::ofcore::OFFramework& framework,
        const std::string& policySpaceName,
        const std::string& gbpRoutingDomainName,
        const std::string& gbpL3ExternalDomainName,
        const std::string& gbpL3ExternalNetworkName,
        uint16_t gbpL3ExternalNetworkToProvContractRSrcTargetClass,
        const std::string& gbpL3ExternalNetworkToProvContractRSrcTargetName)
    {
        MO::remove(framework, CLASS_ID, opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PolicySpace").addElement(policySpaceName).addElement("GbpRoutingDomain").addElement(gbpRoutingDomainName).addElement("GbpL3ExternalDomain").addElement(gbpL3ExternalDomainName).addElement("GbpL3ExternalNetwork").addElement(gbpL3ExternalNetworkName).addElement("GbpL3ExternalNetworkToProvContractRSrc").addElement(gbpL3ExternalNetworkToProvContractRSrcTargetClass).addElement(gbpL3ExternalNetworkToProvContractRSrcTargetName).build());
    }

    /**
     * Remove the L3ExternalNetworkToProvContractRSrc object with the specified path
     * elements from the managed object store using the default
     * framework instance.  If the object does not exist, then
     * this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpRoutingDomain/[gbpRoutingDomainName]/GbpL3ExternalDomain/[gbpL3ExternalDomainName]/GbpL3ExternalNetwork/[gbpL3ExternalNetworkName]/GbpL3ExternalNetworkToProvContractRSrc/[gbpL3ExternalNetworkToProvContractRSrcTargetClass]/[gbpL3ExternalNetworkToProvContractRSrcTargetName]
     * 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpRoutingDomainName the value of gbpRoutingDomainName,
     * a naming property for RoutingDomain
     * @param gbpL3ExternalDomainName the value of gbpL3ExternalDomainName,
     * a naming property for L3ExternalDomain
     * @param gbpL3ExternalNetworkName the value of gbpL3ExternalNetworkName,
     * a naming property for L3ExternalNetwork
     * @param gbpL3ExternalNetworkToProvContractRSrcTargetClass the value of gbpL3ExternalNetworkToProvContractRSrcTargetClass,
     * a naming property for L3ExternalNetworkToProvContractRSrc
     * @param gbpL3ExternalNetworkToProvContractRSrcTargetName the value of gbpL3ExternalNetworkToProvContractRSrcTargetName,
     * a naming property for L3ExternalNetworkToProvContractRSrc
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        const std::string& policySpaceName,
        const std::string& gbpRoutingDomainName,
        const std::string& gbpL3ExternalDomainName,
        const std::string& gbpL3ExternalNetworkName,
        uint16_t gbpL3ExternalNetworkToProvContractRSrcTargetClass,
        const std::string& gbpL3ExternalNetworkToProvContractRSrcTargetName)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(),policySpaceName,gbpRoutingDomainName,gbpL3ExternalDomainName,gbpL3ExternalNetworkName,gbpL3ExternalNetworkToProvContractRSrcTargetClass,gbpL3ExternalNetworkToProvContractRSrcTargetName);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class.  This listener will be called for any modifications
     * of this class or any transitive children of this class.
     * 
     * @param framework the framework instance 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::registerListener(framework, listener, CLASS_ID);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class with the default framework instance.  This listener
     * will be called for any modifications of this class or any
     * transitive children of this class.
     * 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::modb::ObjectListener* listener)
    {
        registerListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Unregister a listener from updates to this class.
     * 
     * @param framework the framework instance 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::unregisterListener(framework, listener, CLASS_ID);
    }

    /**
     * Unregister a listener from updates to this class from the
     * default framework instance
     * 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::modb::ObjectListener* listener)
    {
        unregisterListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Construct an instance of L3ExternalNetworkToProvContractRSrc.
     * This should not typically be called from user code.
     */
    L3ExternalNetworkToProvContractRSrc(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri,
        const boost::shared_ptr<const opflex::modb::mointernal::ObjectInstance>& oi)
        : MO(framework, CLASS_ID, uri, oi) { }
}; // class L3ExternalNetworkToProvContractRSrc

} // namespace gbp
} // namespace modelgbp
#endif // GI_GBP_L3EXTERNALNETWORKTOPROVCONTRACTRSRC_HPP
