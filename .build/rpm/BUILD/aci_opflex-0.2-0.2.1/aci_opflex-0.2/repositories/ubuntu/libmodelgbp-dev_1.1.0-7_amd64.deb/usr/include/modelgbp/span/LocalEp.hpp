/**
 * 
 * SOME COPYRIGHT
 * 
 * LocalEp.hpp
 * 
 * generated LocalEp.hpp file genie code generation framework free of license.
 *  
 */
#pragma once
#ifndef GI_SPAN_LOCALEP_HPP
#define GI_SPAN_LOCALEP_HPP

#include <boost/optional.hpp>
#include "opflex/modb/URIBuilder.h"
#include "opflex/modb/mo-internal/MO.h"
/*
 * contains: item:mclass(span/LocalEpToEpRSrc)
 */
#include "modelgbp/span/LocalEpToEpRSrc.hpp"
/*
 * contains: item:mclass(span/MemberFromRefRTgt)
 */
#include "modelgbp/span/MemberFromRefRTgt.hpp"

namespace modelgbp {
namespace span {

class LocalEp
    : public opflex::modb::mointernal::MO
{
public:

    /**
     * The unique class ID for LocalEp
     */
    static const opflex::modb::class_id_t CLASS_ID = 51;

    /**
     * Check whether name has been set
     * @return true if name has been set
     */
    bool isNameSet()
    {
        return getObjectInstance().isSet(1671169ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of name if it has been set.
     * @return the value of name or boost::none if not set
     */
    boost::optional<const std::string&> getName()
    {
        if (isNameSet())
            return getObjectInstance().getString(1671169ul);
        return boost::none;
    }

    /**
     * Get the value of name if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of name if set, otherwise the value of default passed in
     */
    const std::string& getName(const std::string& defaultValue)
    {
        return getName().get_value_or(defaultValue);
    }

    /**
     * Set name to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::span::LocalEp& setName(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(1671169ul, newValue);
        return *this;
    }

    /**
     * Unset name in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::span::LocalEp& unsetName()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1671169ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether nic has been set
     * @return true if nic has been set
     */
    bool isNicSet()
    {
        return getObjectInstance().isSet(1671170ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of nic if it has been set.
     * @return the value of nic or boost::none if not set
     */
    boost::optional<const std::string&> getNic()
    {
        if (isNicSet())
            return getObjectInstance().getString(1671170ul);
        return boost::none;
    }

    /**
     * Get the value of nic if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of nic if set, otherwise the value of default passed in
     */
    const std::string& getNic(const std::string& defaultValue)
    {
        return getNic().get_value_or(defaultValue);
    }

    /**
     * Set nic to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::span::LocalEp& setNic(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(1671170ul, newValue);
        return *this;
    }

    /**
     * Unset nic in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::span::LocalEp& unsetNic()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1671170ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Retrieve an instance of LocalEp from the managed
     * object store.  If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::span::LocalEp> > resolve(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::span::LocalEp>(framework, CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of LocalEp from the managed
     * object store using the default framework instance.  If the 
     * object does not exist in the local store, returns boost::none. 
     * Note that even though it may not exist locally, it may still 
     * exist remotely.
     * 
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::span::LocalEp> > resolve(
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::span::LocalEp>(opflex::ofcore::OFFramework::defaultInstance(), CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of LocalEp from the managed
     * object store by constructing its URI from the path elements
     * that lead to it.  If the object does not exist in the local
     * store, returns boost::none.  Note that even though it may not
     * exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PlatformConfig/[platformConfigName]/SpanLocalEp/[spanLocalEpName]
     * 
     * @param framework the framework instance to use 
     * @param platformConfigName the value of platformConfigName,
     * a naming property for Config
     * @param spanLocalEpName the value of spanLocalEpName,
     * a naming property for LocalEp
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::span::LocalEp> > resolve(
        opflex::ofcore::OFFramework& framework,
        const std::string& platformConfigName,
        const std::string& spanLocalEpName)
    {
        return resolve(framework,opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PlatformConfig").addElement(platformConfigName).addElement("SpanLocalEp").addElement(spanLocalEpName).build());
    }

    /**
     * Retrieve an instance of LocalEp from the 
     * default managed object store by constructing its URI from the
     * path elements that lead to it.  If the object does not exist in
     * the local store, returns boost::none.  Note that even though it
     * may not exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PlatformConfig/[platformConfigName]/SpanLocalEp/[spanLocalEpName]
     * 
     * @param platformConfigName the value of platformConfigName,
     * a naming property for Config
     * @param spanLocalEpName the value of spanLocalEpName,
     * a naming property for LocalEp
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::span::LocalEp> > resolve(
        const std::string& platformConfigName,
        const std::string& spanLocalEpName)
    {
        return resolve(opflex::ofcore::OFFramework::defaultInstance(),platformConfigName,spanLocalEpName);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::span::LocalEpToEpRSrc> > resolveSpanLocalEpToEpRSrc(
        )
    {
        return modelgbp::span::LocalEpToEpRSrc::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("SpanLocalEpToEpRSrc").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::span::LocalEpToEpRSrc> addSpanLocalEpToEpRSrc(
        )
    {
        boost::shared_ptr<modelgbp::span::LocalEpToEpRSrc> result = addChild<modelgbp::span::LocalEpToEpRSrc>(
            CLASS_ID, getURI(), 2149154868ul, 52,
            opflex::modb::URIBuilder(getURI()).addElement("SpanLocalEpToEpRSrc").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param spanMemberFromRefRTgtSource the value of spanMemberFromRefRTgtSource,
     * a naming property for MemberFromRefRTgt
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::span::MemberFromRefRTgt> > resolveSpanMemberFromRefRTgt(
        const std::string& spanMemberFromRefRTgtSource)
    {
        return modelgbp::span::MemberFromRefRTgt::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("SpanMemberFromRefRTgt").addElement(spanMemberFromRefRTgtSource).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param spanMemberFromRefRTgtSource the value of spanMemberFromRefRTgtSource,
     * a naming property for MemberFromRefRTgt
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::span::MemberFromRefRTgt> addSpanMemberFromRefRTgt(
        const std::string& spanMemberFromRefRTgtSource)
    {
        boost::shared_ptr<modelgbp::span::MemberFromRefRTgt> result = addChild<modelgbp::span::MemberFromRefRTgt>(
            CLASS_ID, getURI(), 2149154873ul, 57,
            opflex::modb::URIBuilder(getURI()).addElement("SpanMemberFromRefRTgt").addElement(spanMemberFromRefRTgtSource).build()
            );
        result->setSource(spanMemberFromRefRTgtSource);
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::span::MemberFromRefRTgt
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveSpanMemberFromRefRTgt(/* out */ std::vector<boost::shared_ptr<modelgbp::span::MemberFromRefRTgt> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::span::MemberFromRefRTgt>(
            getFramework(), CLASS_ID, getURI(), 2149154873ul, 57, out);
    }

    /**
     * Remove this instance using the currently-active mutator.  If
     * the object does not exist, then this will be a no-op.  If this
     * object has any children, they will be garbage-collected at some
     * future time.
     * 
     * @throws std::logic_error if no mutator is active
     */
    void remove()
    {
        getTLMutator().remove(CLASS_ID, getURI());
    }

    /**
     * Remove the LocalEp object with the specified URI
     * using the currently-active mutator.  If the object does not exist,
     * then this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(opflex::ofcore::OFFramework& framework,
                       const opflex::modb::URI& uri)
    {
        MO::remove(framework, CLASS_ID, uri);
    }

    /**
     * Remove the LocalEp object with the specified URI 
     * using the currently-active mutator and the default framework 
     * instance.  If the object does not exist, then this will be a
     * no-op.  If this object has any children, they will be 
     * garbage-collected at some future time.
     * 
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(const opflex::modb::URI& uri)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(), uri);
    }

    /**
     * Remove the LocalEp object with the specified path
     * elements from the managed object store.  If the object does
     * not exist, then this will be a no-op.  If this object has any
     * children, they will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PlatformConfig/[platformConfigName]/SpanLocalEp/[spanLocalEpName]
     * 
     * @param framework the framework instance to use
     * @param platformConfigName the value of platformConfigName,
     * a naming property for Config
     * @param spanLocalEpName the value of spanLocalEpName,
     * a naming property for LocalEp
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        opflex::ofcore::OFFramework& framework,
        const std::string& platformConfigName,
        const std::string& spanLocalEpName)
    {
        MO::remove(framework, CLASS_ID, opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PlatformConfig").addElement(platformConfigName).addElement("SpanLocalEp").addElement(spanLocalEpName).build());
    }

    /**
     * Remove the LocalEp object with the specified path
     * elements from the managed object store using the default
     * framework instance.  If the object does not exist, then
     * this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PlatformConfig/[platformConfigName]/SpanLocalEp/[spanLocalEpName]
     * 
     * @param platformConfigName the value of platformConfigName,
     * a naming property for Config
     * @param spanLocalEpName the value of spanLocalEpName,
     * a naming property for LocalEp
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        const std::string& platformConfigName,
        const std::string& spanLocalEpName)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(),platformConfigName,spanLocalEpName);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class.  This listener will be called for any modifications
     * of this class or any transitive children of this class.
     * 
     * @param framework the framework instance 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::registerListener(framework, listener, CLASS_ID);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class with the default framework instance.  This listener
     * will be called for any modifications of this class or any
     * transitive children of this class.
     * 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::modb::ObjectListener* listener)
    {
        registerListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Unregister a listener from updates to this class.
     * 
     * @param framework the framework instance 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::unregisterListener(framework, listener, CLASS_ID);
    }

    /**
     * Unregister a listener from updates to this class from the
     * default framework instance
     * 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::modb::ObjectListener* listener)
    {
        unregisterListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Construct an instance of LocalEp.
     * This should not typically be called from user code.
     */
    LocalEp(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri,
        const boost::shared_ptr<const opflex::modb::mointernal::ObjectInstance>& oi)
        : MO(framework, CLASS_ID, uri, oi) { }
}; // class LocalEp

} // namespace span
} // namespace modelgbp
#endif // GI_SPAN_LOCALEP_HPP
