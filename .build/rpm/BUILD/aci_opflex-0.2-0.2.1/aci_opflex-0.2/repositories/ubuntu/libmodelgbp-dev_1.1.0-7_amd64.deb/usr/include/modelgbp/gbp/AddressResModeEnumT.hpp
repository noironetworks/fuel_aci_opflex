/**
 * 
 * SOME COPYRIGHT
 * 
 * AddressResModeEnumT.hpp
 * 
 * generated AddressResModeEnumT.hpp file genie code generation framework free of license.
 *  
 */
#include <boost/cstdint.hpp>
#include <cstddef>
namespace modelgbp {
namespace gbp {
    struct AddressResModeEnumT {
        static const uint8_t CONST_DROP = 2;
        static const uint8_t CONST_FLOOD = 1;
        static const uint8_t CONST_UNICAST = 0;
    };
}
}
