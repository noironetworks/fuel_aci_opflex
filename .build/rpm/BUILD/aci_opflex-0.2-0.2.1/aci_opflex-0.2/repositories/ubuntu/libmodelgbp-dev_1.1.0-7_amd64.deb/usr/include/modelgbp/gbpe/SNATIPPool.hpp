/**
 * 
 * SOME COPYRIGHT
 * 
 * SNATIPPool.hpp
 * 
 * generated SNATIPPool.hpp file genie code generation framework free of license.
 *  
 */
#pragma once
#ifndef GI_GBPE_SNATIPPOOL_HPP
#define GI_GBPE_SNATIPPOOL_HPP

#include <boost/optional.hpp>
#include "opflex/modb/URIBuilder.h"
#include "opflex/modb/mo-internal/MO.h"

namespace modelgbp {
namespace gbpe {

class SNATIPPool
    : public opflex::modb::mointernal::MO
{
public:

    /**
     * The unique class ID for SNATIPPool
     */
    static const opflex::modb::class_id_t CLASS_ID = 35;

    /**
     * Check whether address has been set
     * @return true if address has been set
     */
    bool isAddressSet()
    {
        return getObjectInstance().isSet(1146882ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of address if it has been set.
     * @return the value of address or boost::none if not set
     */
    boost::optional<const std::string&> getAddress()
    {
        if (isAddressSet())
            return getObjectInstance().getString(1146882ul);
        return boost::none;
    }

    /**
     * Get the value of address if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of address if set, otherwise the value of default passed in
     */
    const std::string& getAddress(const std::string& defaultValue)
    {
        return getAddress().get_value_or(defaultValue);
    }

    /**
     * Set address to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::SNATIPPool& setAddress(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(1146882ul, newValue);
        return *this;
    }

    /**
     * Unset address in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::SNATIPPool& unsetAddress()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1146882ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether name has been set
     * @return true if name has been set
     */
    bool isNameSet()
    {
        return getObjectInstance().isSet(1146881ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of name if it has been set.
     * @return the value of name or boost::none if not set
     */
    boost::optional<const std::string&> getName()
    {
        if (isNameSet())
            return getObjectInstance().getString(1146881ul);
        return boost::none;
    }

    /**
     * Get the value of name if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of name if set, otherwise the value of default passed in
     */
    const std::string& getName(const std::string& defaultValue)
    {
        return getName().get_value_or(defaultValue);
    }

    /**
     * Set name to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::SNATIPPool& setName(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(1146881ul, newValue);
        return *this;
    }

    /**
     * Unset name in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::SNATIPPool& unsetName()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1146881ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether natEpGroup has been set
     * @return true if natEpGroup has been set
     */
    bool isNatEpGroupSet()
    {
        return getObjectInstance().isSet(1146885ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of natEpGroup if it has been set.
     * @return the value of natEpGroup or boost::none if not set
     */
    boost::optional<const std::string&> getNatEpGroup()
    {
        if (isNatEpGroupSet())
            return getObjectInstance().getString(1146885ul);
        return boost::none;
    }

    /**
     * Get the value of natEpGroup if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of natEpGroup if set, otherwise the value of default passed in
     */
    const std::string& getNatEpGroup(const std::string& defaultValue)
    {
        return getNatEpGroup().get_value_or(defaultValue);
    }

    /**
     * Set natEpGroup to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::SNATIPPool& setNatEpGroup(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(1146885ul, newValue);
        return *this;
    }

    /**
     * Unset natEpGroup in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::SNATIPPool& unsetNatEpGroup()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1146885ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether prefixLen has been set
     * @return true if prefixLen has been set
     */
    bool isPrefixLenSet()
    {
        return getObjectInstance().isSet(1146883ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of prefixLen if it has been set.
     * @return the value of prefixLen or boost::none if not set
     */
    boost::optional<const uint8_t> getPrefixLen()
    {
        if (isPrefixLenSet())
            return (const uint8_t)getObjectInstance().getUInt64(1146883ul);
        return boost::none;
    }

    /**
     * Get the value of prefixLen if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of prefixLen if set, otherwise the value of default passed in
     */
    const uint8_t getPrefixLen(const uint8_t defaultValue)
    {
        return getPrefixLen().get_value_or(defaultValue);
    }

    /**
     * Set prefixLen to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::SNATIPPool& setPrefixLen(const uint8_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(1146883ul, newValue);
        return *this;
    }

    /**
     * Unset prefixLen in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::SNATIPPool& unsetPrefixLen()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1146883ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether tunnelEpUuid has been set
     * @return true if tunnelEpUuid has been set
     */
    bool isTunnelEpUuidSet()
    {
        return getObjectInstance().isSet(1146884ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of tunnelEpUuid if it has been set.
     * @return the value of tunnelEpUuid or boost::none if not set
     */
    boost::optional<const std::string&> getTunnelEpUuid()
    {
        if (isTunnelEpUuidSet())
            return getObjectInstance().getString(1146884ul);
        return boost::none;
    }

    /**
     * Get the value of tunnelEpUuid if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of tunnelEpUuid if set, otherwise the value of default passed in
     */
    const std::string& getTunnelEpUuid(const std::string& defaultValue)
    {
        return getTunnelEpUuid().get_value_or(defaultValue);
    }

    /**
     * Set tunnelEpUuid to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::SNATIPPool& setTunnelEpUuid(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(1146884ul, newValue);
        return *this;
    }

    /**
     * Unset tunnelEpUuid in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::SNATIPPool& unsetTunnelEpUuid()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1146884ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Retrieve an instance of SNATIPPool from the managed
     * object store.  If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbpe::SNATIPPool> > resolve(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::gbpe::SNATIPPool>(framework, CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of SNATIPPool from the managed
     * object store using the default framework instance.  If the 
     * object does not exist in the local store, returns boost::none. 
     * Note that even though it may not exist locally, it may still 
     * exist remotely.
     * 
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbpe::SNATIPPool> > resolve(
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::gbpe::SNATIPPool>(opflex::ofcore::OFFramework::defaultInstance(), CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of SNATIPPool from the managed
     * object store by constructing its URI from the path elements
     * that lead to it.  If the object does not exist in the local
     * store, returns boost::none.  Note that even though it may not
     * exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PlatformConfig/[platformConfigName]/GbpeSNATIPPool/[gbpeSNATIPPoolName]
     * 
     * @param framework the framework instance to use 
     * @param platformConfigName the value of platformConfigName,
     * a naming property for Config
     * @param gbpeSNATIPPoolName the value of gbpeSNATIPPoolName,
     * a naming property for SNATIPPool
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbpe::SNATIPPool> > resolve(
        opflex::ofcore::OFFramework& framework,
        const std::string& platformConfigName,
        const std::string& gbpeSNATIPPoolName)
    {
        return resolve(framework,opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PlatformConfig").addElement(platformConfigName).addElement("GbpeSNATIPPool").addElement(gbpeSNATIPPoolName).build());
    }

    /**
     * Retrieve an instance of SNATIPPool from the 
     * default managed object store by constructing its URI from the
     * path elements that lead to it.  If the object does not exist in
     * the local store, returns boost::none.  Note that even though it
     * may not exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PlatformConfig/[platformConfigName]/GbpeSNATIPPool/[gbpeSNATIPPoolName]
     * 
     * @param platformConfigName the value of platformConfigName,
     * a naming property for Config
     * @param gbpeSNATIPPoolName the value of gbpeSNATIPPoolName,
     * a naming property for SNATIPPool
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbpe::SNATIPPool> > resolve(
        const std::string& platformConfigName,
        const std::string& gbpeSNATIPPoolName)
    {
        return resolve(opflex::ofcore::OFFramework::defaultInstance(),platformConfigName,gbpeSNATIPPoolName);
    }

    /**
     * Remove this instance using the currently-active mutator.  If
     * the object does not exist, then this will be a no-op.  If this
     * object has any children, they will be garbage-collected at some
     * future time.
     * 
     * @throws std::logic_error if no mutator is active
     */
    void remove()
    {
        getTLMutator().remove(CLASS_ID, getURI());
    }

    /**
     * Remove the SNATIPPool object with the specified URI
     * using the currently-active mutator.  If the object does not exist,
     * then this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(opflex::ofcore::OFFramework& framework,
                       const opflex::modb::URI& uri)
    {
        MO::remove(framework, CLASS_ID, uri);
    }

    /**
     * Remove the SNATIPPool object with the specified URI 
     * using the currently-active mutator and the default framework 
     * instance.  If the object does not exist, then this will be a
     * no-op.  If this object has any children, they will be 
     * garbage-collected at some future time.
     * 
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(const opflex::modb::URI& uri)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(), uri);
    }

    /**
     * Remove the SNATIPPool object with the specified path
     * elements from the managed object store.  If the object does
     * not exist, then this will be a no-op.  If this object has any
     * children, they will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PlatformConfig/[platformConfigName]/GbpeSNATIPPool/[gbpeSNATIPPoolName]
     * 
     * @param framework the framework instance to use
     * @param platformConfigName the value of platformConfigName,
     * a naming property for Config
     * @param gbpeSNATIPPoolName the value of gbpeSNATIPPoolName,
     * a naming property for SNATIPPool
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        opflex::ofcore::OFFramework& framework,
        const std::string& platformConfigName,
        const std::string& gbpeSNATIPPoolName)
    {
        MO::remove(framework, CLASS_ID, opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PlatformConfig").addElement(platformConfigName).addElement("GbpeSNATIPPool").addElement(gbpeSNATIPPoolName).build());
    }

    /**
     * Remove the SNATIPPool object with the specified path
     * elements from the managed object store using the default
     * framework instance.  If the object does not exist, then
     * this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PlatformConfig/[platformConfigName]/GbpeSNATIPPool/[gbpeSNATIPPoolName]
     * 
     * @param platformConfigName the value of platformConfigName,
     * a naming property for Config
     * @param gbpeSNATIPPoolName the value of gbpeSNATIPPoolName,
     * a naming property for SNATIPPool
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        const std::string& platformConfigName,
        const std::string& gbpeSNATIPPoolName)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(),platformConfigName,gbpeSNATIPPoolName);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class.  This listener will be called for any modifications
     * of this class or any transitive children of this class.
     * 
     * @param framework the framework instance 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::registerListener(framework, listener, CLASS_ID);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class with the default framework instance.  This listener
     * will be called for any modifications of this class or any
     * transitive children of this class.
     * 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::modb::ObjectListener* listener)
    {
        registerListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Unregister a listener from updates to this class.
     * 
     * @param framework the framework instance 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::unregisterListener(framework, listener, CLASS_ID);
    }

    /**
     * Unregister a listener from updates to this class from the
     * default framework instance
     * 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::modb::ObjectListener* listener)
    {
        unregisterListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Construct an instance of SNATIPPool.
     * This should not typically be called from user code.
     */
    SNATIPPool(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri,
        const boost::shared_ptr<const opflex::modb::mointernal::ObjectInstance>& oi)
        : MO(framework, CLASS_ID, uri, oi) { }
}; // class SNATIPPool

} // namespace gbpe
} // namespace modelgbp
#endif // GI_GBPE_SNATIPPOOL_HPP
