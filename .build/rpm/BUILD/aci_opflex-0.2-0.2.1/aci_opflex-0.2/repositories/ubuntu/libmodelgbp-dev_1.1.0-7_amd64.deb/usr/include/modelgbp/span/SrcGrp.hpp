/**
 * 
 * SOME COPYRIGHT
 * 
 * SrcGrp.hpp
 * 
 * generated SrcGrp.hpp file genie code generation framework free of license.
 *  
 */
#pragma once
#ifndef GI_SPAN_SRCGRP_HPP
#define GI_SPAN_SRCGRP_HPP

#include <boost/optional.hpp>
#include "opflex/modb/URIBuilder.h"
#include "opflex/modb/mo-internal/MO.h"
/*
 * contains: item:mclass(span/SrcMember)
 */
#include "modelgbp/span/SrcMember.hpp"
/*
 * contains: item:mclass(span/DstMember)
 */
#include "modelgbp/span/DstMember.hpp"

namespace modelgbp {
namespace span {

class SrcGrp
    : public opflex::modb::mointernal::MO
{
public:

    /**
     * The unique class ID for SrcGrp
     */
    static const opflex::modb::class_id_t CLASS_ID = 49;

    /**
     * Check whether label has been set
     * @return true if label has been set
     */
    bool isLabelSet()
    {
        return getObjectInstance().isSet(1605635ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of label if it has been set.
     * @return the value of label or boost::none if not set
     */
    boost::optional<uint32_t> getLabel()
    {
        if (isLabelSet())
            return (uint32_t)getObjectInstance().getUInt64(1605635ul);
        return boost::none;
    }

    /**
     * Get the value of label if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of label if set, otherwise the value of default passed in
     */
    uint32_t getLabel(uint32_t defaultValue)
    {
        return getLabel().get_value_or(defaultValue);
    }

    /**
     * Set label to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::span::SrcGrp& setLabel(uint32_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(1605635ul, newValue);
        return *this;
    }

    /**
     * Unset label in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::span::SrcGrp& unsetLabel()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1605635ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether name has been set
     * @return true if name has been set
     */
    bool isNameSet()
    {
        return getObjectInstance().isSet(1605633ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of name if it has been set.
     * @return the value of name or boost::none if not set
     */
    boost::optional<const std::string&> getName()
    {
        if (isNameSet())
            return getObjectInstance().getString(1605633ul);
        return boost::none;
    }

    /**
     * Get the value of name if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of name if set, otherwise the value of default passed in
     */
    const std::string& getName(const std::string& defaultValue)
    {
        return getName().get_value_or(defaultValue);
    }

    /**
     * Set name to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::span::SrcGrp& setName(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(1605633ul, newValue);
        return *this;
    }

    /**
     * Unset name in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::span::SrcGrp& unsetName()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1605633ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether state has been set
     * @return true if state has been set
     */
    bool isStateSet()
    {
        return getObjectInstance().isSet(1605634ul, opflex::modb::PropertyInfo::ENUM8);
    }

    /**
     * Get the value of state if it has been set.
     * @return the value of state or boost::none if not set
     */
    boost::optional<const uint8_t> getState()
    {
        if (isStateSet())
            return (const uint8_t)getObjectInstance().getUInt64(1605634ul);
        return boost::none;
    }

    /**
     * Get the value of state if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of state if set, otherwise the value of default passed in
     */
    const uint8_t getState(const uint8_t defaultValue)
    {
        return getState().get_value_or(defaultValue);
    }

    /**
     * Set state to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::span::SrcGrp& setState(const uint8_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(1605634ul, newValue);
        return *this;
    }

    /**
     * Unset state in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::span::SrcGrp& unsetState()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1605634ul, opflex::modb::PropertyInfo::ENUM8, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Retrieve an instance of SrcGrp from the managed
     * object store.  If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::span::SrcGrp> > resolve(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::span::SrcGrp>(framework, CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of SrcGrp from the managed
     * object store using the default framework instance.  If the 
     * object does not exist in the local store, returns boost::none. 
     * Note that even though it may not exist locally, it may still 
     * exist remotely.
     * 
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::span::SrcGrp> > resolve(
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::span::SrcGrp>(opflex::ofcore::OFFramework::defaultInstance(), CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of SrcGrp from the managed
     * object store by constructing its URI from the path elements
     * that lead to it.  If the object does not exist in the local
     * store, returns boost::none.  Note that even though it may not
     * exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PlatformConfig/[platformConfigName]/SpanSrcGrp/[spanSrcGrpName]
     * 
     * @param framework the framework instance to use 
     * @param platformConfigName the value of platformConfigName,
     * a naming property for Config
     * @param spanSrcGrpName the value of spanSrcGrpName,
     * a naming property for SrcGrp
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::span::SrcGrp> > resolve(
        opflex::ofcore::OFFramework& framework,
        const std::string& platformConfigName,
        const std::string& spanSrcGrpName)
    {
        return resolve(framework,opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PlatformConfig").addElement(platformConfigName).addElement("SpanSrcGrp").addElement(spanSrcGrpName).build());
    }

    /**
     * Retrieve an instance of SrcGrp from the 
     * default managed object store by constructing its URI from the
     * path elements that lead to it.  If the object does not exist in
     * the local store, returns boost::none.  Note that even though it
     * may not exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PlatformConfig/[platformConfigName]/SpanSrcGrp/[spanSrcGrpName]
     * 
     * @param platformConfigName the value of platformConfigName,
     * a naming property for Config
     * @param spanSrcGrpName the value of spanSrcGrpName,
     * a naming property for SrcGrp
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::span::SrcGrp> > resolve(
        const std::string& platformConfigName,
        const std::string& spanSrcGrpName)
    {
        return resolve(opflex::ofcore::OFFramework::defaultInstance(),platformConfigName,spanSrcGrpName);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param spanSrcMemberName the value of spanSrcMemberName,
     * a naming property for SrcMember
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::span::SrcMember> > resolveSpanSrcMember(
        const std::string& spanSrcMemberName)
    {
        return modelgbp::span::SrcMember::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("SpanSrcMember").addElement(spanSrcMemberName).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param spanSrcMemberName the value of spanSrcMemberName,
     * a naming property for SrcMember
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::span::SrcMember> addSpanSrcMember(
        const std::string& spanSrcMemberName)
    {
        boost::shared_ptr<modelgbp::span::SrcMember> result = addChild<modelgbp::span::SrcMember>(
            CLASS_ID, getURI(), 2149089339ul, 59,
            opflex::modb::URIBuilder(getURI()).addElement("SpanSrcMember").addElement(spanSrcMemberName).build()
            );
        result->setName(spanSrcMemberName);
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::span::SrcMember
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveSpanSrcMember(/* out */ std::vector<boost::shared_ptr<modelgbp::span::SrcMember> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::span::SrcMember>(
            getFramework(), CLASS_ID, getURI(), 2149089339ul, 59, out);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param spanDstMemberName the value of spanDstMemberName,
     * a naming property for DstMember
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::span::DstMember> > resolveSpanDstMember(
        const std::string& spanDstMemberName)
    {
        return modelgbp::span::DstMember::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("SpanDstMember").addElement(spanDstMemberName).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param spanDstMemberName the value of spanDstMemberName,
     * a naming property for DstMember
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::span::DstMember> addSpanDstMember(
        const std::string& spanDstMemberName)
    {
        boost::shared_ptr<modelgbp::span::DstMember> result = addChild<modelgbp::span::DstMember>(
            CLASS_ID, getURI(), 2149089340ul, 60,
            opflex::modb::URIBuilder(getURI()).addElement("SpanDstMember").addElement(spanDstMemberName).build()
            );
        result->setName(spanDstMemberName);
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::span::DstMember
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveSpanDstMember(/* out */ std::vector<boost::shared_ptr<modelgbp::span::DstMember> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::span::DstMember>(
            getFramework(), CLASS_ID, getURI(), 2149089340ul, 60, out);
    }

    /**
     * Remove this instance using the currently-active mutator.  If
     * the object does not exist, then this will be a no-op.  If this
     * object has any children, they will be garbage-collected at some
     * future time.
     * 
     * @throws std::logic_error if no mutator is active
     */
    void remove()
    {
        getTLMutator().remove(CLASS_ID, getURI());
    }

    /**
     * Remove the SrcGrp object with the specified URI
     * using the currently-active mutator.  If the object does not exist,
     * then this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(opflex::ofcore::OFFramework& framework,
                       const opflex::modb::URI& uri)
    {
        MO::remove(framework, CLASS_ID, uri);
    }

    /**
     * Remove the SrcGrp object with the specified URI 
     * using the currently-active mutator and the default framework 
     * instance.  If the object does not exist, then this will be a
     * no-op.  If this object has any children, they will be 
     * garbage-collected at some future time.
     * 
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(const opflex::modb::URI& uri)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(), uri);
    }

    /**
     * Remove the SrcGrp object with the specified path
     * elements from the managed object store.  If the object does
     * not exist, then this will be a no-op.  If this object has any
     * children, they will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PlatformConfig/[platformConfigName]/SpanSrcGrp/[spanSrcGrpName]
     * 
     * @param framework the framework instance to use
     * @param platformConfigName the value of platformConfigName,
     * a naming property for Config
     * @param spanSrcGrpName the value of spanSrcGrpName,
     * a naming property for SrcGrp
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        opflex::ofcore::OFFramework& framework,
        const std::string& platformConfigName,
        const std::string& spanSrcGrpName)
    {
        MO::remove(framework, CLASS_ID, opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PlatformConfig").addElement(platformConfigName).addElement("SpanSrcGrp").addElement(spanSrcGrpName).build());
    }

    /**
     * Remove the SrcGrp object with the specified path
     * elements from the managed object store using the default
     * framework instance.  If the object does not exist, then
     * this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PlatformConfig/[platformConfigName]/SpanSrcGrp/[spanSrcGrpName]
     * 
     * @param platformConfigName the value of platformConfigName,
     * a naming property for Config
     * @param spanSrcGrpName the value of spanSrcGrpName,
     * a naming property for SrcGrp
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        const std::string& platformConfigName,
        const std::string& spanSrcGrpName)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(),platformConfigName,spanSrcGrpName);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class.  This listener will be called for any modifications
     * of this class or any transitive children of this class.
     * 
     * @param framework the framework instance 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::registerListener(framework, listener, CLASS_ID);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class with the default framework instance.  This listener
     * will be called for any modifications of this class or any
     * transitive children of this class.
     * 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::modb::ObjectListener* listener)
    {
        registerListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Unregister a listener from updates to this class.
     * 
     * @param framework the framework instance 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::unregisterListener(framework, listener, CLASS_ID);
    }

    /**
     * Unregister a listener from updates to this class from the
     * default framework instance
     * 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::modb::ObjectListener* listener)
    {
        unregisterListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Construct an instance of SrcGrp.
     * This should not typically be called from user code.
     */
    SrcGrp(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri,
        const boost::shared_ptr<const opflex::modb::mointernal::ObjectInstance>& oi)
        : MO(framework, CLASS_ID, uri, oi) { }
}; // class SrcGrp

} // namespace span
} // namespace modelgbp
#endif // GI_SPAN_SRCGRP_HPP
