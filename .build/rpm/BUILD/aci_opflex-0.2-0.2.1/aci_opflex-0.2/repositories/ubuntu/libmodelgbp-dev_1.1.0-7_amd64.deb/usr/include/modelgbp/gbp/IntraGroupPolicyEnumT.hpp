/**
 * 
 * SOME COPYRIGHT
 * 
 * IntraGroupPolicyEnumT.hpp
 * 
 * generated IntraGroupPolicyEnumT.hpp file genie code generation framework free of license.
 *  
 */
#include <boost/cstdint.hpp>
#include <cstddef>
namespace modelgbp {
namespace gbp {
    struct IntraGroupPolicyEnumT {
        static const uint8_t CONST_ALLOW = 0;
        static const uint8_t CONST_REQUIRE_CONTRACT = 1;
    };
}
}
