/**
 * 
 * SOME COPYRIGHT
 * 
 * RoleEnumT.hpp
 * 
 * generated RoleEnumT.hpp file genie code generation framework free of license.
 *  
 */
#include <boost/cstdint.hpp>
#include <cstddef>
namespace modelgbp {
namespace relator {
    struct RoleEnumT {
        static const uint8_t CONST_RESOLVER = 4;
        static const uint8_t CONST_SOURCE = 1;
        static const uint8_t CONST_TARGET = 2;
    };
}
}
