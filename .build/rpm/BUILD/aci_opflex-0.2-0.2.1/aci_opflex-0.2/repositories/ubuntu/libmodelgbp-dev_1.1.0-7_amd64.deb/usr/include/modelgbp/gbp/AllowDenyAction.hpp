/**
 * 
 * SOME COPYRIGHT
 * 
 * AllowDenyAction.hpp
 * 
 * generated AllowDenyAction.hpp file genie code generation framework free of license.
 *  
 */
#pragma once
#ifndef GI_GBP_ALLOWDENYACTION_HPP
#define GI_GBP_ALLOWDENYACTION_HPP

#include <boost/optional.hpp>
#include "opflex/modb/URIBuilder.h"
#include "opflex/modb/mo-internal/MO.h"
/*
 * contains: item:mclass(gbp/RuleFromActionRTgt)
 */
#include "modelgbp/gbp/RuleFromActionRTgt.hpp"

namespace modelgbp {
namespace gbp {

class AllowDenyAction
    : public opflex::modb::mointernal::MO
{
public:

    /**
     * The unique class ID for AllowDenyAction
     */
    static const opflex::modb::class_id_t CLASS_ID = 95;

    /**
     * Check whether allow has been set
     * @return true if allow has been set
     */
    bool isAllowSet()
    {
        return getObjectInstance().isSet(3112963ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of allow if it has been set.
     * @return the value of allow or boost::none if not set
     */
    boost::optional<const uint8_t> getAllow()
    {
        if (isAllowSet())
            return (const uint8_t)getObjectInstance().getUInt64(3112963ul);
        return boost::none;
    }

    /**
     * Get the value of allow if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of allow if set, otherwise the value of default passed in
     */
    const uint8_t getAllow(const uint8_t defaultValue)
    {
        return getAllow().get_value_or(defaultValue);
    }

    /**
     * Set allow to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::AllowDenyAction& setAllow(const uint8_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(3112963ul, newValue);
        return *this;
    }

    /**
     * Unset allow in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::AllowDenyAction& unsetAllow()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(3112963ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether name has been set
     * @return true if name has been set
     */
    bool isNameSet()
    {
        return getObjectInstance().isSet(3112961ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of name if it has been set.
     * @return the value of name or boost::none if not set
     */
    boost::optional<const std::string&> getName()
    {
        if (isNameSet())
            return getObjectInstance().getString(3112961ul);
        return boost::none;
    }

    /**
     * Get the value of name if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of name if set, otherwise the value of default passed in
     */
    const std::string& getName(const std::string& defaultValue)
    {
        return getName().get_value_or(defaultValue);
    }

    /**
     * Set name to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::AllowDenyAction& setName(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(3112961ul, newValue);
        return *this;
    }

    /**
     * Unset name in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::AllowDenyAction& unsetName()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(3112961ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether order has been set
     * @return true if order has been set
     */
    bool isOrderSet()
    {
        return getObjectInstance().isSet(3112962ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of order if it has been set.
     * @return the value of order or boost::none if not set
     */
    boost::optional<uint32_t> getOrder()
    {
        if (isOrderSet())
            return (uint32_t)getObjectInstance().getUInt64(3112962ul);
        return boost::none;
    }

    /**
     * Get the value of order if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of order if set, otherwise the value of default passed in
     */
    uint32_t getOrder(uint32_t defaultValue)
    {
        return getOrder().get_value_or(defaultValue);
    }

    /**
     * Set order to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::AllowDenyAction& setOrder(uint32_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(3112962ul, newValue);
        return *this;
    }

    /**
     * Unset order in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::AllowDenyAction& unsetOrder()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(3112962ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Retrieve an instance of AllowDenyAction from the managed
     * object store.  If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::AllowDenyAction> > resolve(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::gbp::AllowDenyAction>(framework, CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of AllowDenyAction from the managed
     * object store using the default framework instance.  If the 
     * object does not exist in the local store, returns boost::none. 
     * Note that even though it may not exist locally, it may still 
     * exist remotely.
     * 
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::AllowDenyAction> > resolve(
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::gbp::AllowDenyAction>(opflex::ofcore::OFFramework::defaultInstance(), CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of AllowDenyAction from the managed
     * object store by constructing its URI from the path elements
     * that lead to it.  If the object does not exist in the local
     * store, returns boost::none.  Note that even though it may not
     * exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpAllowDenyAction/[gbpAllowDenyActionName]
     * 
     * @param framework the framework instance to use 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpAllowDenyActionName the value of gbpAllowDenyActionName,
     * a naming property for AllowDenyAction
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::AllowDenyAction> > resolve(
        opflex::ofcore::OFFramework& framework,
        const std::string& policySpaceName,
        const std::string& gbpAllowDenyActionName)
    {
        return resolve(framework,opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PolicySpace").addElement(policySpaceName).addElement("GbpAllowDenyAction").addElement(gbpAllowDenyActionName).build());
    }

    /**
     * Retrieve an instance of AllowDenyAction from the 
     * default managed object store by constructing its URI from the
     * path elements that lead to it.  If the object does not exist in
     * the local store, returns boost::none.  Note that even though it
     * may not exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpAllowDenyAction/[gbpAllowDenyActionName]
     * 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpAllowDenyActionName the value of gbpAllowDenyActionName,
     * a naming property for AllowDenyAction
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::AllowDenyAction> > resolve(
        const std::string& policySpaceName,
        const std::string& gbpAllowDenyActionName)
    {
        return resolve(opflex::ofcore::OFFramework::defaultInstance(),policySpaceName,gbpAllowDenyActionName);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param gbpRuleFromActionRTgtSource the value of gbpRuleFromActionRTgtSource,
     * a naming property for RuleFromActionRTgt
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::RuleFromActionRTgt> > resolveGbpRuleFromActionRTgt(
        const std::string& gbpRuleFromActionRTgtSource)
    {
        return modelgbp::gbp::RuleFromActionRTgt::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpRuleFromActionRTgt").addElement(gbpRuleFromActionRTgtSource).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param gbpRuleFromActionRTgtSource the value of gbpRuleFromActionRTgtSource,
     * a naming property for RuleFromActionRTgt
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::RuleFromActionRTgt> addGbpRuleFromActionRTgt(
        const std::string& gbpRuleFromActionRTgtSource)
    {
        boost::shared_ptr<modelgbp::gbp::RuleFromActionRTgt> result = addChild<modelgbp::gbp::RuleFromActionRTgt>(
            CLASS_ID, getURI(), 2150596712ul, 104,
            opflex::modb::URIBuilder(getURI()).addElement("GbpRuleFromActionRTgt").addElement(gbpRuleFromActionRTgtSource).build()
            );
        result->setSource(gbpRuleFromActionRTgtSource);
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::gbp::RuleFromActionRTgt
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveGbpRuleFromActionRTgt(/* out */ std::vector<boost::shared_ptr<modelgbp::gbp::RuleFromActionRTgt> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::gbp::RuleFromActionRTgt>(
            getFramework(), CLASS_ID, getURI(), 2150596712ul, 104, out);
    }

    /**
     * Remove this instance using the currently-active mutator.  If
     * the object does not exist, then this will be a no-op.  If this
     * object has any children, they will be garbage-collected at some
     * future time.
     * 
     * @throws std::logic_error if no mutator is active
     */
    void remove()
    {
        getTLMutator().remove(CLASS_ID, getURI());
    }

    /**
     * Remove the AllowDenyAction object with the specified URI
     * using the currently-active mutator.  If the object does not exist,
     * then this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(opflex::ofcore::OFFramework& framework,
                       const opflex::modb::URI& uri)
    {
        MO::remove(framework, CLASS_ID, uri);
    }

    /**
     * Remove the AllowDenyAction object with the specified URI 
     * using the currently-active mutator and the default framework 
     * instance.  If the object does not exist, then this will be a
     * no-op.  If this object has any children, they will be 
     * garbage-collected at some future time.
     * 
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(const opflex::modb::URI& uri)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(), uri);
    }

    /**
     * Remove the AllowDenyAction object with the specified path
     * elements from the managed object store.  If the object does
     * not exist, then this will be a no-op.  If this object has any
     * children, they will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpAllowDenyAction/[gbpAllowDenyActionName]
     * 
     * @param framework the framework instance to use
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpAllowDenyActionName the value of gbpAllowDenyActionName,
     * a naming property for AllowDenyAction
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        opflex::ofcore::OFFramework& framework,
        const std::string& policySpaceName,
        const std::string& gbpAllowDenyActionName)
    {
        MO::remove(framework, CLASS_ID, opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PolicySpace").addElement(policySpaceName).addElement("GbpAllowDenyAction").addElement(gbpAllowDenyActionName).build());
    }

    /**
     * Remove the AllowDenyAction object with the specified path
     * elements from the managed object store using the default
     * framework instance.  If the object does not exist, then
     * this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpAllowDenyAction/[gbpAllowDenyActionName]
     * 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpAllowDenyActionName the value of gbpAllowDenyActionName,
     * a naming property for AllowDenyAction
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        const std::string& policySpaceName,
        const std::string& gbpAllowDenyActionName)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(),policySpaceName,gbpAllowDenyActionName);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class.  This listener will be called for any modifications
     * of this class or any transitive children of this class.
     * 
     * @param framework the framework instance 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::registerListener(framework, listener, CLASS_ID);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class with the default framework instance.  This listener
     * will be called for any modifications of this class or any
     * transitive children of this class.
     * 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::modb::ObjectListener* listener)
    {
        registerListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Unregister a listener from updates to this class.
     * 
     * @param framework the framework instance 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::unregisterListener(framework, listener, CLASS_ID);
    }

    /**
     * Unregister a listener from updates to this class from the
     * default framework instance
     * 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::modb::ObjectListener* listener)
    {
        unregisterListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Construct an instance of AllowDenyAction.
     * This should not typically be called from user code.
     */
    AllowDenyAction(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri,
        const boost::shared_ptr<const opflex::modb::mointernal::ObjectInstance>& oi)
        : MO(framework, CLASS_ID, uri, oi) { }
}; // class AllowDenyAction

} // namespace gbp
} // namespace modelgbp
#endif // GI_GBP_ALLOWDENYACTION_HPP
