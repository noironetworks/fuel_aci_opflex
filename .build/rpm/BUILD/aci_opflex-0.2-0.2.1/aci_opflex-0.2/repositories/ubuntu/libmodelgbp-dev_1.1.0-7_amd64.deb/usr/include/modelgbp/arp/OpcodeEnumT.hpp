/**
 * 
 * SOME COPYRIGHT
 * 
 * OpcodeEnumT.hpp
 * 
 * generated OpcodeEnumT.hpp file genie code generation framework free of license.
 *  
 */
#include <boost/cstdint.hpp>
#include <cstddef>
namespace modelgbp {
namespace arp {
    struct OpcodeEnumT {
        static const uint8_t CONST_REPLY = 2;
        static const uint8_t CONST_REQUEST = 1;
        static const uint8_t CONST_UNSPECIFIED = 0;
    };
}
}
