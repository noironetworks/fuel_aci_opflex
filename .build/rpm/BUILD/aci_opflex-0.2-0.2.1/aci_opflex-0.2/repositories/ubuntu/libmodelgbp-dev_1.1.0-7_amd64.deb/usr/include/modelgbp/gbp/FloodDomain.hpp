/**
 * 
 * SOME COPYRIGHT
 * 
 * FloodDomain.hpp
 * 
 * generated FloodDomain.hpp file genie code generation framework free of license.
 *  
 */
#pragma once
#ifndef GI_GBP_FLOODDOMAIN_HPP
#define GI_GBP_FLOODDOMAIN_HPP

#include <boost/optional.hpp>
#include "opflex/modb/URIBuilder.h"
#include "opflex/modb/mo-internal/MO.h"
/*
 * contains: item:mclass(gbpe/FloodContext)
 */
#include "modelgbp/gbpe/FloodContext.hpp"
/*
 * contains: item:mclass(gbp/EpGroupFromNetworkRTgt)
 */
#include "modelgbp/gbp/EpGroupFromNetworkRTgt.hpp"
/*
 * contains: item:mclass(gbp/FloodDomainToNetworkRSrc)
 */
#include "modelgbp/gbp/FloodDomainToNetworkRSrc.hpp"
/*
 * contains: item:mclass(gbp/ForwardingBehavioralGroupToSubnetsRSrc)
 */
#include "modelgbp/gbp/ForwardingBehavioralGroupToSubnetsRSrc.hpp"

namespace modelgbp {
namespace gbp {

class FloodDomain
    : public opflex::modb::mointernal::MO
{
public:

    /**
     * The unique class ID for FloodDomain
     */
    static const opflex::modb::class_id_t CLASS_ID = 136;

    /**
     * Check whether arpMode has been set
     * @return true if arpMode has been set
     */
    bool isArpModeSet()
    {
        return getObjectInstance().isSet(4456450ul, opflex::modb::PropertyInfo::ENUM8);
    }

    /**
     * Get the value of arpMode if it has been set.
     * @return the value of arpMode or boost::none if not set
     */
    boost::optional<const uint8_t> getArpMode()
    {
        if (isArpModeSet())
            return (const uint8_t)getObjectInstance().getUInt64(4456450ul);
        return boost::none;
    }

    /**
     * Get the value of arpMode if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of arpMode if set, otherwise the value of default passed in
     */
    const uint8_t getArpMode(const uint8_t defaultValue)
    {
        return getArpMode().get_value_or(defaultValue);
    }

    /**
     * Set arpMode to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::FloodDomain& setArpMode(const uint8_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(4456450ul, newValue);
        return *this;
    }

    /**
     * Unset arpMode in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::FloodDomain& unsetArpMode()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(4456450ul, opflex::modb::PropertyInfo::ENUM8, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether name has been set
     * @return true if name has been set
     */
    bool isNameSet()
    {
        return getObjectInstance().isSet(4456449ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of name if it has been set.
     * @return the value of name or boost::none if not set
     */
    boost::optional<const std::string&> getName()
    {
        if (isNameSet())
            return getObjectInstance().getString(4456449ul);
        return boost::none;
    }

    /**
     * Get the value of name if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of name if set, otherwise the value of default passed in
     */
    const std::string& getName(const std::string& defaultValue)
    {
        return getName().get_value_or(defaultValue);
    }

    /**
     * Set name to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::FloodDomain& setName(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(4456449ul, newValue);
        return *this;
    }

    /**
     * Unset name in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::FloodDomain& unsetName()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(4456449ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether neighborDiscMode has been set
     * @return true if neighborDiscMode has been set
     */
    bool isNeighborDiscModeSet()
    {
        return getObjectInstance().isSet(4456451ul, opflex::modb::PropertyInfo::ENUM8);
    }

    /**
     * Get the value of neighborDiscMode if it has been set.
     * @return the value of neighborDiscMode or boost::none if not set
     */
    boost::optional<const uint8_t> getNeighborDiscMode()
    {
        if (isNeighborDiscModeSet())
            return (const uint8_t)getObjectInstance().getUInt64(4456451ul);
        return boost::none;
    }

    /**
     * Get the value of neighborDiscMode if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of neighborDiscMode if set, otherwise the value of default passed in
     */
    const uint8_t getNeighborDiscMode(const uint8_t defaultValue)
    {
        return getNeighborDiscMode().get_value_or(defaultValue);
    }

    /**
     * Set neighborDiscMode to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::FloodDomain& setNeighborDiscMode(const uint8_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(4456451ul, newValue);
        return *this;
    }

    /**
     * Unset neighborDiscMode in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::FloodDomain& unsetNeighborDiscMode()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(4456451ul, opflex::modb::PropertyInfo::ENUM8, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether unknownFloodMode has been set
     * @return true if unknownFloodMode has been set
     */
    bool isUnknownFloodModeSet()
    {
        return getObjectInstance().isSet(4456452ul, opflex::modb::PropertyInfo::ENUM8);
    }

    /**
     * Get the value of unknownFloodMode if it has been set.
     * @return the value of unknownFloodMode or boost::none if not set
     */
    boost::optional<const uint8_t> getUnknownFloodMode()
    {
        if (isUnknownFloodModeSet())
            return (const uint8_t)getObjectInstance().getUInt64(4456452ul);
        return boost::none;
    }

    /**
     * Get the value of unknownFloodMode if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of unknownFloodMode if set, otherwise the value of default passed in
     */
    const uint8_t getUnknownFloodMode(const uint8_t defaultValue)
    {
        return getUnknownFloodMode().get_value_or(defaultValue);
    }

    /**
     * Set unknownFloodMode to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::FloodDomain& setUnknownFloodMode(const uint8_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(4456452ul, newValue);
        return *this;
    }

    /**
     * Unset unknownFloodMode in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::FloodDomain& unsetUnknownFloodMode()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(4456452ul, opflex::modb::PropertyInfo::ENUM8, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Retrieve an instance of FloodDomain from the managed
     * object store.  If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::FloodDomain> > resolve(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::gbp::FloodDomain>(framework, CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of FloodDomain from the managed
     * object store using the default framework instance.  If the 
     * object does not exist in the local store, returns boost::none. 
     * Note that even though it may not exist locally, it may still 
     * exist remotely.
     * 
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::FloodDomain> > resolve(
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::gbp::FloodDomain>(opflex::ofcore::OFFramework::defaultInstance(), CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of FloodDomain from the managed
     * object store by constructing its URI from the path elements
     * that lead to it.  If the object does not exist in the local
     * store, returns boost::none.  Note that even though it may not
     * exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpFloodDomain/[gbpFloodDomainName]
     * 
     * @param framework the framework instance to use 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpFloodDomainName the value of gbpFloodDomainName,
     * a naming property for FloodDomain
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::FloodDomain> > resolve(
        opflex::ofcore::OFFramework& framework,
        const std::string& policySpaceName,
        const std::string& gbpFloodDomainName)
    {
        return resolve(framework,opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PolicySpace").addElement(policySpaceName).addElement("GbpFloodDomain").addElement(gbpFloodDomainName).build());
    }

    /**
     * Retrieve an instance of FloodDomain from the 
     * default managed object store by constructing its URI from the
     * path elements that lead to it.  If the object does not exist in
     * the local store, returns boost::none.  Note that even though it
     * may not exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpFloodDomain/[gbpFloodDomainName]
     * 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpFloodDomainName the value of gbpFloodDomainName,
     * a naming property for FloodDomain
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::FloodDomain> > resolve(
        const std::string& policySpaceName,
        const std::string& gbpFloodDomainName)
    {
        return resolve(opflex::ofcore::OFFramework::defaultInstance(),policySpaceName,gbpFloodDomainName);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbpe::FloodContext> > resolveGbpeFloodContext(
        )
    {
        return modelgbp::gbpe::FloodContext::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpeFloodContext").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbpe::FloodContext> addGbpeFloodContext(
        )
    {
        boost::shared_ptr<modelgbp::gbpe::FloodContext> result = addChild<modelgbp::gbpe::FloodContext>(
            CLASS_ID, getURI(), 2151940126ul, 30,
            opflex::modb::URIBuilder(getURI()).addElement("GbpeFloodContext").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param gbpEpGroupFromNetworkRTgtSource the value of gbpEpGroupFromNetworkRTgtSource,
     * a naming property for EpGroupFromNetworkRTgt
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::EpGroupFromNetworkRTgt> > resolveGbpEpGroupFromNetworkRTgt(
        const std::string& gbpEpGroupFromNetworkRTgtSource)
    {
        return modelgbp::gbp::EpGroupFromNetworkRTgt::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpEpGroupFromNetworkRTgt").addElement(gbpEpGroupFromNetworkRTgtSource).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param gbpEpGroupFromNetworkRTgtSource the value of gbpEpGroupFromNetworkRTgtSource,
     * a naming property for EpGroupFromNetworkRTgt
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::EpGroupFromNetworkRTgt> addGbpEpGroupFromNetworkRTgt(
        const std::string& gbpEpGroupFromNetworkRTgtSource)
    {
        boost::shared_ptr<modelgbp::gbp::EpGroupFromNetworkRTgt> result = addChild<modelgbp::gbp::EpGroupFromNetworkRTgt>(
            CLASS_ID, getURI(), 2151940204ul, 108,
            opflex::modb::URIBuilder(getURI()).addElement("GbpEpGroupFromNetworkRTgt").addElement(gbpEpGroupFromNetworkRTgtSource).build()
            );
        result->setSource(gbpEpGroupFromNetworkRTgtSource);
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::gbp::EpGroupFromNetworkRTgt
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveGbpEpGroupFromNetworkRTgt(/* out */ std::vector<boost::shared_ptr<modelgbp::gbp::EpGroupFromNetworkRTgt> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::gbp::EpGroupFromNetworkRTgt>(
            getFramework(), CLASS_ID, getURI(), 2151940204ul, 108, out);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::FloodDomainToNetworkRSrc> > resolveGbpFloodDomainToNetworkRSrc(
        )
    {
        return modelgbp::gbp::FloodDomainToNetworkRSrc::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpFloodDomainToNetworkRSrc").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::FloodDomainToNetworkRSrc> addGbpFloodDomainToNetworkRSrc(
        )
    {
        boost::shared_ptr<modelgbp::gbp::FloodDomainToNetworkRSrc> result = addChild<modelgbp::gbp::FloodDomainToNetworkRSrc>(
            CLASS_ID, getURI(), 2151940233ul, 137,
            opflex::modb::URIBuilder(getURI()).addElement("GbpFloodDomainToNetworkRSrc").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::ForwardingBehavioralGroupToSubnetsRSrc> > resolveGbpForwardingBehavioralGroupToSubnetsRSrc(
        )
    {
        return modelgbp::gbp::ForwardingBehavioralGroupToSubnetsRSrc::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpForwardingBehavioralGroupToSubnetsRSrc").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::ForwardingBehavioralGroupToSubnetsRSrc> addGbpForwardingBehavioralGroupToSubnetsRSrc(
        )
    {
        boost::shared_ptr<modelgbp::gbp::ForwardingBehavioralGroupToSubnetsRSrc> result = addChild<modelgbp::gbp::ForwardingBehavioralGroupToSubnetsRSrc>(
            CLASS_ID, getURI(), 2151940246ul, 150,
            opflex::modb::URIBuilder(getURI()).addElement("GbpForwardingBehavioralGroupToSubnetsRSrc").build()
            );
        return result;
    }

    /**
     * Remove this instance using the currently-active mutator.  If
     * the object does not exist, then this will be a no-op.  If this
     * object has any children, they will be garbage-collected at some
     * future time.
     * 
     * @throws std::logic_error if no mutator is active
     */
    void remove()
    {
        getTLMutator().remove(CLASS_ID, getURI());
    }

    /**
     * Remove the FloodDomain object with the specified URI
     * using the currently-active mutator.  If the object does not exist,
     * then this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(opflex::ofcore::OFFramework& framework,
                       const opflex::modb::URI& uri)
    {
        MO::remove(framework, CLASS_ID, uri);
    }

    /**
     * Remove the FloodDomain object with the specified URI 
     * using the currently-active mutator and the default framework 
     * instance.  If the object does not exist, then this will be a
     * no-op.  If this object has any children, they will be 
     * garbage-collected at some future time.
     * 
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(const opflex::modb::URI& uri)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(), uri);
    }

    /**
     * Remove the FloodDomain object with the specified path
     * elements from the managed object store.  If the object does
     * not exist, then this will be a no-op.  If this object has any
     * children, they will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpFloodDomain/[gbpFloodDomainName]
     * 
     * @param framework the framework instance to use
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpFloodDomainName the value of gbpFloodDomainName,
     * a naming property for FloodDomain
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        opflex::ofcore::OFFramework& framework,
        const std::string& policySpaceName,
        const std::string& gbpFloodDomainName)
    {
        MO::remove(framework, CLASS_ID, opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PolicySpace").addElement(policySpaceName).addElement("GbpFloodDomain").addElement(gbpFloodDomainName).build());
    }

    /**
     * Remove the FloodDomain object with the specified path
     * elements from the managed object store using the default
     * framework instance.  If the object does not exist, then
     * this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpFloodDomain/[gbpFloodDomainName]
     * 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpFloodDomainName the value of gbpFloodDomainName,
     * a naming property for FloodDomain
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        const std::string& policySpaceName,
        const std::string& gbpFloodDomainName)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(),policySpaceName,gbpFloodDomainName);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class.  This listener will be called for any modifications
     * of this class or any transitive children of this class.
     * 
     * @param framework the framework instance 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::registerListener(framework, listener, CLASS_ID);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class with the default framework instance.  This listener
     * will be called for any modifications of this class or any
     * transitive children of this class.
     * 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::modb::ObjectListener* listener)
    {
        registerListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Unregister a listener from updates to this class.
     * 
     * @param framework the framework instance 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::unregisterListener(framework, listener, CLASS_ID);
    }

    /**
     * Unregister a listener from updates to this class from the
     * default framework instance
     * 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::modb::ObjectListener* listener)
    {
        unregisterListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Construct an instance of FloodDomain.
     * This should not typically be called from user code.
     */
    FloodDomain(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri,
        const boost::shared_ptr<const opflex::modb::mointernal::ObjectInstance>& oi)
        : MO(framework, CLASS_ID, uri, oi) { }
}; // class FloodDomain

} // namespace gbp
} // namespace modelgbp
#endif // GI_GBP_FLOODDOMAIN_HPP
