/**
 * 
 * SOME COPYRIGHT
 * 
 * EpGroup.hpp
 * 
 * generated EpGroup.hpp file genie code generation framework free of license.
 *  
 */
#pragma once
#ifndef GI_GBP_EPGROUP_HPP
#define GI_GBP_EPGROUP_HPP

#include <boost/optional.hpp>
#include "opflex/modb/URIBuilder.h"
#include "opflex/modb/mo-internal/MO.h"
/*
 * contains: item:mclass(gbpe/EpgMappingFromDefaultGroupRTgt)
 */
#include "modelgbp/gbpe/EpgMappingFromDefaultGroupRTgt.hpp"
/*
 * contains: item:mclass(gbpe/MappingRuleFromGroupRTgt)
 */
#include "modelgbp/gbpe/MappingRuleFromGroupRTgt.hpp"
/*
 * contains: item:mclass(gbpe/InstContext)
 */
#include "modelgbp/gbpe/InstContext.hpp"
/*
 * contains: item:mclass(span/MemberFromRefRTgt)
 */
#include "modelgbp/span/MemberFromRefRTgt.hpp"
/*
 * contains: item:mclass(epdr/EndPointFromGroupRTgt)
 */
#include "modelgbp/epdr/EndPointFromGroupRTgt.hpp"
/*
 * contains: item:mclass(gbp/EpGroupToNetworkRSrc)
 */
#include "modelgbp/gbp/EpGroupToNetworkRSrc.hpp"
/*
 * contains: item:mclass(gbp/EpGroupToProvContractRSrc)
 */
#include "modelgbp/gbp/EpGroupToProvContractRSrc.hpp"
/*
 * contains: item:mclass(gbp/EpGroupToConsContractRSrc)
 */
#include "modelgbp/gbp/EpGroupToConsContractRSrc.hpp"
/*
 * contains: item:mclass(gbp/EpGroupToSubnetsRSrc)
 */
#include "modelgbp/gbp/EpGroupToSubnetsRSrc.hpp"
/*
 * contains: item:mclass(gbp/L3ExternalNetworkFromNatEPGroupRTgt)
 */
#include "modelgbp/gbp/L3ExternalNetworkFromNatEPGroupRTgt.hpp"

namespace modelgbp {
namespace gbp {

class EpGroup
    : public opflex::modb::mointernal::MO
{
public:

    /**
     * The unique class ID for EpGroup
     */
    static const opflex::modb::class_id_t CLASS_ID = 106;

    /**
     * Check whether intraGroupPolicy has been set
     * @return true if intraGroupPolicy has been set
     */
    bool isIntraGroupPolicySet()
    {
        return getObjectInstance().isSet(3473410ul, opflex::modb::PropertyInfo::ENUM8);
    }

    /**
     * Get the value of intraGroupPolicy if it has been set.
     * @return the value of intraGroupPolicy or boost::none if not set
     */
    boost::optional<const uint8_t> getIntraGroupPolicy()
    {
        if (isIntraGroupPolicySet())
            return (const uint8_t)getObjectInstance().getUInt64(3473410ul);
        return boost::none;
    }

    /**
     * Get the value of intraGroupPolicy if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of intraGroupPolicy if set, otherwise the value of default passed in
     */
    const uint8_t getIntraGroupPolicy(const uint8_t defaultValue)
    {
        return getIntraGroupPolicy().get_value_or(defaultValue);
    }

    /**
     * Set intraGroupPolicy to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::EpGroup& setIntraGroupPolicy(const uint8_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(3473410ul, newValue);
        return *this;
    }

    /**
     * Unset intraGroupPolicy in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::EpGroup& unsetIntraGroupPolicy()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(3473410ul, opflex::modb::PropertyInfo::ENUM8, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether name has been set
     * @return true if name has been set
     */
    bool isNameSet()
    {
        return getObjectInstance().isSet(3473409ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of name if it has been set.
     * @return the value of name or boost::none if not set
     */
    boost::optional<const std::string&> getName()
    {
        if (isNameSet())
            return getObjectInstance().getString(3473409ul);
        return boost::none;
    }

    /**
     * Get the value of name if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of name if set, otherwise the value of default passed in
     */
    const std::string& getName(const std::string& defaultValue)
    {
        return getName().get_value_or(defaultValue);
    }

    /**
     * Set name to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::EpGroup& setName(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(3473409ul, newValue);
        return *this;
    }

    /**
     * Unset name in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::EpGroup& unsetName()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(3473409ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Retrieve an instance of EpGroup from the managed
     * object store.  If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::EpGroup> > resolve(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::gbp::EpGroup>(framework, CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of EpGroup from the managed
     * object store using the default framework instance.  If the 
     * object does not exist in the local store, returns boost::none. 
     * Note that even though it may not exist locally, it may still 
     * exist remotely.
     * 
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::EpGroup> > resolve(
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::gbp::EpGroup>(opflex::ofcore::OFFramework::defaultInstance(), CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of EpGroup from the managed
     * object store by constructing its URI from the path elements
     * that lead to it.  If the object does not exist in the local
     * store, returns boost::none.  Note that even though it may not
     * exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpEpGroup/[gbpEpGroupName]
     * 
     * @param framework the framework instance to use 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpEpGroupName the value of gbpEpGroupName,
     * a naming property for EpGroup
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::EpGroup> > resolve(
        opflex::ofcore::OFFramework& framework,
        const std::string& policySpaceName,
        const std::string& gbpEpGroupName)
    {
        return resolve(framework,opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PolicySpace").addElement(policySpaceName).addElement("GbpEpGroup").addElement(gbpEpGroupName).build());
    }

    /**
     * Retrieve an instance of EpGroup from the 
     * default managed object store by constructing its URI from the
     * path elements that lead to it.  If the object does not exist in
     * the local store, returns boost::none.  Note that even though it
     * may not exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpEpGroup/[gbpEpGroupName]
     * 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpEpGroupName the value of gbpEpGroupName,
     * a naming property for EpGroup
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::EpGroup> > resolve(
        const std::string& policySpaceName,
        const std::string& gbpEpGroupName)
    {
        return resolve(opflex::ofcore::OFFramework::defaultInstance(),policySpaceName,gbpEpGroupName);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param gbpeEpgMappingFromDefaultGroupRTgtSource the value of gbpeEpgMappingFromDefaultGroupRTgtSource,
     * a naming property for EpgMappingFromDefaultGroupRTgt
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbpe::EpgMappingFromDefaultGroupRTgt> > resolveGbpeEpgMappingFromDefaultGroupRTgt(
        const std::string& gbpeEpgMappingFromDefaultGroupRTgtSource)
    {
        return modelgbp::gbpe::EpgMappingFromDefaultGroupRTgt::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpeEpgMappingFromDefaultGroupRTgt").addElement(gbpeEpgMappingFromDefaultGroupRTgtSource).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param gbpeEpgMappingFromDefaultGroupRTgtSource the value of gbpeEpgMappingFromDefaultGroupRTgtSource,
     * a naming property for EpgMappingFromDefaultGroupRTgt
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbpe::EpgMappingFromDefaultGroupRTgt> addGbpeEpgMappingFromDefaultGroupRTgt(
        const std::string& gbpeEpgMappingFromDefaultGroupRTgtSource)
    {
        boost::shared_ptr<modelgbp::gbpe::EpgMappingFromDefaultGroupRTgt> result = addChild<modelgbp::gbpe::EpgMappingFromDefaultGroupRTgt>(
            CLASS_ID, getURI(), 2150957067ul, 11,
            opflex::modb::URIBuilder(getURI()).addElement("GbpeEpgMappingFromDefaultGroupRTgt").addElement(gbpeEpgMappingFromDefaultGroupRTgtSource).build()
            );
        result->setSource(gbpeEpgMappingFromDefaultGroupRTgtSource);
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::gbpe::EpgMappingFromDefaultGroupRTgt
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveGbpeEpgMappingFromDefaultGroupRTgt(/* out */ std::vector<boost::shared_ptr<modelgbp::gbpe::EpgMappingFromDefaultGroupRTgt> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::gbpe::EpgMappingFromDefaultGroupRTgt>(
            getFramework(), CLASS_ID, getURI(), 2150957067ul, 11, out);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param gbpeMappingRuleFromGroupRTgtSource the value of gbpeMappingRuleFromGroupRTgtSource,
     * a naming property for MappingRuleFromGroupRTgt
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbpe::MappingRuleFromGroupRTgt> > resolveGbpeMappingRuleFromGroupRTgt(
        const std::string& gbpeMappingRuleFromGroupRTgtSource)
    {
        return modelgbp::gbpe::MappingRuleFromGroupRTgt::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpeMappingRuleFromGroupRTgt").addElement(gbpeMappingRuleFromGroupRTgtSource).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param gbpeMappingRuleFromGroupRTgtSource the value of gbpeMappingRuleFromGroupRTgtSource,
     * a naming property for MappingRuleFromGroupRTgt
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbpe::MappingRuleFromGroupRTgt> addGbpeMappingRuleFromGroupRTgt(
        const std::string& gbpeMappingRuleFromGroupRTgtSource)
    {
        boost::shared_ptr<modelgbp::gbpe::MappingRuleFromGroupRTgt> result = addChild<modelgbp::gbpe::MappingRuleFromGroupRTgt>(
            CLASS_ID, getURI(), 2150957078ul, 22,
            opflex::modb::URIBuilder(getURI()).addElement("GbpeMappingRuleFromGroupRTgt").addElement(gbpeMappingRuleFromGroupRTgtSource).build()
            );
        result->setSource(gbpeMappingRuleFromGroupRTgtSource);
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::gbpe::MappingRuleFromGroupRTgt
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveGbpeMappingRuleFromGroupRTgt(/* out */ std::vector<boost::shared_ptr<modelgbp::gbpe::MappingRuleFromGroupRTgt> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::gbpe::MappingRuleFromGroupRTgt>(
            getFramework(), CLASS_ID, getURI(), 2150957078ul, 22, out);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbpe::InstContext> > resolveGbpeInstContext(
        )
    {
        return modelgbp::gbpe::InstContext::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpeInstContext").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbpe::InstContext> addGbpeInstContext(
        )
    {
        boost::shared_ptr<modelgbp::gbpe::InstContext> result = addChild<modelgbp::gbpe::InstContext>(
            CLASS_ID, getURI(), 2150957085ul, 29,
            opflex::modb::URIBuilder(getURI()).addElement("GbpeInstContext").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param spanMemberFromRefRTgtSource the value of spanMemberFromRefRTgtSource,
     * a naming property for MemberFromRefRTgt
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::span::MemberFromRefRTgt> > resolveSpanMemberFromRefRTgt(
        const std::string& spanMemberFromRefRTgtSource)
    {
        return modelgbp::span::MemberFromRefRTgt::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("SpanMemberFromRefRTgt").addElement(spanMemberFromRefRTgtSource).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param spanMemberFromRefRTgtSource the value of spanMemberFromRefRTgtSource,
     * a naming property for MemberFromRefRTgt
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::span::MemberFromRefRTgt> addSpanMemberFromRefRTgt(
        const std::string& spanMemberFromRefRTgtSource)
    {
        boost::shared_ptr<modelgbp::span::MemberFromRefRTgt> result = addChild<modelgbp::span::MemberFromRefRTgt>(
            CLASS_ID, getURI(), 2150957113ul, 57,
            opflex::modb::URIBuilder(getURI()).addElement("SpanMemberFromRefRTgt").addElement(spanMemberFromRefRTgtSource).build()
            );
        result->setSource(spanMemberFromRefRTgtSource);
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::span::MemberFromRefRTgt
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveSpanMemberFromRefRTgt(/* out */ std::vector<boost::shared_ptr<modelgbp::span::MemberFromRefRTgt> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::span::MemberFromRefRTgt>(
            getFramework(), CLASS_ID, getURI(), 2150957113ul, 57, out);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param epdrEndPointFromGroupRTgtSource the value of epdrEndPointFromGroupRTgtSource,
     * a naming property for EndPointFromGroupRTgt
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::epdr::EndPointFromGroupRTgt> > resolveEpdrEndPointFromGroupRTgt(
        const std::string& epdrEndPointFromGroupRTgtSource)
    {
        return modelgbp::epdr::EndPointFromGroupRTgt::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("EpdrEndPointFromGroupRTgt").addElement(epdrEndPointFromGroupRTgtSource).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param epdrEndPointFromGroupRTgtSource the value of epdrEndPointFromGroupRTgtSource,
     * a naming property for EndPointFromGroupRTgt
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::epdr::EndPointFromGroupRTgt> addEpdrEndPointFromGroupRTgt(
        const std::string& epdrEndPointFromGroupRTgtSource)
    {
        boost::shared_ptr<modelgbp::epdr::EndPointFromGroupRTgt> result = addChild<modelgbp::epdr::EndPointFromGroupRTgt>(
            CLASS_ID, getURI(), 2150957141ul, 85,
            opflex::modb::URIBuilder(getURI()).addElement("EpdrEndPointFromGroupRTgt").addElement(epdrEndPointFromGroupRTgtSource).build()
            );
        result->setSource(epdrEndPointFromGroupRTgtSource);
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::epdr::EndPointFromGroupRTgt
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveEpdrEndPointFromGroupRTgt(/* out */ std::vector<boost::shared_ptr<modelgbp::epdr::EndPointFromGroupRTgt> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::epdr::EndPointFromGroupRTgt>(
            getFramework(), CLASS_ID, getURI(), 2150957141ul, 85, out);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::EpGroupToNetworkRSrc> > resolveGbpEpGroupToNetworkRSrc(
        )
    {
        return modelgbp::gbp::EpGroupToNetworkRSrc::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpEpGroupToNetworkRSrc").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::EpGroupToNetworkRSrc> addGbpEpGroupToNetworkRSrc(
        )
    {
        boost::shared_ptr<modelgbp::gbp::EpGroupToNetworkRSrc> result = addChild<modelgbp::gbp::EpGroupToNetworkRSrc>(
            CLASS_ID, getURI(), 2150957163ul, 107,
            opflex::modb::URIBuilder(getURI()).addElement("GbpEpGroupToNetworkRSrc").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param gbpEpGroupToProvContractRSrcTargetClass the value of gbpEpGroupToProvContractRSrcTargetClass,
     * a naming property for EpGroupToProvContractRSrc
     * @param gbpEpGroupToProvContractRSrcTargetName the value of gbpEpGroupToProvContractRSrcTargetName,
     * a naming property for EpGroupToProvContractRSrc
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::EpGroupToProvContractRSrc> > resolveGbpEpGroupToProvContractRSrc(
        const std::string& gbpEpGroupToProvContractRSrcTargetName)
    {
        opflex::modb::class_id_t gbpEpGroupToProvContractRSrcTargetClass = 97;
        return modelgbp::gbp::EpGroupToProvContractRSrc::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpEpGroupToProvContractRSrc").addElement(gbpEpGroupToProvContractRSrcTargetClass).addElement(gbpEpGroupToProvContractRSrcTargetName).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param gbpEpGroupToProvContractRSrcTargetClass the value of gbpEpGroupToProvContractRSrcTargetClass,
     * a naming property for EpGroupToProvContractRSrc
     * @param gbpEpGroupToProvContractRSrcTargetName the value of gbpEpGroupToProvContractRSrcTargetName,
     * a naming property for EpGroupToProvContractRSrc
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::EpGroupToProvContractRSrc> addGbpEpGroupToProvContractRSrc(
        const std::string& gbpEpGroupToProvContractRSrcTargetName)
    {
        opflex::modb::class_id_t gbpEpGroupToProvContractRSrcTargetClass = 97;
        boost::shared_ptr<modelgbp::gbp::EpGroupToProvContractRSrc> result = addChild<modelgbp::gbp::EpGroupToProvContractRSrc>(
            CLASS_ID, getURI(), 2150957166ul, 110,
            opflex::modb::URIBuilder(getURI()).addElement("GbpEpGroupToProvContractRSrc").addElement(gbpEpGroupToProvContractRSrcTargetClass).addElement(gbpEpGroupToProvContractRSrcTargetName).build()
            );
        result->setTargetContract(opflex::modb::URI(gbpEpGroupToProvContractRSrcTargetName));
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::gbp::EpGroupToProvContractRSrc
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveGbpEpGroupToProvContractRSrc(/* out */ std::vector<boost::shared_ptr<modelgbp::gbp::EpGroupToProvContractRSrc> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::gbp::EpGroupToProvContractRSrc>(
            getFramework(), CLASS_ID, getURI(), 2150957166ul, 110, out);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param gbpEpGroupToConsContractRSrcTargetClass the value of gbpEpGroupToConsContractRSrcTargetClass,
     * a naming property for EpGroupToConsContractRSrc
     * @param gbpEpGroupToConsContractRSrcTargetName the value of gbpEpGroupToConsContractRSrcTargetName,
     * a naming property for EpGroupToConsContractRSrc
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::EpGroupToConsContractRSrc> > resolveGbpEpGroupToConsContractRSrc(
        const std::string& gbpEpGroupToConsContractRSrcTargetName)
    {
        opflex::modb::class_id_t gbpEpGroupToConsContractRSrcTargetClass = 97;
        return modelgbp::gbp::EpGroupToConsContractRSrc::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpEpGroupToConsContractRSrc").addElement(gbpEpGroupToConsContractRSrcTargetClass).addElement(gbpEpGroupToConsContractRSrcTargetName).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param gbpEpGroupToConsContractRSrcTargetClass the value of gbpEpGroupToConsContractRSrcTargetClass,
     * a naming property for EpGroupToConsContractRSrc
     * @param gbpEpGroupToConsContractRSrcTargetName the value of gbpEpGroupToConsContractRSrcTargetName,
     * a naming property for EpGroupToConsContractRSrc
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::EpGroupToConsContractRSrc> addGbpEpGroupToConsContractRSrc(
        const std::string& gbpEpGroupToConsContractRSrcTargetName)
    {
        opflex::modb::class_id_t gbpEpGroupToConsContractRSrcTargetClass = 97;
        boost::shared_ptr<modelgbp::gbp::EpGroupToConsContractRSrc> result = addChild<modelgbp::gbp::EpGroupToConsContractRSrc>(
            CLASS_ID, getURI(), 2150957169ul, 113,
            opflex::modb::URIBuilder(getURI()).addElement("GbpEpGroupToConsContractRSrc").addElement(gbpEpGroupToConsContractRSrcTargetClass).addElement(gbpEpGroupToConsContractRSrcTargetName).build()
            );
        result->setTargetContract(opflex::modb::URI(gbpEpGroupToConsContractRSrcTargetName));
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::gbp::EpGroupToConsContractRSrc
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveGbpEpGroupToConsContractRSrc(/* out */ std::vector<boost::shared_ptr<modelgbp::gbp::EpGroupToConsContractRSrc> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::gbp::EpGroupToConsContractRSrc>(
            getFramework(), CLASS_ID, getURI(), 2150957169ul, 113, out);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::EpGroupToSubnetsRSrc> > resolveGbpEpGroupToSubnetsRSrc(
        )
    {
        return modelgbp::gbp::EpGroupToSubnetsRSrc::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpEpGroupToSubnetsRSrc").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::EpGroupToSubnetsRSrc> addGbpEpGroupToSubnetsRSrc(
        )
    {
        boost::shared_ptr<modelgbp::gbp::EpGroupToSubnetsRSrc> result = addChild<modelgbp::gbp::EpGroupToSubnetsRSrc>(
            CLASS_ID, getURI(), 2150957172ul, 116,
            opflex::modb::URIBuilder(getURI()).addElement("GbpEpGroupToSubnetsRSrc").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param gbpL3ExternalNetworkFromNatEPGroupRTgtSource the value of gbpL3ExternalNetworkFromNatEPGroupRTgtSource,
     * a naming property for L3ExternalNetworkFromNatEPGroupRTgt
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::L3ExternalNetworkFromNatEPGroupRTgt> > resolveGbpL3ExternalNetworkFromNatEPGroupRTgt(
        const std::string& gbpL3ExternalNetworkFromNatEPGroupRTgtSource)
    {
        return modelgbp::gbp::L3ExternalNetworkFromNatEPGroupRTgt::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpL3ExternalNetworkFromNatEPGroupRTgt").addElement(gbpL3ExternalNetworkFromNatEPGroupRTgtSource).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param gbpL3ExternalNetworkFromNatEPGroupRTgtSource the value of gbpL3ExternalNetworkFromNatEPGroupRTgtSource,
     * a naming property for L3ExternalNetworkFromNatEPGroupRTgt
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::L3ExternalNetworkFromNatEPGroupRTgt> addGbpL3ExternalNetworkFromNatEPGroupRTgt(
        const std::string& gbpL3ExternalNetworkFromNatEPGroupRTgtSource)
    {
        boost::shared_ptr<modelgbp::gbp::L3ExternalNetworkFromNatEPGroupRTgt> result = addChild<modelgbp::gbp::L3ExternalNetworkFromNatEPGroupRTgt>(
            CLASS_ID, getURI(), 2150957184ul, 128,
            opflex::modb::URIBuilder(getURI()).addElement("GbpL3ExternalNetworkFromNatEPGroupRTgt").addElement(gbpL3ExternalNetworkFromNatEPGroupRTgtSource).build()
            );
        result->setSource(gbpL3ExternalNetworkFromNatEPGroupRTgtSource);
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::gbp::L3ExternalNetworkFromNatEPGroupRTgt
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveGbpL3ExternalNetworkFromNatEPGroupRTgt(/* out */ std::vector<boost::shared_ptr<modelgbp::gbp::L3ExternalNetworkFromNatEPGroupRTgt> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::gbp::L3ExternalNetworkFromNatEPGroupRTgt>(
            getFramework(), CLASS_ID, getURI(), 2150957184ul, 128, out);
    }

    /**
     * Remove this instance using the currently-active mutator.  If
     * the object does not exist, then this will be a no-op.  If this
     * object has any children, they will be garbage-collected at some
     * future time.
     * 
     * @throws std::logic_error if no mutator is active
     */
    void remove()
    {
        getTLMutator().remove(CLASS_ID, getURI());
    }

    /**
     * Remove the EpGroup object with the specified URI
     * using the currently-active mutator.  If the object does not exist,
     * then this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(opflex::ofcore::OFFramework& framework,
                       const opflex::modb::URI& uri)
    {
        MO::remove(framework, CLASS_ID, uri);
    }

    /**
     * Remove the EpGroup object with the specified URI 
     * using the currently-active mutator and the default framework 
     * instance.  If the object does not exist, then this will be a
     * no-op.  If this object has any children, they will be 
     * garbage-collected at some future time.
     * 
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(const opflex::modb::URI& uri)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(), uri);
    }

    /**
     * Remove the EpGroup object with the specified path
     * elements from the managed object store.  If the object does
     * not exist, then this will be a no-op.  If this object has any
     * children, they will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpEpGroup/[gbpEpGroupName]
     * 
     * @param framework the framework instance to use
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpEpGroupName the value of gbpEpGroupName,
     * a naming property for EpGroup
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        opflex::ofcore::OFFramework& framework,
        const std::string& policySpaceName,
        const std::string& gbpEpGroupName)
    {
        MO::remove(framework, CLASS_ID, opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PolicySpace").addElement(policySpaceName).addElement("GbpEpGroup").addElement(gbpEpGroupName).build());
    }

    /**
     * Remove the EpGroup object with the specified path
     * elements from the managed object store using the default
     * framework instance.  If the object does not exist, then
     * this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpEpGroup/[gbpEpGroupName]
     * 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpEpGroupName the value of gbpEpGroupName,
     * a naming property for EpGroup
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        const std::string& policySpaceName,
        const std::string& gbpEpGroupName)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(),policySpaceName,gbpEpGroupName);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class.  This listener will be called for any modifications
     * of this class or any transitive children of this class.
     * 
     * @param framework the framework instance 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::registerListener(framework, listener, CLASS_ID);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class with the default framework instance.  This listener
     * will be called for any modifications of this class or any
     * transitive children of this class.
     * 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::modb::ObjectListener* listener)
    {
        registerListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Unregister a listener from updates to this class.
     * 
     * @param framework the framework instance 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::unregisterListener(framework, listener, CLASS_ID);
    }

    /**
     * Unregister a listener from updates to this class from the
     * default framework instance
     * 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::modb::ObjectListener* listener)
    {
        unregisterListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Construct an instance of EpGroup.
     * This should not typically be called from user code.
     */
    EpGroup(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri,
        const boost::shared_ptr<const opflex::modb::mointernal::ObjectInstance>& oi)
        : MO(framework, CLASS_ID, uri, oi) { }
}; // class EpGroup

} // namespace gbp
} // namespace modelgbp
#endif // GI_GBP_EPGROUP_HPP
