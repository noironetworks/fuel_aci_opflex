/**
 * 
 * SOME COPYRIGHT
 * 
 * Universe.hpp
 * 
 * generated Universe.hpp file genie code generation framework free of license.
 *  
 */
#pragma once
#ifndef GI_RELATOR_UNIVERSE_HPP
#define GI_RELATOR_UNIVERSE_HPP

#include <boost/optional.hpp>
#include "opflex/modb/URIBuilder.h"
#include "opflex/modb/mo-internal/MO.h"
/*
 * contains: item:mclass(gbpe/EpgMappingToDefaultGroupRRes)
 */
#include "modelgbp/gbpe/EpgMappingToDefaultGroupRRes.hpp"
/*
 * contains: item:mclass(gbpe/EpgMappingCtxToEpgMappingRRes)
 */
#include "modelgbp/gbpe/EpgMappingCtxToEpgMappingRRes.hpp"
/*
 * contains: item:mclass(gbpe/EpgMappingCtxToAttrSetRRes)
 */
#include "modelgbp/gbpe/EpgMappingCtxToAttrSetRRes.hpp"
/*
 * contains: item:mclass(gbpe/MappingRuleToGroupRRes)
 */
#include "modelgbp/gbpe/MappingRuleToGroupRRes.hpp"
/*
 * contains: item:mclass(domain/ConfigToConfigRRes)
 */
#include "modelgbp/domain/ConfigToConfigRRes.hpp"
/*
 * contains: item:mclass(span/LocalEpToEpRRes)
 */
#include "modelgbp/span/LocalEpToEpRRes.hpp"
/*
 * contains: item:mclass(span/MemberToRefRRes)
 */
#include "modelgbp/span/MemberToRefRRes.hpp"
/*
 * contains: item:mclass(dci/DciEpToGroupRRes)
 */
#include "modelgbp/dci/DciEpToGroupRRes.hpp"
/*
 * contains: item:mclass(dci/DomainToNetworkRRes)
 */
#include "modelgbp/dci/DomainToNetworkRRes.hpp"
/*
 * contains: item:mclass(epdr/EndPointToGroupRRes)
 */
#include "modelgbp/epdr/EndPointToGroupRRes.hpp"
/*
 * contains: item:mclass(gbp/RuleToClassifierRRes)
 */
#include "modelgbp/gbp/RuleToClassifierRRes.hpp"
/*
 * contains: item:mclass(gbp/RuleToActionRRes)
 */
#include "modelgbp/gbp/RuleToActionRRes.hpp"
/*
 * contains: item:mclass(gbp/EpGroupToNetworkRRes)
 */
#include "modelgbp/gbp/EpGroupToNetworkRRes.hpp"
/*
 * contains: item:mclass(gbp/EpGroupToProvContractRRes)
 */
#include "modelgbp/gbp/EpGroupToProvContractRRes.hpp"
/*
 * contains: item:mclass(gbp/EpGroupToConsContractRRes)
 */
#include "modelgbp/gbp/EpGroupToConsContractRRes.hpp"
/*
 * contains: item:mclass(gbp/EpGroupToSubnetsRRes)
 */
#include "modelgbp/gbp/EpGroupToSubnetsRRes.hpp"
/*
 * contains: item:mclass(gbp/L3ExternalNetworkToProvContractRRes)
 */
#include "modelgbp/gbp/L3ExternalNetworkToProvContractRRes.hpp"
/*
 * contains: item:mclass(gbp/L3ExternalNetworkToConsContractRRes)
 */
#include "modelgbp/gbp/L3ExternalNetworkToConsContractRRes.hpp"
/*
 * contains: item:mclass(gbp/L3ExternalNetworkToNatEPGroupRRes)
 */
#include "modelgbp/gbp/L3ExternalNetworkToNatEPGroupRRes.hpp"
/*
 * contains: item:mclass(gbp/BridgeDomainToNetworkRRes)
 */
#include "modelgbp/gbp/BridgeDomainToNetworkRRes.hpp"
/*
 * contains: item:mclass(gbp/FloodDomainToNetworkRRes)
 */
#include "modelgbp/gbp/FloodDomainToNetworkRRes.hpp"
/*
 * contains: item:mclass(gbp/RoutingDomainToIntSubnetsRRes)
 */
#include "modelgbp/gbp/RoutingDomainToIntSubnetsRRes.hpp"
/*
 * contains: item:mclass(gbp/ForwardingBehavioralGroupToSubnetsRRes)
 */
#include "modelgbp/gbp/ForwardingBehavioralGroupToSubnetsRRes.hpp"

namespace modelgbp {
namespace relator {

class Universe
    : public opflex::modb::mointernal::MO
{
public:

    /**
     * The unique class ID for Universe
     */
    static const opflex::modb::class_id_t CLASS_ID = 7;

    /**
     * Retrieve an instance of Universe from the managed
     * object store.  If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::relator::Universe> > resolve(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::relator::Universe>(framework, CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of Universe from the managed
     * object store using the default framework instance.  If the 
     * object does not exist in the local store, returns boost::none. 
     * Note that even though it may not exist locally, it may still 
     * exist remotely.
     * 
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::relator::Universe> > resolve(
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::relator::Universe>(opflex::ofcore::OFFramework::defaultInstance(), CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of Universe from the managed
     * object store by constructing its URI from the path elements
     * that lead to it.  If the object does not exist in the local
     * store, returns boost::none.  Note that even though it may not
     * exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /RelatorUniverse
     * 
     * @param framework the framework instance to use 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::relator::Universe> > resolve(
        opflex::ofcore::OFFramework& framework)
    {
        return resolve(framework,opflex::modb::URIBuilder().addElement("RelatorUniverse").build());
    }

    /**
     * Retrieve an instance of Universe from the 
     * default managed object store by constructing its URI from the
     * path elements that lead to it.  If the object does not exist in
     * the local store, returns boost::none.  Note that even though it
     * may not exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /RelatorUniverse
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::relator::Universe> > resolve(
        )
    {
        return resolve(opflex::ofcore::OFFramework::defaultInstance());
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbpe::EpgMappingToDefaultGroupRRes> > resolveGbpeEpgMappingToDefaultGroupRRes(
        )
    {
        return modelgbp::gbpe::EpgMappingToDefaultGroupRRes::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpeEpgMappingToDefaultGroupRRes").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbpe::EpgMappingToDefaultGroupRRes> addGbpeEpgMappingToDefaultGroupRRes(
        )
    {
        boost::shared_ptr<modelgbp::gbpe::EpgMappingToDefaultGroupRRes> result = addChild<modelgbp::gbpe::EpgMappingToDefaultGroupRRes>(
            CLASS_ID, getURI(), 2147713036ul, 12,
            opflex::modb::URIBuilder(getURI()).addElement("GbpeEpgMappingToDefaultGroupRRes").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbpe::EpgMappingCtxToEpgMappingRRes> > resolveGbpeEpgMappingCtxToEpgMappingRRes(
        )
    {
        return modelgbp::gbpe::EpgMappingCtxToEpgMappingRRes::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpeEpgMappingCtxToEpgMappingRRes").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbpe::EpgMappingCtxToEpgMappingRRes> addGbpeEpgMappingCtxToEpgMappingRRes(
        )
    {
        boost::shared_ptr<modelgbp::gbpe::EpgMappingCtxToEpgMappingRRes> result = addChild<modelgbp::gbpe::EpgMappingCtxToEpgMappingRRes>(
            CLASS_ID, getURI(), 2147713040ul, 16,
            opflex::modb::URIBuilder(getURI()).addElement("GbpeEpgMappingCtxToEpgMappingRRes").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbpe::EpgMappingCtxToAttrSetRRes> > resolveGbpeEpgMappingCtxToAttrSetRRes(
        )
    {
        return modelgbp::gbpe::EpgMappingCtxToAttrSetRRes::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpeEpgMappingCtxToAttrSetRRes").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbpe::EpgMappingCtxToAttrSetRRes> addGbpeEpgMappingCtxToAttrSetRRes(
        )
    {
        boost::shared_ptr<modelgbp::gbpe::EpgMappingCtxToAttrSetRRes> result = addChild<modelgbp::gbpe::EpgMappingCtxToAttrSetRRes>(
            CLASS_ID, getURI(), 2147713043ul, 19,
            opflex::modb::URIBuilder(getURI()).addElement("GbpeEpgMappingCtxToAttrSetRRes").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbpe::MappingRuleToGroupRRes> > resolveGbpeMappingRuleToGroupRRes(
        )
    {
        return modelgbp::gbpe::MappingRuleToGroupRRes::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpeMappingRuleToGroupRRes").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbpe::MappingRuleToGroupRRes> addGbpeMappingRuleToGroupRRes(
        )
    {
        boost::shared_ptr<modelgbp::gbpe::MappingRuleToGroupRRes> result = addChild<modelgbp::gbpe::MappingRuleToGroupRRes>(
            CLASS_ID, getURI(), 2147713047ul, 23,
            opflex::modb::URIBuilder(getURI()).addElement("GbpeMappingRuleToGroupRRes").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::domain::ConfigToConfigRRes> > resolveDomainConfigToConfigRRes(
        )
    {
        return modelgbp::domain::ConfigToConfigRRes::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("DomainConfigToConfigRRes").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::domain::ConfigToConfigRRes> addDomainConfigToConfigRRes(
        )
    {
        boost::shared_ptr<modelgbp::domain::ConfigToConfigRRes> result = addChild<modelgbp::domain::ConfigToConfigRRes>(
            CLASS_ID, getURI(), 2147713068ul, 44,
            opflex::modb::URIBuilder(getURI()).addElement("DomainConfigToConfigRRes").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::span::LocalEpToEpRRes> > resolveSpanLocalEpToEpRRes(
        )
    {
        return modelgbp::span::LocalEpToEpRRes::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("SpanLocalEpToEpRRes").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::span::LocalEpToEpRRes> addSpanLocalEpToEpRRes(
        )
    {
        boost::shared_ptr<modelgbp::span::LocalEpToEpRRes> result = addChild<modelgbp::span::LocalEpToEpRRes>(
            CLASS_ID, getURI(), 2147713078ul, 54,
            opflex::modb::URIBuilder(getURI()).addElement("SpanLocalEpToEpRRes").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::span::MemberToRefRRes> > resolveSpanMemberToRefRRes(
        )
    {
        return modelgbp::span::MemberToRefRRes::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("SpanMemberToRefRRes").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::span::MemberToRefRRes> addSpanMemberToRefRRes(
        )
    {
        boost::shared_ptr<modelgbp::span::MemberToRefRRes> result = addChild<modelgbp::span::MemberToRefRRes>(
            CLASS_ID, getURI(), 2147713082ul, 58,
            opflex::modb::URIBuilder(getURI()).addElement("SpanMemberToRefRRes").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::dci::DciEpToGroupRRes> > resolveDciDciEpToGroupRRes(
        )
    {
        return modelgbp::dci::DciEpToGroupRRes::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("DciDciEpToGroupRRes").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::dci::DciEpToGroupRRes> addDciDciEpToGroupRRes(
        )
    {
        boost::shared_ptr<modelgbp::dci::DciEpToGroupRRes> result = addChild<modelgbp::dci::DciEpToGroupRRes>(
            CLASS_ID, getURI(), 2147713092ul, 68,
            opflex::modb::URIBuilder(getURI()).addElement("DciDciEpToGroupRRes").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::dci::DomainToNetworkRRes> > resolveDciDomainToNetworkRRes(
        )
    {
        return modelgbp::dci::DomainToNetworkRRes::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("DciDomainToNetworkRRes").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::dci::DomainToNetworkRRes> addDciDomainToNetworkRRes(
        )
    {
        boost::shared_ptr<modelgbp::dci::DomainToNetworkRRes> result = addChild<modelgbp::dci::DomainToNetworkRRes>(
            CLASS_ID, getURI(), 2147713096ul, 72,
            opflex::modb::URIBuilder(getURI()).addElement("DciDomainToNetworkRRes").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::epdr::EndPointToGroupRRes> > resolveEpdrEndPointToGroupRRes(
        )
    {
        return modelgbp::epdr::EndPointToGroupRRes::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("EpdrEndPointToGroupRRes").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::epdr::EndPointToGroupRRes> addEpdrEndPointToGroupRRes(
        )
    {
        boost::shared_ptr<modelgbp::epdr::EndPointToGroupRRes> result = addChild<modelgbp::epdr::EndPointToGroupRRes>(
            CLASS_ID, getURI(), 2147713110ul, 86,
            opflex::modb::URIBuilder(getURI()).addElement("EpdrEndPointToGroupRRes").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::RuleToClassifierRRes> > resolveGbpRuleToClassifierRRes(
        )
    {
        return modelgbp::gbp::RuleToClassifierRRes::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpRuleToClassifierRRes").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::RuleToClassifierRRes> addGbpRuleToClassifierRRes(
        )
    {
        boost::shared_ptr<modelgbp::gbp::RuleToClassifierRRes> result = addChild<modelgbp::gbp::RuleToClassifierRRes>(
            CLASS_ID, getURI(), 2147713126ul, 102,
            opflex::modb::URIBuilder(getURI()).addElement("GbpRuleToClassifierRRes").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::RuleToActionRRes> > resolveGbpRuleToActionRRes(
        )
    {
        return modelgbp::gbp::RuleToActionRRes::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpRuleToActionRRes").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::RuleToActionRRes> addGbpRuleToActionRRes(
        )
    {
        boost::shared_ptr<modelgbp::gbp::RuleToActionRRes> result = addChild<modelgbp::gbp::RuleToActionRRes>(
            CLASS_ID, getURI(), 2147713129ul, 105,
            opflex::modb::URIBuilder(getURI()).addElement("GbpRuleToActionRRes").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::EpGroupToNetworkRRes> > resolveGbpEpGroupToNetworkRRes(
        )
    {
        return modelgbp::gbp::EpGroupToNetworkRRes::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpEpGroupToNetworkRRes").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::EpGroupToNetworkRRes> addGbpEpGroupToNetworkRRes(
        )
    {
        boost::shared_ptr<modelgbp::gbp::EpGroupToNetworkRRes> result = addChild<modelgbp::gbp::EpGroupToNetworkRRes>(
            CLASS_ID, getURI(), 2147713133ul, 109,
            opflex::modb::URIBuilder(getURI()).addElement("GbpEpGroupToNetworkRRes").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::EpGroupToProvContractRRes> > resolveGbpEpGroupToProvContractRRes(
        )
    {
        return modelgbp::gbp::EpGroupToProvContractRRes::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpEpGroupToProvContractRRes").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::EpGroupToProvContractRRes> addGbpEpGroupToProvContractRRes(
        )
    {
        boost::shared_ptr<modelgbp::gbp::EpGroupToProvContractRRes> result = addChild<modelgbp::gbp::EpGroupToProvContractRRes>(
            CLASS_ID, getURI(), 2147713136ul, 112,
            opflex::modb::URIBuilder(getURI()).addElement("GbpEpGroupToProvContractRRes").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::EpGroupToConsContractRRes> > resolveGbpEpGroupToConsContractRRes(
        )
    {
        return modelgbp::gbp::EpGroupToConsContractRRes::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpEpGroupToConsContractRRes").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::EpGroupToConsContractRRes> addGbpEpGroupToConsContractRRes(
        )
    {
        boost::shared_ptr<modelgbp::gbp::EpGroupToConsContractRRes> result = addChild<modelgbp::gbp::EpGroupToConsContractRRes>(
            CLASS_ID, getURI(), 2147713139ul, 115,
            opflex::modb::URIBuilder(getURI()).addElement("GbpEpGroupToConsContractRRes").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::EpGroupToSubnetsRRes> > resolveGbpEpGroupToSubnetsRRes(
        )
    {
        return modelgbp::gbp::EpGroupToSubnetsRRes::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpEpGroupToSubnetsRRes").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::EpGroupToSubnetsRRes> addGbpEpGroupToSubnetsRRes(
        )
    {
        boost::shared_ptr<modelgbp::gbp::EpGroupToSubnetsRRes> result = addChild<modelgbp::gbp::EpGroupToSubnetsRRes>(
            CLASS_ID, getURI(), 2147713142ul, 118,
            opflex::modb::URIBuilder(getURI()).addElement("GbpEpGroupToSubnetsRRes").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::L3ExternalNetworkToProvContractRRes> > resolveGbpL3ExternalNetworkToProvContractRRes(
        )
    {
        return modelgbp::gbp::L3ExternalNetworkToProvContractRRes::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpL3ExternalNetworkToProvContractRRes").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::L3ExternalNetworkToProvContractRRes> addGbpL3ExternalNetworkToProvContractRRes(
        )
    {
        boost::shared_ptr<modelgbp::gbp::L3ExternalNetworkToProvContractRRes> result = addChild<modelgbp::gbp::L3ExternalNetworkToProvContractRRes>(
            CLASS_ID, getURI(), 2147713147ul, 123,
            opflex::modb::URIBuilder(getURI()).addElement("GbpL3ExternalNetworkToProvContractRRes").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::L3ExternalNetworkToConsContractRRes> > resolveGbpL3ExternalNetworkToConsContractRRes(
        )
    {
        return modelgbp::gbp::L3ExternalNetworkToConsContractRRes::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpL3ExternalNetworkToConsContractRRes").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::L3ExternalNetworkToConsContractRRes> addGbpL3ExternalNetworkToConsContractRRes(
        )
    {
        boost::shared_ptr<modelgbp::gbp::L3ExternalNetworkToConsContractRRes> result = addChild<modelgbp::gbp::L3ExternalNetworkToConsContractRRes>(
            CLASS_ID, getURI(), 2147713150ul, 126,
            opflex::modb::URIBuilder(getURI()).addElement("GbpL3ExternalNetworkToConsContractRRes").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::L3ExternalNetworkToNatEPGroupRRes> > resolveGbpL3ExternalNetworkToNatEPGroupRRes(
        )
    {
        return modelgbp::gbp::L3ExternalNetworkToNatEPGroupRRes::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpL3ExternalNetworkToNatEPGroupRRes").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::L3ExternalNetworkToNatEPGroupRRes> addGbpL3ExternalNetworkToNatEPGroupRRes(
        )
    {
        boost::shared_ptr<modelgbp::gbp::L3ExternalNetworkToNatEPGroupRRes> result = addChild<modelgbp::gbp::L3ExternalNetworkToNatEPGroupRRes>(
            CLASS_ID, getURI(), 2147713153ul, 129,
            opflex::modb::URIBuilder(getURI()).addElement("GbpL3ExternalNetworkToNatEPGroupRRes").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::BridgeDomainToNetworkRRes> > resolveGbpBridgeDomainToNetworkRRes(
        )
    {
        return modelgbp::gbp::BridgeDomainToNetworkRRes::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpBridgeDomainToNetworkRRes").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::BridgeDomainToNetworkRRes> addGbpBridgeDomainToNetworkRRes(
        )
    {
        boost::shared_ptr<modelgbp::gbp::BridgeDomainToNetworkRRes> result = addChild<modelgbp::gbp::BridgeDomainToNetworkRRes>(
            CLASS_ID, getURI(), 2147713159ul, 135,
            opflex::modb::URIBuilder(getURI()).addElement("GbpBridgeDomainToNetworkRRes").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::FloodDomainToNetworkRRes> > resolveGbpFloodDomainToNetworkRRes(
        )
    {
        return modelgbp::gbp::FloodDomainToNetworkRRes::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpFloodDomainToNetworkRRes").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::FloodDomainToNetworkRRes> addGbpFloodDomainToNetworkRRes(
        )
    {
        boost::shared_ptr<modelgbp::gbp::FloodDomainToNetworkRRes> result = addChild<modelgbp::gbp::FloodDomainToNetworkRRes>(
            CLASS_ID, getURI(), 2147713163ul, 139,
            opflex::modb::URIBuilder(getURI()).addElement("GbpFloodDomainToNetworkRRes").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::RoutingDomainToIntSubnetsRRes> > resolveGbpRoutingDomainToIntSubnetsRRes(
        )
    {
        return modelgbp::gbp::RoutingDomainToIntSubnetsRRes::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpRoutingDomainToIntSubnetsRRes").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::RoutingDomainToIntSubnetsRRes> addGbpRoutingDomainToIntSubnetsRRes(
        )
    {
        boost::shared_ptr<modelgbp::gbp::RoutingDomainToIntSubnetsRRes> result = addChild<modelgbp::gbp::RoutingDomainToIntSubnetsRRes>(
            CLASS_ID, getURI(), 2147713168ul, 144,
            opflex::modb::URIBuilder(getURI()).addElement("GbpRoutingDomainToIntSubnetsRRes").build()
            );
        return result;
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbp::ForwardingBehavioralGroupToSubnetsRRes> > resolveGbpForwardingBehavioralGroupToSubnetsRRes(
        )
    {
        return modelgbp::gbp::ForwardingBehavioralGroupToSubnetsRRes::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpForwardingBehavioralGroupToSubnetsRRes").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbp::ForwardingBehavioralGroupToSubnetsRRes> addGbpForwardingBehavioralGroupToSubnetsRRes(
        )
    {
        boost::shared_ptr<modelgbp::gbp::ForwardingBehavioralGroupToSubnetsRRes> result = addChild<modelgbp::gbp::ForwardingBehavioralGroupToSubnetsRRes>(
            CLASS_ID, getURI(), 2147713176ul, 152,
            opflex::modb::URIBuilder(getURI()).addElement("GbpForwardingBehavioralGroupToSubnetsRRes").build()
            );
        return result;
    }

    /**
     * Remove this instance using the currently-active mutator.  If
     * the object does not exist, then this will be a no-op.  If this
     * object has any children, they will be garbage-collected at some
     * future time.
     * 
     * @throws std::logic_error if no mutator is active
     */
    void remove()
    {
        getTLMutator().remove(CLASS_ID, getURI());
    }

    /**
     * Remove the Universe object with the specified URI
     * using the currently-active mutator.  If the object does not exist,
     * then this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(opflex::ofcore::OFFramework& framework,
                       const opflex::modb::URI& uri)
    {
        MO::remove(framework, CLASS_ID, uri);
    }

    /**
     * Remove the Universe object with the specified URI 
     * using the currently-active mutator and the default framework 
     * instance.  If the object does not exist, then this will be a
     * no-op.  If this object has any children, they will be 
     * garbage-collected at some future time.
     * 
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(const opflex::modb::URI& uri)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(), uri);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class.  This listener will be called for any modifications
     * of this class or any transitive children of this class.
     * 
     * @param framework the framework instance 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::registerListener(framework, listener, CLASS_ID);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class with the default framework instance.  This listener
     * will be called for any modifications of this class or any
     * transitive children of this class.
     * 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::modb::ObjectListener* listener)
    {
        registerListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Unregister a listener from updates to this class.
     * 
     * @param framework the framework instance 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::unregisterListener(framework, listener, CLASS_ID);
    }

    /**
     * Unregister a listener from updates to this class from the
     * default framework instance
     * 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::modb::ObjectListener* listener)
    {
        unregisterListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Construct an instance of Universe.
     * This should not typically be called from user code.
     */
    Universe(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri,
        const boost::shared_ptr<const opflex::modb::mointernal::ObjectInstance>& oi)
        : MO(framework, CLASS_ID, uri, oi) { }
}; // class Universe

} // namespace relator
} // namespace modelgbp
#endif // GI_RELATOR_UNIVERSE_HPP
