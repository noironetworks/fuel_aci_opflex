/**
 * 
 * SOME COPYRIGHT
 * 
 * AutoconfigEnumT.hpp
 * 
 * generated AutoconfigEnumT.hpp file genie code generation framework free of license.
 *  
 */
#include <boost/cstdint.hpp>
#include <cstddef>
namespace modelgbp {
namespace gbp {
    struct AutoconfigEnumT {
        static const uint8_t CONST_BOTH = 2;
        static const uint8_t CONST_DHCP = 1;
        static const uint8_t CONST_STATELESS = 0;
    };
}
}
