/**
 * 
 * SOME COPYRIGHT
 * 
 * EpCounter.hpp
 * 
 * generated EpCounter.hpp file genie code generation framework free of license.
 *  
 */
#pragma once
#ifndef GI_GBPE_EPCOUNTER_HPP
#define GI_GBPE_EPCOUNTER_HPP

#include <boost/optional.hpp>
#include "opflex/modb/URIBuilder.h"
#include "opflex/modb/mo-internal/MO.h"

namespace modelgbp {
namespace gbpe {

class EpCounter
    : public opflex::modb::mointernal::MO
{
public:

    /**
     * The unique class ID for EpCounter
     */
    static const opflex::modb::class_id_t CLASS_ID = 32;

    /**
     * Check whether rxBroadcast has been set
     * @return true if rxBroadcast has been set
     */
    bool isRxBroadcastSet()
    {
        return getObjectInstance().isSet(1048584ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of rxBroadcast if it has been set.
     * @return the value of rxBroadcast or boost::none if not set
     */
    boost::optional<uint64_t> getRxBroadcast()
    {
        if (isRxBroadcastSet())
            return getObjectInstance().getUInt64(1048584ul);
        return boost::none;
    }

    /**
     * Get the value of rxBroadcast if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of rxBroadcast if set, otherwise the value of default passed in
     */
    uint64_t getRxBroadcast(uint64_t defaultValue)
    {
        return getRxBroadcast().get_value_or(defaultValue);
    }

    /**
     * Set rxBroadcast to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::EpCounter& setRxBroadcast(uint64_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(1048584ul, newValue);
        return *this;
    }

    /**
     * Unset rxBroadcast in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::EpCounter& unsetRxBroadcast()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1048584ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether rxBytes has been set
     * @return true if rxBytes has been set
     */
    bool isRxBytesSet()
    {
        return getObjectInstance().isSet(1048588ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of rxBytes if it has been set.
     * @return the value of rxBytes or boost::none if not set
     */
    boost::optional<uint64_t> getRxBytes()
    {
        if (isRxBytesSet())
            return getObjectInstance().getUInt64(1048588ul);
        return boost::none;
    }

    /**
     * Get the value of rxBytes if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of rxBytes if set, otherwise the value of default passed in
     */
    uint64_t getRxBytes(uint64_t defaultValue)
    {
        return getRxBytes().get_value_or(defaultValue);
    }

    /**
     * Set rxBytes to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::EpCounter& setRxBytes(uint64_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(1048588ul, newValue);
        return *this;
    }

    /**
     * Unset rxBytes in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::EpCounter& unsetRxBytes()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1048588ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether rxDrop has been set
     * @return true if rxDrop has been set
     */
    bool isRxDropSet()
    {
        return getObjectInstance().isSet(1048580ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of rxDrop if it has been set.
     * @return the value of rxDrop or boost::none if not set
     */
    boost::optional<uint64_t> getRxDrop()
    {
        if (isRxDropSet())
            return getObjectInstance().getUInt64(1048580ul);
        return boost::none;
    }

    /**
     * Get the value of rxDrop if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of rxDrop if set, otherwise the value of default passed in
     */
    uint64_t getRxDrop(uint64_t defaultValue)
    {
        return getRxDrop().get_value_or(defaultValue);
    }

    /**
     * Set rxDrop to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::EpCounter& setRxDrop(uint64_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(1048580ul, newValue);
        return *this;
    }

    /**
     * Unset rxDrop in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::EpCounter& unsetRxDrop()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1048580ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether rxMulticast has been set
     * @return true if rxMulticast has been set
     */
    bool isRxMulticastSet()
    {
        return getObjectInstance().isSet(1048582ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of rxMulticast if it has been set.
     * @return the value of rxMulticast or boost::none if not set
     */
    boost::optional<uint64_t> getRxMulticast()
    {
        if (isRxMulticastSet())
            return getObjectInstance().getUInt64(1048582ul);
        return boost::none;
    }

    /**
     * Get the value of rxMulticast if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of rxMulticast if set, otherwise the value of default passed in
     */
    uint64_t getRxMulticast(uint64_t defaultValue)
    {
        return getRxMulticast().get_value_or(defaultValue);
    }

    /**
     * Set rxMulticast to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::EpCounter& setRxMulticast(uint64_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(1048582ul, newValue);
        return *this;
    }

    /**
     * Unset rxMulticast in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::EpCounter& unsetRxMulticast()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1048582ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether rxPackets has been set
     * @return true if rxPackets has been set
     */
    bool isRxPacketsSet()
    {
        return getObjectInstance().isSet(1048578ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of rxPackets if it has been set.
     * @return the value of rxPackets or boost::none if not set
     */
    boost::optional<uint64_t> getRxPackets()
    {
        if (isRxPacketsSet())
            return getObjectInstance().getUInt64(1048578ul);
        return boost::none;
    }

    /**
     * Get the value of rxPackets if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of rxPackets if set, otherwise the value of default passed in
     */
    uint64_t getRxPackets(uint64_t defaultValue)
    {
        return getRxPackets().get_value_or(defaultValue);
    }

    /**
     * Set rxPackets to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::EpCounter& setRxPackets(uint64_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(1048578ul, newValue);
        return *this;
    }

    /**
     * Unset rxPackets in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::EpCounter& unsetRxPackets()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1048578ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether rxUnicast has been set
     * @return true if rxUnicast has been set
     */
    bool isRxUnicastSet()
    {
        return getObjectInstance().isSet(1048586ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of rxUnicast if it has been set.
     * @return the value of rxUnicast or boost::none if not set
     */
    boost::optional<uint64_t> getRxUnicast()
    {
        if (isRxUnicastSet())
            return getObjectInstance().getUInt64(1048586ul);
        return boost::none;
    }

    /**
     * Get the value of rxUnicast if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of rxUnicast if set, otherwise the value of default passed in
     */
    uint64_t getRxUnicast(uint64_t defaultValue)
    {
        return getRxUnicast().get_value_or(defaultValue);
    }

    /**
     * Set rxUnicast to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::EpCounter& setRxUnicast(uint64_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(1048586ul, newValue);
        return *this;
    }

    /**
     * Unset rxUnicast in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::EpCounter& unsetRxUnicast()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1048586ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether txBroadcast has been set
     * @return true if txBroadcast has been set
     */
    bool isTxBroadcastSet()
    {
        return getObjectInstance().isSet(1048585ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of txBroadcast if it has been set.
     * @return the value of txBroadcast or boost::none if not set
     */
    boost::optional<uint64_t> getTxBroadcast()
    {
        if (isTxBroadcastSet())
            return getObjectInstance().getUInt64(1048585ul);
        return boost::none;
    }

    /**
     * Get the value of txBroadcast if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of txBroadcast if set, otherwise the value of default passed in
     */
    uint64_t getTxBroadcast(uint64_t defaultValue)
    {
        return getTxBroadcast().get_value_or(defaultValue);
    }

    /**
     * Set txBroadcast to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::EpCounter& setTxBroadcast(uint64_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(1048585ul, newValue);
        return *this;
    }

    /**
     * Unset txBroadcast in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::EpCounter& unsetTxBroadcast()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1048585ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether txBytes has been set
     * @return true if txBytes has been set
     */
    bool isTxBytesSet()
    {
        return getObjectInstance().isSet(1048589ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of txBytes if it has been set.
     * @return the value of txBytes or boost::none if not set
     */
    boost::optional<uint64_t> getTxBytes()
    {
        if (isTxBytesSet())
            return getObjectInstance().getUInt64(1048589ul);
        return boost::none;
    }

    /**
     * Get the value of txBytes if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of txBytes if set, otherwise the value of default passed in
     */
    uint64_t getTxBytes(uint64_t defaultValue)
    {
        return getTxBytes().get_value_or(defaultValue);
    }

    /**
     * Set txBytes to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::EpCounter& setTxBytes(uint64_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(1048589ul, newValue);
        return *this;
    }

    /**
     * Unset txBytes in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::EpCounter& unsetTxBytes()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1048589ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether txDrop has been set
     * @return true if txDrop has been set
     */
    bool isTxDropSet()
    {
        return getObjectInstance().isSet(1048581ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of txDrop if it has been set.
     * @return the value of txDrop or boost::none if not set
     */
    boost::optional<uint64_t> getTxDrop()
    {
        if (isTxDropSet())
            return getObjectInstance().getUInt64(1048581ul);
        return boost::none;
    }

    /**
     * Get the value of txDrop if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of txDrop if set, otherwise the value of default passed in
     */
    uint64_t getTxDrop(uint64_t defaultValue)
    {
        return getTxDrop().get_value_or(defaultValue);
    }

    /**
     * Set txDrop to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::EpCounter& setTxDrop(uint64_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(1048581ul, newValue);
        return *this;
    }

    /**
     * Unset txDrop in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::EpCounter& unsetTxDrop()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1048581ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether txMulticast has been set
     * @return true if txMulticast has been set
     */
    bool isTxMulticastSet()
    {
        return getObjectInstance().isSet(1048583ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of txMulticast if it has been set.
     * @return the value of txMulticast or boost::none if not set
     */
    boost::optional<uint64_t> getTxMulticast()
    {
        if (isTxMulticastSet())
            return getObjectInstance().getUInt64(1048583ul);
        return boost::none;
    }

    /**
     * Get the value of txMulticast if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of txMulticast if set, otherwise the value of default passed in
     */
    uint64_t getTxMulticast(uint64_t defaultValue)
    {
        return getTxMulticast().get_value_or(defaultValue);
    }

    /**
     * Set txMulticast to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::EpCounter& setTxMulticast(uint64_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(1048583ul, newValue);
        return *this;
    }

    /**
     * Unset txMulticast in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::EpCounter& unsetTxMulticast()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1048583ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether txPackets has been set
     * @return true if txPackets has been set
     */
    bool isTxPacketsSet()
    {
        return getObjectInstance().isSet(1048579ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of txPackets if it has been set.
     * @return the value of txPackets or boost::none if not set
     */
    boost::optional<uint64_t> getTxPackets()
    {
        if (isTxPacketsSet())
            return getObjectInstance().getUInt64(1048579ul);
        return boost::none;
    }

    /**
     * Get the value of txPackets if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of txPackets if set, otherwise the value of default passed in
     */
    uint64_t getTxPackets(uint64_t defaultValue)
    {
        return getTxPackets().get_value_or(defaultValue);
    }

    /**
     * Set txPackets to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::EpCounter& setTxPackets(uint64_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(1048579ul, newValue);
        return *this;
    }

    /**
     * Unset txPackets in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::EpCounter& unsetTxPackets()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1048579ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether txUnicast has been set
     * @return true if txUnicast has been set
     */
    bool isTxUnicastSet()
    {
        return getObjectInstance().isSet(1048587ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of txUnicast if it has been set.
     * @return the value of txUnicast or boost::none if not set
     */
    boost::optional<uint64_t> getTxUnicast()
    {
        if (isTxUnicastSet())
            return getObjectInstance().getUInt64(1048587ul);
        return boost::none;
    }

    /**
     * Get the value of txUnicast if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of txUnicast if set, otherwise the value of default passed in
     */
    uint64_t getTxUnicast(uint64_t defaultValue)
    {
        return getTxUnicast().get_value_or(defaultValue);
    }

    /**
     * Set txUnicast to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::EpCounter& setTxUnicast(uint64_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(1048587ul, newValue);
        return *this;
    }

    /**
     * Unset txUnicast in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::EpCounter& unsetTxUnicast()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1048587ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether uuid has been set
     * @return true if uuid has been set
     */
    bool isUuidSet()
    {
        return getObjectInstance().isSet(1048577ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of uuid if it has been set.
     * @return the value of uuid or boost::none if not set
     */
    boost::optional<const std::string&> getUuid()
    {
        if (isUuidSet())
            return getObjectInstance().getString(1048577ul);
        return boost::none;
    }

    /**
     * Get the value of uuid if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of uuid if set, otherwise the value of default passed in
     */
    const std::string& getUuid(const std::string& defaultValue)
    {
        return getUuid().get_value_or(defaultValue);
    }

    /**
     * Set uuid to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::EpCounter& setUuid(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(1048577ul, newValue);
        return *this;
    }

    /**
     * Unset uuid in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::EpCounter& unsetUuid()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(1048577ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Retrieve an instance of EpCounter from the managed
     * object store.  If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbpe::EpCounter> > resolve(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::gbpe::EpCounter>(framework, CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of EpCounter from the managed
     * object store using the default framework instance.  If the 
     * object does not exist in the local store, returns boost::none. 
     * Note that even though it may not exist locally, it may still 
     * exist remotely.
     * 
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbpe::EpCounter> > resolve(
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::gbpe::EpCounter>(opflex::ofcore::OFFramework::defaultInstance(), CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of EpCounter from the managed
     * object store by constructing its URI from the path elements
     * that lead to it.  If the object does not exist in the local
     * store, returns boost::none.  Note that even though it may not
     * exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /ObserverEpStatUniverse/GbpeEpCounter/[gbpeEpCounterUuid]
     * 
     * @param framework the framework instance to use 
     * @param gbpeEpCounterUuid the value of gbpeEpCounterUuid,
     * a naming property for EpCounter
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbpe::EpCounter> > resolve(
        opflex::ofcore::OFFramework& framework,
        const std::string& gbpeEpCounterUuid)
    {
        return resolve(framework,opflex::modb::URIBuilder().addElement("ObserverEpStatUniverse").addElement("GbpeEpCounter").addElement(gbpeEpCounterUuid).build());
    }

    /**
     * Retrieve an instance of EpCounter from the 
     * default managed object store by constructing its URI from the
     * path elements that lead to it.  If the object does not exist in
     * the local store, returns boost::none.  Note that even though it
     * may not exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /ObserverEpStatUniverse/GbpeEpCounter/[gbpeEpCounterUuid]
     * 
     * @param gbpeEpCounterUuid the value of gbpeEpCounterUuid,
     * a naming property for EpCounter
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbpe::EpCounter> > resolve(
        const std::string& gbpeEpCounterUuid)
    {
        return resolve(opflex::ofcore::OFFramework::defaultInstance(),gbpeEpCounterUuid);
    }

    /**
     * Remove this instance using the currently-active mutator.  If
     * the object does not exist, then this will be a no-op.  If this
     * object has any children, they will be garbage-collected at some
     * future time.
     * 
     * @throws std::logic_error if no mutator is active
     */
    void remove()
    {
        getTLMutator().remove(CLASS_ID, getURI());
    }

    /**
     * Remove the EpCounter object with the specified URI
     * using the currently-active mutator.  If the object does not exist,
     * then this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(opflex::ofcore::OFFramework& framework,
                       const opflex::modb::URI& uri)
    {
        MO::remove(framework, CLASS_ID, uri);
    }

    /**
     * Remove the EpCounter object with the specified URI 
     * using the currently-active mutator and the default framework 
     * instance.  If the object does not exist, then this will be a
     * no-op.  If this object has any children, they will be 
     * garbage-collected at some future time.
     * 
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(const opflex::modb::URI& uri)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(), uri);
    }

    /**
     * Remove the EpCounter object with the specified path
     * elements from the managed object store.  If the object does
     * not exist, then this will be a no-op.  If this object has any
     * children, they will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /ObserverEpStatUniverse/GbpeEpCounter/[gbpeEpCounterUuid]
     * 
     * @param framework the framework instance to use
     * @param gbpeEpCounterUuid the value of gbpeEpCounterUuid,
     * a naming property for EpCounter
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        opflex::ofcore::OFFramework& framework,
        const std::string& gbpeEpCounterUuid)
    {
        MO::remove(framework, CLASS_ID, opflex::modb::URIBuilder().addElement("ObserverEpStatUniverse").addElement("GbpeEpCounter").addElement(gbpeEpCounterUuid).build());
    }

    /**
     * Remove the EpCounter object with the specified path
     * elements from the managed object store using the default
     * framework instance.  If the object does not exist, then
     * this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /ObserverEpStatUniverse/GbpeEpCounter/[gbpeEpCounterUuid]
     * 
     * @param gbpeEpCounterUuid the value of gbpeEpCounterUuid,
     * a naming property for EpCounter
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        const std::string& gbpeEpCounterUuid)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(),gbpeEpCounterUuid);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class.  This listener will be called for any modifications
     * of this class or any transitive children of this class.
     * 
     * @param framework the framework instance 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::registerListener(framework, listener, CLASS_ID);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class with the default framework instance.  This listener
     * will be called for any modifications of this class or any
     * transitive children of this class.
     * 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::modb::ObjectListener* listener)
    {
        registerListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Unregister a listener from updates to this class.
     * 
     * @param framework the framework instance 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::unregisterListener(framework, listener, CLASS_ID);
    }

    /**
     * Unregister a listener from updates to this class from the
     * default framework instance
     * 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::modb::ObjectListener* listener)
    {
        unregisterListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Construct an instance of EpCounter.
     * This should not typically be called from user code.
     */
    EpCounter(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri,
        const boost::shared_ptr<const opflex::modb::mointernal::ObjectInstance>& oi)
        : MO(framework, CLASS_ID, uri, oi) { }
}; // class EpCounter

} // namespace gbpe
} // namespace modelgbp
#endif // GI_GBPE_EPCOUNTER_HPP
