/**
 * 
 * SOME COPYRIGHT
 * 
 * TypeEnumT.hpp
 * 
 * generated TypeEnumT.hpp file genie code generation framework free of license.
 *  
 */
#include <boost/cstdint.hpp>
#include <cstddef>
namespace modelgbp {
namespace relator {
    struct TypeEnumT {
        static const uint8_t CONST_DIRECT_ASSOCIATION = 1;
        static const uint8_t CONST_DIRECT_DEPENDENCY = 3;
        static const uint8_t CONST_NAMED_ASSOCIATION = 2;
        static const uint8_t CONST_NAMED_DEPENDENCY = 4;
        static const uint8_t CONST_REFERENCE = 8;
    };
}
}
