/**
 * 
 * SOME COPYRIGHT
 * 
 * ControlBitsEnumT.hpp
 * 
 * generated ControlBitsEnumT.hpp file genie code generation framework free of license.
 *  
 */
#include <boost/cstdint.hpp>
#include <cstddef>
namespace modelgbp {
namespace lacp {
    struct ControlBitsEnumT {
        static const uint8_t CONST_FAST_SELECT_HOT_STANDBY = 8;
        static const uint8_t CONST_GRACEFUL_CONVERGENCE = 2;
        static const uint8_t CONST_LOAD_DEFER = 4;
        static const uint8_t CONST_SUSPEND_INVIDIDUAL_PORT = 1;
    };
}
}
