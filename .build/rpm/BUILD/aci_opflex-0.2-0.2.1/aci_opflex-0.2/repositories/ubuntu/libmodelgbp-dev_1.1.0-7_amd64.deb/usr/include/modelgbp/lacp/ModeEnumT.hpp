/**
 * 
 * SOME COPYRIGHT
 * 
 * ModeEnumT.hpp
 * 
 * generated ModeEnumT.hpp file genie code generation framework free of license.
 *  
 */
#include <boost/cstdint.hpp>
#include <cstddef>
namespace modelgbp {
namespace lacp {
    struct ModeEnumT {
        static const uint8_t CONST_ACTIVE = 1;
        static const uint8_t CONST_MAC_PIN = 3;
        static const uint8_t CONST_OFF = 0;
        static const uint8_t CONST_PASSIVE = 2;
    };
}
}
