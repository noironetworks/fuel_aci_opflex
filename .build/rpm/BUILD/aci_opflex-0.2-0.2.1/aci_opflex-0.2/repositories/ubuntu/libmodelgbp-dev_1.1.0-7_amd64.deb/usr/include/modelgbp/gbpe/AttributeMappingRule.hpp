/**
 * 
 * SOME COPYRIGHT
 * 
 * AttributeMappingRule.hpp
 * 
 * generated AttributeMappingRule.hpp file genie code generation framework free of license.
 *  
 */
#pragma once
#ifndef GI_GBPE_ATTRIBUTEMAPPINGRULE_HPP
#define GI_GBPE_ATTRIBUTEMAPPINGRULE_HPP

#include <boost/optional.hpp>
#include "opflex/modb/URIBuilder.h"
#include "opflex/modb/mo-internal/MO.h"
/*
 * contains: item:mclass(gbpe/MappingRuleToGroupRSrc)
 */
#include "modelgbp/gbpe/MappingRuleToGroupRSrc.hpp"

namespace modelgbp {
namespace gbpe {

class AttributeMappingRule
    : public opflex::modb::mointernal::MO
{
public:

    /**
     * The unique class ID for AttributeMappingRule
     */
    static const opflex::modb::class_id_t CLASS_ID = 24;

    /**
     * Check whether attributeName has been set
     * @return true if attributeName has been set
     */
    bool isAttributeNameSet()
    {
        return getObjectInstance().isSet(786435ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of attributeName if it has been set.
     * @return the value of attributeName or boost::none if not set
     */
    boost::optional<const std::string&> getAttributeName()
    {
        if (isAttributeNameSet())
            return getObjectInstance().getString(786435ul);
        return boost::none;
    }

    /**
     * Get the value of attributeName if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of attributeName if set, otherwise the value of default passed in
     */
    const std::string& getAttributeName(const std::string& defaultValue)
    {
        return getAttributeName().get_value_or(defaultValue);
    }

    /**
     * Set attributeName to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::AttributeMappingRule& setAttributeName(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(786435ul, newValue);
        return *this;
    }

    /**
     * Unset attributeName in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::AttributeMappingRule& unsetAttributeName()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(786435ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether matchString has been set
     * @return true if matchString has been set
     */
    bool isMatchStringSet()
    {
        return getObjectInstance().isSet(786438ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of matchString if it has been set.
     * @return the value of matchString or boost::none if not set
     */
    boost::optional<const std::string&> getMatchString()
    {
        if (isMatchStringSet())
            return getObjectInstance().getString(786438ul);
        return boost::none;
    }

    /**
     * Get the value of matchString if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of matchString if set, otherwise the value of default passed in
     */
    const std::string& getMatchString(const std::string& defaultValue)
    {
        return getMatchString().get_value_or(defaultValue);
    }

    /**
     * Set matchString to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::AttributeMappingRule& setMatchString(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(786438ul, newValue);
        return *this;
    }

    /**
     * Unset matchString in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::AttributeMappingRule& unsetMatchString()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(786438ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether matchType has been set
     * @return true if matchType has been set
     */
    bool isMatchTypeSet()
    {
        return getObjectInstance().isSet(786436ul, opflex::modb::PropertyInfo::ENUM8);
    }

    /**
     * Get the value of matchType if it has been set.
     * @return the value of matchType or boost::none if not set
     */
    boost::optional<const uint8_t> getMatchType()
    {
        if (isMatchTypeSet())
            return (const uint8_t)getObjectInstance().getUInt64(786436ul);
        return boost::none;
    }

    /**
     * Get the value of matchType if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of matchType if set, otherwise the value of default passed in
     */
    const uint8_t getMatchType(const uint8_t defaultValue)
    {
        return getMatchType().get_value_or(defaultValue);
    }

    /**
     * Set matchType to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::AttributeMappingRule& setMatchType(const uint8_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(786436ul, newValue);
        return *this;
    }

    /**
     * Unset matchType in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::AttributeMappingRule& unsetMatchType()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(786436ul, opflex::modb::PropertyInfo::ENUM8, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether name has been set
     * @return true if name has been set
     */
    bool isNameSet()
    {
        return getObjectInstance().isSet(786433ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of name if it has been set.
     * @return the value of name or boost::none if not set
     */
    boost::optional<const std::string&> getName()
    {
        if (isNameSet())
            return getObjectInstance().getString(786433ul);
        return boost::none;
    }

    /**
     * Get the value of name if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of name if set, otherwise the value of default passed in
     */
    const std::string& getName(const std::string& defaultValue)
    {
        return getName().get_value_or(defaultValue);
    }

    /**
     * Set name to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::AttributeMappingRule& setName(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(786433ul, newValue);
        return *this;
    }

    /**
     * Unset name in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::AttributeMappingRule& unsetName()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(786433ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether negated has been set
     * @return true if negated has been set
     */
    bool isNegatedSet()
    {
        return getObjectInstance().isSet(786437ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of negated if it has been set.
     * @return the value of negated or boost::none if not set
     */
    boost::optional<const uint8_t> getNegated()
    {
        if (isNegatedSet())
            return (const uint8_t)getObjectInstance().getUInt64(786437ul);
        return boost::none;
    }

    /**
     * Get the value of negated if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of negated if set, otherwise the value of default passed in
     */
    const uint8_t getNegated(const uint8_t defaultValue)
    {
        return getNegated().get_value_or(defaultValue);
    }

    /**
     * Set negated to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::AttributeMappingRule& setNegated(const uint8_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(786437ul, newValue);
        return *this;
    }

    /**
     * Unset negated in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::AttributeMappingRule& unsetNegated()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(786437ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether order has been set
     * @return true if order has been set
     */
    bool isOrderSet()
    {
        return getObjectInstance().isSet(786434ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of order if it has been set.
     * @return the value of order or boost::none if not set
     */
    boost::optional<uint32_t> getOrder()
    {
        if (isOrderSet())
            return (uint32_t)getObjectInstance().getUInt64(786434ul);
        return boost::none;
    }

    /**
     * Get the value of order if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of order if set, otherwise the value of default passed in
     */
    uint32_t getOrder(uint32_t defaultValue)
    {
        return getOrder().get_value_or(defaultValue);
    }

    /**
     * Set order to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::AttributeMappingRule& setOrder(uint32_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(786434ul, newValue);
        return *this;
    }

    /**
     * Unset order in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbpe::AttributeMappingRule& unsetOrder()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(786434ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Retrieve an instance of AttributeMappingRule from the managed
     * object store.  If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbpe::AttributeMappingRule> > resolve(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::gbpe::AttributeMappingRule>(framework, CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of AttributeMappingRule from the managed
     * object store using the default framework instance.  If the 
     * object does not exist in the local store, returns boost::none. 
     * Note that even though it may not exist locally, it may still 
     * exist remotely.
     * 
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbpe::AttributeMappingRule> > resolve(
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::gbpe::AttributeMappingRule>(opflex::ofcore::OFFramework::defaultInstance(), CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of AttributeMappingRule from the managed
     * object store by constructing its URI from the path elements
     * that lead to it.  If the object does not exist in the local
     * store, returns boost::none.  Note that even though it may not
     * exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/GbpeEpgMapping/[gbpeEpgMappingName]/GbpeAttributeMappingRule/[gbpeAttributeMappingRuleName]
     * 
     * @param framework the framework instance to use 
     * @param gbpeEpgMappingName the value of gbpeEpgMappingName,
     * a naming property for EpgMapping
     * @param gbpeAttributeMappingRuleName the value of gbpeAttributeMappingRuleName,
     * a naming property for AttributeMappingRule
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbpe::AttributeMappingRule> > resolve(
        opflex::ofcore::OFFramework& framework,
        const std::string& gbpeEpgMappingName,
        const std::string& gbpeAttributeMappingRuleName)
    {
        return resolve(framework,opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("GbpeEpgMapping").addElement(gbpeEpgMappingName).addElement("GbpeAttributeMappingRule").addElement(gbpeAttributeMappingRuleName).build());
    }

    /**
     * Retrieve an instance of AttributeMappingRule from the 
     * default managed object store by constructing its URI from the
     * path elements that lead to it.  If the object does not exist in
     * the local store, returns boost::none.  Note that even though it
     * may not exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/GbpeEpgMapping/[gbpeEpgMappingName]/GbpeAttributeMappingRule/[gbpeAttributeMappingRuleName]
     * 
     * @param gbpeEpgMappingName the value of gbpeEpgMappingName,
     * a naming property for EpgMapping
     * @param gbpeAttributeMappingRuleName the value of gbpeAttributeMappingRuleName,
     * a naming property for AttributeMappingRule
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbpe::AttributeMappingRule> > resolve(
        const std::string& gbpeEpgMappingName,
        const std::string& gbpeAttributeMappingRuleName)
    {
        return resolve(opflex::ofcore::OFFramework::defaultInstance(),gbpeEpgMappingName,gbpeAttributeMappingRuleName);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::gbpe::MappingRuleToGroupRSrc> > resolveGbpeMappingRuleToGroupRSrc(
        )
    {
        return modelgbp::gbpe::MappingRuleToGroupRSrc::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("GbpeMappingRuleToGroupRSrc").build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::gbpe::MappingRuleToGroupRSrc> addGbpeMappingRuleToGroupRSrc(
        )
    {
        boost::shared_ptr<modelgbp::gbpe::MappingRuleToGroupRSrc> result = addChild<modelgbp::gbpe::MappingRuleToGroupRSrc>(
            CLASS_ID, getURI(), 2148270101ul, 21,
            opflex::modb::URIBuilder(getURI()).addElement("GbpeMappingRuleToGroupRSrc").build()
            );
        return result;
    }

    /**
     * Remove this instance using the currently-active mutator.  If
     * the object does not exist, then this will be a no-op.  If this
     * object has any children, they will be garbage-collected at some
     * future time.
     * 
     * @throws std::logic_error if no mutator is active
     */
    void remove()
    {
        getTLMutator().remove(CLASS_ID, getURI());
    }

    /**
     * Remove the AttributeMappingRule object with the specified URI
     * using the currently-active mutator.  If the object does not exist,
     * then this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(opflex::ofcore::OFFramework& framework,
                       const opflex::modb::URI& uri)
    {
        MO::remove(framework, CLASS_ID, uri);
    }

    /**
     * Remove the AttributeMappingRule object with the specified URI 
     * using the currently-active mutator and the default framework 
     * instance.  If the object does not exist, then this will be a
     * no-op.  If this object has any children, they will be 
     * garbage-collected at some future time.
     * 
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(const opflex::modb::URI& uri)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(), uri);
    }

    /**
     * Remove the AttributeMappingRule object with the specified path
     * elements from the managed object store.  If the object does
     * not exist, then this will be a no-op.  If this object has any
     * children, they will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/GbpeEpgMapping/[gbpeEpgMappingName]/GbpeAttributeMappingRule/[gbpeAttributeMappingRuleName]
     * 
     * @param framework the framework instance to use
     * @param gbpeEpgMappingName the value of gbpeEpgMappingName,
     * a naming property for EpgMapping
     * @param gbpeAttributeMappingRuleName the value of gbpeAttributeMappingRuleName,
     * a naming property for AttributeMappingRule
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        opflex::ofcore::OFFramework& framework,
        const std::string& gbpeEpgMappingName,
        const std::string& gbpeAttributeMappingRuleName)
    {
        MO::remove(framework, CLASS_ID, opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("GbpeEpgMapping").addElement(gbpeEpgMappingName).addElement("GbpeAttributeMappingRule").addElement(gbpeAttributeMappingRuleName).build());
    }

    /**
     * Remove the AttributeMappingRule object with the specified path
     * elements from the managed object store using the default
     * framework instance.  If the object does not exist, then
     * this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/GbpeEpgMapping/[gbpeEpgMappingName]/GbpeAttributeMappingRule/[gbpeAttributeMappingRuleName]
     * 
     * @param gbpeEpgMappingName the value of gbpeEpgMappingName,
     * a naming property for EpgMapping
     * @param gbpeAttributeMappingRuleName the value of gbpeAttributeMappingRuleName,
     * a naming property for AttributeMappingRule
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        const std::string& gbpeEpgMappingName,
        const std::string& gbpeAttributeMappingRuleName)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(),gbpeEpgMappingName,gbpeAttributeMappingRuleName);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class.  This listener will be called for any modifications
     * of this class or any transitive children of this class.
     * 
     * @param framework the framework instance 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::registerListener(framework, listener, CLASS_ID);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class with the default framework instance.  This listener
     * will be called for any modifications of this class or any
     * transitive children of this class.
     * 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::modb::ObjectListener* listener)
    {
        registerListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Unregister a listener from updates to this class.
     * 
     * @param framework the framework instance 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::unregisterListener(framework, listener, CLASS_ID);
    }

    /**
     * Unregister a listener from updates to this class from the
     * default framework instance
     * 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::modb::ObjectListener* listener)
    {
        unregisterListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Construct an instance of AttributeMappingRule.
     * This should not typically be called from user code.
     */
    AttributeMappingRule(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri,
        const boost::shared_ptr<const opflex::modb::mointernal::ObjectInstance>& oi)
        : MO(framework, CLASS_ID, uri, oi) { }
}; // class AttributeMappingRule

} // namespace gbpe
} // namespace modelgbp
#endif // GI_GBPE_ATTRIBUTEMAPPINGRULE_HPP
