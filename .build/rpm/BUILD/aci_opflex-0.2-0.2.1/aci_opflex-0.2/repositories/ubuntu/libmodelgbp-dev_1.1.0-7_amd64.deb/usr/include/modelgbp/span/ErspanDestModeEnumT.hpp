/**
 * 
 * SOME COPYRIGHT
 * 
 * ErspanDestModeEnumT.hpp
 * 
 * generated ErspanDestModeEnumT.hpp file genie code generation framework free of license.
 *  
 */
#include <boost/cstdint.hpp>
#include <cstddef>
namespace modelgbp {
namespace span {
    struct ErspanDestModeEnumT {
        static const uint8_t CONST_NOTVISIBLE = 2;
        static const uint8_t CONST_VISIBLE = 1;
    };
}
}
