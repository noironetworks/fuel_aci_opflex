/**
 * 
 * SOME COPYRIGHT
 * 
 * AddressFamilyEnumT.hpp
 * 
 * generated AddressFamilyEnumT.hpp file genie code generation framework free of license.
 *  
 */
#include <boost/cstdint.hpp>
#include <cstddef>
namespace modelgbp {
namespace dci {
    struct AddressFamilyEnumT {
        static const uint8_t CONST_IPV4 = 4;
        static const uint8_t CONST_IPV6 = 6;
        static const uint8_t CONST_L2VPN_EVPN = 0;
    };
}
}
