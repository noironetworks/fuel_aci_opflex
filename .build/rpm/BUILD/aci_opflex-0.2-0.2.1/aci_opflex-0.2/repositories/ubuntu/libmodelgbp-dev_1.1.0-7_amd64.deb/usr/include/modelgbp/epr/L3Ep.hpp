/**
 * 
 * SOME COPYRIGHT
 * 
 * L3Ep.hpp
 * 
 * generated L3Ep.hpp file genie code generation framework free of license.
 *  
 */
#pragma once
#ifndef GI_EPR_L3EP_HPP
#define GI_EPR_L3EP_HPP

#include <boost/optional.hpp>
#include "opflex/modb/URIBuilder.h"
#include "opflex/modb/mo-internal/MO.h"
/*
 * contains: item:mclass(span/LocalEpFromEpRTgt)
 */
#include "modelgbp/span/LocalEpFromEpRTgt.hpp"

namespace modelgbp {
namespace epr {

class L3Ep
    : public opflex::modb::mointernal::MO
{
public:

    /**
     * The unique class ID for L3Ep
     */
    static const opflex::modb::class_id_t CLASS_ID = 82;

    /**
     * Check whether context has been set
     * @return true if context has been set
     */
    bool isContextSet()
    {
        return getObjectInstance().isSet(2686981ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of context if it has been set.
     * @return the value of context or boost::none if not set
     */
    boost::optional<const std::string&> getContext()
    {
        if (isContextSet())
            return getObjectInstance().getString(2686981ul);
        return boost::none;
    }

    /**
     * Get the value of context if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of context if set, otherwise the value of default passed in
     */
    const std::string& getContext(const std::string& defaultValue)
    {
        return getContext().get_value_or(defaultValue);
    }

    /**
     * Set context to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::epr::L3Ep& setContext(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(2686981ul, newValue);
        return *this;
    }

    /**
     * Unset context in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::epr::L3Ep& unsetContext()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(2686981ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether group has been set
     * @return true if group has been set
     */
    bool isGroupSet()
    {
        return getObjectInstance().isSet(2686979ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of group if it has been set.
     * @return the value of group or boost::none if not set
     */
    boost::optional<const std::string&> getGroup()
    {
        if (isGroupSet())
            return getObjectInstance().getString(2686979ul);
        return boost::none;
    }

    /**
     * Get the value of group if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of group if set, otherwise the value of default passed in
     */
    const std::string& getGroup(const std::string& defaultValue)
    {
        return getGroup().get_value_or(defaultValue);
    }

    /**
     * Set group to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::epr::L3Ep& setGroup(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(2686979ul, newValue);
        return *this;
    }

    /**
     * Unset group in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::epr::L3Ep& unsetGroup()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(2686979ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether ip has been set
     * @return true if ip has been set
     */
    bool isIpSet()
    {
        return getObjectInstance().isSet(2686980ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of ip if it has been set.
     * @return the value of ip or boost::none if not set
     */
    boost::optional<const std::string&> getIp()
    {
        if (isIpSet())
            return getObjectInstance().getString(2686980ul);
        return boost::none;
    }

    /**
     * Get the value of ip if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of ip if set, otherwise the value of default passed in
     */
    const std::string& getIp(const std::string& defaultValue)
    {
        return getIp().get_value_or(defaultValue);
    }

    /**
     * Set ip to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::epr::L3Ep& setIp(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(2686980ul, newValue);
        return *this;
    }

    /**
     * Unset ip in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::epr::L3Ep& unsetIp()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(2686980ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether mac has been set
     * @return true if mac has been set
     */
    bool isMacSet()
    {
        return getObjectInstance().isSet(2686978ul, opflex::modb::PropertyInfo::MAC);
    }

    /**
     * Get the value of mac if it has been set.
     * @return the value of mac or boost::none if not set
     */
    boost::optional<const opflex::modb::MAC&> getMac()
    {
        if (isMacSet())
            return getObjectInstance().getMAC(2686978ul);
        return boost::none;
    }

    /**
     * Get the value of mac if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of mac if set, otherwise the value of default passed in
     */
    const opflex::modb::MAC& getMac(const opflex::modb::MAC& defaultValue)
    {
        return getMac().get_value_or(defaultValue);
    }

    /**
     * Set mac to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::epr::L3Ep& setMac(const opflex::modb::MAC& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setMAC(2686978ul, newValue);
        return *this;
    }

    /**
     * Unset mac in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::epr::L3Ep& unsetMac()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(2686978ul, opflex::modb::PropertyInfo::MAC, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether uuid has been set
     * @return true if uuid has been set
     */
    bool isUuidSet()
    {
        return getObjectInstance().isSet(2686977ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of uuid if it has been set.
     * @return the value of uuid or boost::none if not set
     */
    boost::optional<const std::string&> getUuid()
    {
        if (isUuidSet())
            return getObjectInstance().getString(2686977ul);
        return boost::none;
    }

    /**
     * Get the value of uuid if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of uuid if set, otherwise the value of default passed in
     */
    const std::string& getUuid(const std::string& defaultValue)
    {
        return getUuid().get_value_or(defaultValue);
    }

    /**
     * Set uuid to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::epr::L3Ep& setUuid(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(2686977ul, newValue);
        return *this;
    }

    /**
     * Unset uuid in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::epr::L3Ep& unsetUuid()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(2686977ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Retrieve an instance of L3Ep from the managed
     * object store.  If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::epr::L3Ep> > resolve(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::epr::L3Ep>(framework, CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of L3Ep from the managed
     * object store using the default framework instance.  If the 
     * object does not exist in the local store, returns boost::none. 
     * Note that even though it may not exist locally, it may still 
     * exist remotely.
     * 
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::epr::L3Ep> > resolve(
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::epr::L3Ep>(opflex::ofcore::OFFramework::defaultInstance(), CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of L3Ep from the managed
     * object store by constructing its URI from the path elements
     * that lead to it.  If the object does not exist in the local
     * store, returns boost::none.  Note that even though it may not
     * exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /EprL3Universe/EprL3Ep/[eprL3EpContext]/[eprL3EpIp]
     * 
     * @param framework the framework instance to use 
     * @param eprL3EpContext the value of eprL3EpContext,
     * a naming property for L3Ep
     * @param eprL3EpIp the value of eprL3EpIp,
     * a naming property for L3Ep
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::epr::L3Ep> > resolve(
        opflex::ofcore::OFFramework& framework,
        const std::string& eprL3EpContext,
        const std::string& eprL3EpIp)
    {
        return resolve(framework,opflex::modb::URIBuilder().addElement("EprL3Universe").addElement("EprL3Ep").addElement(eprL3EpContext).addElement(eprL3EpIp).build());
    }

    /**
     * Retrieve an instance of L3Ep from the 
     * default managed object store by constructing its URI from the
     * path elements that lead to it.  If the object does not exist in
     * the local store, returns boost::none.  Note that even though it
     * may not exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /EprL3Universe/EprL3Ep/[eprL3EpContext]/[eprL3EpIp]
     * 
     * @param eprL3EpContext the value of eprL3EpContext,
     * a naming property for L3Ep
     * @param eprL3EpIp the value of eprL3EpIp,
     * a naming property for L3Ep
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::epr::L3Ep> > resolve(
        const std::string& eprL3EpContext,
        const std::string& eprL3EpIp)
    {
        return resolve(opflex::ofcore::OFFramework::defaultInstance(),eprL3EpContext,eprL3EpIp);
    }

    /**
     * Retrieve the child object with the specified naming
     * properties. If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param spanLocalEpFromEpRTgtSource the value of spanLocalEpFromEpRTgtSource,
     * a naming property for LocalEpFromEpRTgt
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    boost::optional<boost::shared_ptr<modelgbp::span::LocalEpFromEpRTgt> > resolveSpanLocalEpFromEpRTgt(
        const std::string& spanLocalEpFromEpRTgtSource)
    {
        return modelgbp::span::LocalEpFromEpRTgt::resolve(getFramework(), opflex::modb::URIBuilder(getURI()).addElement("SpanLocalEpFromEpRTgt").addElement(spanLocalEpFromEpRTgtSource).build());
    }

    /**
     * Create a new child object with the specified naming properties
     * and make it a child of this object in the currently-active
     * mutator.  If the object already exists in the store, get a
     * mutable copy of that object.  If the object already exists in
     * the mutator, get a reference to the object.
     * 
     * @param spanLocalEpFromEpRTgtSource the value of spanLocalEpFromEpRTgtSource,
     * a naming property for LocalEpFromEpRTgt
     * @throws std::logic_error if no mutator is active
     * @return a shared pointer to the (possibly new) object
     */
    boost::shared_ptr<modelgbp::span::LocalEpFromEpRTgt> addSpanLocalEpFromEpRTgt(
        const std::string& spanLocalEpFromEpRTgtSource)
    {
        boost::shared_ptr<modelgbp::span::LocalEpFromEpRTgt> result = addChild<modelgbp::span::LocalEpFromEpRTgt>(
            CLASS_ID, getURI(), 2150170677ul, 53,
            opflex::modb::URIBuilder(getURI()).addElement("SpanLocalEpFromEpRTgt").addElement(spanLocalEpFromEpRTgtSource).build()
            );
        result->setSource(spanLocalEpFromEpRTgtSource);
        return result;
    }

    /**
     * Resolve and retrieve all of the immediate children of type
     * modelgbp::span::LocalEpFromEpRTgt
     * 
     * Note that this retrieves only those children that exist in the
     * local store.  It is possible that there are other children that
     * exist remotely.
     * 
     * The resulting managed objects will be added to the result
     * vector provided.
     * 
     * @param out a reference to a vector that will receive the child
     * objects.
     */
    void resolveSpanLocalEpFromEpRTgt(/* out */ std::vector<boost::shared_ptr<modelgbp::span::LocalEpFromEpRTgt> >& out)
    {
        opflex::modb::mointernal::MO::resolveChildren<modelgbp::span::LocalEpFromEpRTgt>(
            getFramework(), CLASS_ID, getURI(), 2150170677ul, 53, out);
    }

    /**
     * Remove this instance using the currently-active mutator.  If
     * the object does not exist, then this will be a no-op.  If this
     * object has any children, they will be garbage-collected at some
     * future time.
     * 
     * @throws std::logic_error if no mutator is active
     */
    void remove()
    {
        getTLMutator().remove(CLASS_ID, getURI());
    }

    /**
     * Remove the L3Ep object with the specified URI
     * using the currently-active mutator.  If the object does not exist,
     * then this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(opflex::ofcore::OFFramework& framework,
                       const opflex::modb::URI& uri)
    {
        MO::remove(framework, CLASS_ID, uri);
    }

    /**
     * Remove the L3Ep object with the specified URI 
     * using the currently-active mutator and the default framework 
     * instance.  If the object does not exist, then this will be a
     * no-op.  If this object has any children, they will be 
     * garbage-collected at some future time.
     * 
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(const opflex::modb::URI& uri)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(), uri);
    }

    /**
     * Remove the L3Ep object with the specified path
     * elements from the managed object store.  If the object does
     * not exist, then this will be a no-op.  If this object has any
     * children, they will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /EprL3Universe/EprL3Ep/[eprL3EpContext]/[eprL3EpIp]
     * 
     * @param framework the framework instance to use
     * @param eprL3EpContext the value of eprL3EpContext,
     * a naming property for L3Ep
     * @param eprL3EpIp the value of eprL3EpIp,
     * a naming property for L3Ep
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        opflex::ofcore::OFFramework& framework,
        const std::string& eprL3EpContext,
        const std::string& eprL3EpIp)
    {
        MO::remove(framework, CLASS_ID, opflex::modb::URIBuilder().addElement("EprL3Universe").addElement("EprL3Ep").addElement(eprL3EpContext).addElement(eprL3EpIp).build());
    }

    /**
     * Remove the L3Ep object with the specified path
     * elements from the managed object store using the default
     * framework instance.  If the object does not exist, then
     * this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /EprL3Universe/EprL3Ep/[eprL3EpContext]/[eprL3EpIp]
     * 
     * @param eprL3EpContext the value of eprL3EpContext,
     * a naming property for L3Ep
     * @param eprL3EpIp the value of eprL3EpIp,
     * a naming property for L3Ep
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        const std::string& eprL3EpContext,
        const std::string& eprL3EpIp)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(),eprL3EpContext,eprL3EpIp);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class.  This listener will be called for any modifications
     * of this class or any transitive children of this class.
     * 
     * @param framework the framework instance 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::registerListener(framework, listener, CLASS_ID);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class with the default framework instance.  This listener
     * will be called for any modifications of this class or any
     * transitive children of this class.
     * 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::modb::ObjectListener* listener)
    {
        registerListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Unregister a listener from updates to this class.
     * 
     * @param framework the framework instance 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::unregisterListener(framework, listener, CLASS_ID);
    }

    /**
     * Unregister a listener from updates to this class from the
     * default framework instance
     * 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::modb::ObjectListener* listener)
    {
        unregisterListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Construct an instance of L3Ep.
     * This should not typically be called from user code.
     */
    L3Ep(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri,
        const boost::shared_ptr<const opflex::modb::mointernal::ObjectInstance>& oi)
        : MO(framework, CLASS_ID, uri, oi) { }
}; // class L3Ep

} // namespace epr
} // namespace modelgbp
#endif // GI_EPR_L3EP_HPP
