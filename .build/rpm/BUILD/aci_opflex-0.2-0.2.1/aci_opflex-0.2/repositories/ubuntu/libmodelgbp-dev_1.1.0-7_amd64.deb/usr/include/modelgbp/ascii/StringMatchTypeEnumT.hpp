/**
 * 
 * SOME COPYRIGHT
 * 
 * StringMatchTypeEnumT.hpp
 * 
 * generated StringMatchTypeEnumT.hpp file genie code generation framework free of license.
 *  
 */
#include <boost/cstdint.hpp>
#include <cstddef>
namespace modelgbp {
namespace ascii {
    struct StringMatchTypeEnumT {
        static const uint8_t CONST_CONTAINS = 1;
        static const uint8_t CONST_ENDSWITH = 3;
        static const uint8_t CONST_EQUALS = 0;
        static const uint8_t CONST_STARTSWITH = 2;
    };
}
}
