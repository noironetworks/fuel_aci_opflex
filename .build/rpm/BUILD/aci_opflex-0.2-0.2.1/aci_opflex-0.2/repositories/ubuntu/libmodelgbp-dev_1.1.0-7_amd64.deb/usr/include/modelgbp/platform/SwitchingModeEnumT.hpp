/**
 * 
 * SOME COPYRIGHT
 * 
 * SwitchingModeEnumT.hpp
 * 
 * generated SwitchingModeEnumT.hpp file genie code generation framework free of license.
 *  
 */
#include <boost/cstdint.hpp>
#include <cstddef>
namespace modelgbp {
namespace platform {
    struct SwitchingModeEnumT {
        static const uint8_t CONST_HAIRPIN = 1;
        static const uint8_t CONST_INTRA_BD = 3;
        static const uint8_t CONST_INTRA_EPG = 2;
        static const uint8_t CONST_INTRA_RD = 4;
    };
}
}
