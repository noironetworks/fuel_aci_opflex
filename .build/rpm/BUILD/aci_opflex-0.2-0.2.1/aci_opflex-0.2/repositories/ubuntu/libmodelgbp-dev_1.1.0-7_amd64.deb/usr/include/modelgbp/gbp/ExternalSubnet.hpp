/**
 * 
 * SOME COPYRIGHT
 * 
 * ExternalSubnet.hpp
 * 
 * generated ExternalSubnet.hpp file genie code generation framework free of license.
 *  
 */
#pragma once
#ifndef GI_GBP_EXTERNALSUBNET_HPP
#define GI_GBP_EXTERNALSUBNET_HPP

#include <boost/optional.hpp>
#include "opflex/modb/URIBuilder.h"
#include "opflex/modb/mo-internal/MO.h"

namespace modelgbp {
namespace gbp {

class ExternalSubnet
    : public opflex::modb::mointernal::MO
{
public:

    /**
     * The unique class ID for ExternalSubnet
     */
    static const opflex::modb::class_id_t CLASS_ID = 130;

    /**
     * Check whether address has been set
     * @return true if address has been set
     */
    bool isAddressSet()
    {
        return getObjectInstance().isSet(4259842ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of address if it has been set.
     * @return the value of address or boost::none if not set
     */
    boost::optional<const std::string&> getAddress()
    {
        if (isAddressSet())
            return getObjectInstance().getString(4259842ul);
        return boost::none;
    }

    /**
     * Get the value of address if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of address if set, otherwise the value of default passed in
     */
    const std::string& getAddress(const std::string& defaultValue)
    {
        return getAddress().get_value_or(defaultValue);
    }

    /**
     * Set address to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::ExternalSubnet& setAddress(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(4259842ul, newValue);
        return *this;
    }

    /**
     * Unset address in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::ExternalSubnet& unsetAddress()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(4259842ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether name has been set
     * @return true if name has been set
     */
    bool isNameSet()
    {
        return getObjectInstance().isSet(4259841ul, opflex::modb::PropertyInfo::STRING);
    }

    /**
     * Get the value of name if it has been set.
     * @return the value of name or boost::none if not set
     */
    boost::optional<const std::string&> getName()
    {
        if (isNameSet())
            return getObjectInstance().getString(4259841ul);
        return boost::none;
    }

    /**
     * Get the value of name if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of name if set, otherwise the value of default passed in
     */
    const std::string& getName(const std::string& defaultValue)
    {
        return getName().get_value_or(defaultValue);
    }

    /**
     * Set name to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::ExternalSubnet& setName(const std::string& newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setString(4259841ul, newValue);
        return *this;
    }

    /**
     * Unset name in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::ExternalSubnet& unsetName()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(4259841ul, opflex::modb::PropertyInfo::STRING, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Check whether prefixLen has been set
     * @return true if prefixLen has been set
     */
    bool isPrefixLenSet()
    {
        return getObjectInstance().isSet(4259843ul, opflex::modb::PropertyInfo::U64);
    }

    /**
     * Get the value of prefixLen if it has been set.
     * @return the value of prefixLen or boost::none if not set
     */
    boost::optional<const uint8_t> getPrefixLen()
    {
        if (isPrefixLenSet())
            return (const uint8_t)getObjectInstance().getUInt64(4259843ul);
        return boost::none;
    }

    /**
     * Get the value of prefixLen if set, otherwise the value of default passed in.
     * @param defaultValue default value returned if the property is not set
     * @return the value of prefixLen if set, otherwise the value of default passed in
     */
    const uint8_t getPrefixLen(const uint8_t defaultValue)
    {
        return getPrefixLen().get_value_or(defaultValue);
    }

    /**
     * Set prefixLen to the specified value in the currently-active mutator.
     * 
     * @param newValue the new value to set.
     * @return a reference to the current object
     * @throws std::logic_error if no mutator is active
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::ExternalSubnet& setPrefixLen(const uint8_t newValue)
    {
        getTLMutator().modify(getClassId(), getURI())->setUInt64(4259843ul, newValue);
        return *this;
    }

    /**
     * Unset prefixLen in the currently-active mutator.
     * @throws std::logic_error if no mutator is active
     * @return a reference to the current object
     * @see opflex::modb::Mutator
     */
    modelgbp::gbp::ExternalSubnet& unsetPrefixLen()
    {
        getTLMutator().modify(getClassId(), getURI())->unset(4259843ul, opflex::modb::PropertyInfo::U64, opflex::modb::PropertyInfo::SCALAR);
        return *this;
    }

    /**
     * Retrieve an instance of ExternalSubnet from the managed
     * object store.  If the object does not exist in the local store,
     * returns boost::none.  Note that even though it may not exist
     * locally, it may still exist remotely.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::ExternalSubnet> > resolve(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::gbp::ExternalSubnet>(framework, CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of ExternalSubnet from the managed
     * object store using the default framework instance.  If the 
     * object does not exist in the local store, returns boost::none. 
     * Note that even though it may not exist locally, it may still 
     * exist remotely.
     * 
     * @param uri the URI of the object to retrieve
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::ExternalSubnet> > resolve(
        const opflex::modb::URI& uri)
    {
        return opflex::modb::mointernal::MO::resolve<modelgbp::gbp::ExternalSubnet>(opflex::ofcore::OFFramework::defaultInstance(), CLASS_ID, uri);
    }

    /**
     * Retrieve an instance of ExternalSubnet from the managed
     * object store by constructing its URI from the path elements
     * that lead to it.  If the object does not exist in the local
     * store, returns boost::none.  Note that even though it may not
     * exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpRoutingDomain/[gbpRoutingDomainName]/GbpL3ExternalDomain/[gbpL3ExternalDomainName]/GbpL3ExternalNetwork/[gbpL3ExternalNetworkName]/GbpExternalSubnet/[gbpExternalSubnetName]
     * 
     * @param framework the framework instance to use 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpRoutingDomainName the value of gbpRoutingDomainName,
     * a naming property for RoutingDomain
     * @param gbpL3ExternalDomainName the value of gbpL3ExternalDomainName,
     * a naming property for L3ExternalDomain
     * @param gbpL3ExternalNetworkName the value of gbpL3ExternalNetworkName,
     * a naming property for L3ExternalNetwork
     * @param gbpExternalSubnetName the value of gbpExternalSubnetName,
     * a naming property for ExternalSubnet
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::ExternalSubnet> > resolve(
        opflex::ofcore::OFFramework& framework,
        const std::string& policySpaceName,
        const std::string& gbpRoutingDomainName,
        const std::string& gbpL3ExternalDomainName,
        const std::string& gbpL3ExternalNetworkName,
        const std::string& gbpExternalSubnetName)
    {
        return resolve(framework,opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PolicySpace").addElement(policySpaceName).addElement("GbpRoutingDomain").addElement(gbpRoutingDomainName).addElement("GbpL3ExternalDomain").addElement(gbpL3ExternalDomainName).addElement("GbpL3ExternalNetwork").addElement(gbpL3ExternalNetworkName).addElement("GbpExternalSubnet").addElement(gbpExternalSubnetName).build());
    }

    /**
     * Retrieve an instance of ExternalSubnet from the 
     * default managed object store by constructing its URI from the
     * path elements that lead to it.  If the object does not exist in
     * the local store, returns boost::none.  Note that even though it
     * may not exist locally, it may still exist remotely.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpRoutingDomain/[gbpRoutingDomainName]/GbpL3ExternalDomain/[gbpL3ExternalDomainName]/GbpL3ExternalNetwork/[gbpL3ExternalNetworkName]/GbpExternalSubnet/[gbpExternalSubnetName]
     * 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpRoutingDomainName the value of gbpRoutingDomainName,
     * a naming property for RoutingDomain
     * @param gbpL3ExternalDomainName the value of gbpL3ExternalDomainName,
     * a naming property for L3ExternalDomain
     * @param gbpL3ExternalNetworkName the value of gbpL3ExternalNetworkName,
     * a naming property for L3ExternalNetwork
     * @param gbpExternalSubnetName the value of gbpExternalSubnetName,
     * a naming property for ExternalSubnet
     * @return a shared pointer to the object or boost::none if it
     * does not exist.
     */
    static boost::optional<boost::shared_ptr<modelgbp::gbp::ExternalSubnet> > resolve(
        const std::string& policySpaceName,
        const std::string& gbpRoutingDomainName,
        const std::string& gbpL3ExternalDomainName,
        const std::string& gbpL3ExternalNetworkName,
        const std::string& gbpExternalSubnetName)
    {
        return resolve(opflex::ofcore::OFFramework::defaultInstance(),policySpaceName,gbpRoutingDomainName,gbpL3ExternalDomainName,gbpL3ExternalNetworkName,gbpExternalSubnetName);
    }

    /**
     * Remove this instance using the currently-active mutator.  If
     * the object does not exist, then this will be a no-op.  If this
     * object has any children, they will be garbage-collected at some
     * future time.
     * 
     * @throws std::logic_error if no mutator is active
     */
    void remove()
    {
        getTLMutator().remove(CLASS_ID, getURI());
    }

    /**
     * Remove the ExternalSubnet object with the specified URI
     * using the currently-active mutator.  If the object does not exist,
     * then this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * @param framework the framework instance to use
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(opflex::ofcore::OFFramework& framework,
                       const opflex::modb::URI& uri)
    {
        MO::remove(framework, CLASS_ID, uri);
    }

    /**
     * Remove the ExternalSubnet object with the specified URI 
     * using the currently-active mutator and the default framework 
     * instance.  If the object does not exist, then this will be a
     * no-op.  If this object has any children, they will be 
     * garbage-collected at some future time.
     * 
     * @param uri the URI of the object to remove
     * @throws std::logic_error if no mutator is active
     */
    static void remove(const opflex::modb::URI& uri)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(), uri);
    }

    /**
     * Remove the ExternalSubnet object with the specified path
     * elements from the managed object store.  If the object does
     * not exist, then this will be a no-op.  If this object has any
     * children, they will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpRoutingDomain/[gbpRoutingDomainName]/GbpL3ExternalDomain/[gbpL3ExternalDomainName]/GbpL3ExternalNetwork/[gbpL3ExternalNetworkName]/GbpExternalSubnet/[gbpExternalSubnetName]
     * 
     * @param framework the framework instance to use
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpRoutingDomainName the value of gbpRoutingDomainName,
     * a naming property for RoutingDomain
     * @param gbpL3ExternalDomainName the value of gbpL3ExternalDomainName,
     * a naming property for L3ExternalDomain
     * @param gbpL3ExternalNetworkName the value of gbpL3ExternalNetworkName,
     * a naming property for L3ExternalNetwork
     * @param gbpExternalSubnetName the value of gbpExternalSubnetName,
     * a naming property for ExternalSubnet
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        opflex::ofcore::OFFramework& framework,
        const std::string& policySpaceName,
        const std::string& gbpRoutingDomainName,
        const std::string& gbpL3ExternalDomainName,
        const std::string& gbpL3ExternalNetworkName,
        const std::string& gbpExternalSubnetName)
    {
        MO::remove(framework, CLASS_ID, opflex::modb::URIBuilder().addElement("PolicyUniverse").addElement("PolicySpace").addElement(policySpaceName).addElement("GbpRoutingDomain").addElement(gbpRoutingDomainName).addElement("GbpL3ExternalDomain").addElement(gbpL3ExternalDomainName).addElement("GbpL3ExternalNetwork").addElement(gbpL3ExternalNetworkName).addElement("GbpExternalSubnet").addElement(gbpExternalSubnetName).build());
    }

    /**
     * Remove the ExternalSubnet object with the specified path
     * elements from the managed object store using the default
     * framework instance.  If the object does not exist, then
     * this will be a no-op.  If this object has any children, they
     * will be garbage-collected at some future time.
     * 
     * The object URI generated by this function will take the form:
     * /PolicyUniverse/PolicySpace/[policySpaceName]/GbpRoutingDomain/[gbpRoutingDomainName]/GbpL3ExternalDomain/[gbpL3ExternalDomainName]/GbpL3ExternalNetwork/[gbpL3ExternalNetworkName]/GbpExternalSubnet/[gbpExternalSubnetName]
     * 
     * @param policySpaceName the value of policySpaceName,
     * a naming property for Space
     * @param gbpRoutingDomainName the value of gbpRoutingDomainName,
     * a naming property for RoutingDomain
     * @param gbpL3ExternalDomainName the value of gbpL3ExternalDomainName,
     * a naming property for L3ExternalDomain
     * @param gbpL3ExternalNetworkName the value of gbpL3ExternalNetworkName,
     * a naming property for L3ExternalNetwork
     * @param gbpExternalSubnetName the value of gbpExternalSubnetName,
     * a naming property for ExternalSubnet
     * @throws std::logic_error if no mutator is active
     */
    static void remove(
        const std::string& policySpaceName,
        const std::string& gbpRoutingDomainName,
        const std::string& gbpL3ExternalDomainName,
        const std::string& gbpL3ExternalNetworkName,
        const std::string& gbpExternalSubnetName)
    {
        remove(opflex::ofcore::OFFramework::defaultInstance(),policySpaceName,gbpRoutingDomainName,gbpL3ExternalDomainName,gbpL3ExternalNetworkName,gbpExternalSubnetName);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class.  This listener will be called for any modifications
     * of this class or any transitive children of this class.
     * 
     * @param framework the framework instance 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::registerListener(framework, listener, CLASS_ID);
    }

    /**
     * Register a listener that will get called for changes related to
     * this class with the default framework instance.  This listener
     * will be called for any modifications of this class or any
     * transitive children of this class.
     * 
     * @param listener the listener functional object that should be
     * called when changes occur related to the class.  This memory is
     * owned by the caller and should be freed only after it has been
     * unregistered.
     */
    static void registerListener(
        opflex::modb::ObjectListener* listener)
    {
        registerListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Unregister a listener from updates to this class.
     * 
     * @param framework the framework instance 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::ofcore::OFFramework& framework,
        opflex::modb::ObjectListener* listener)
    {
        opflex::modb::mointernal
            ::MO::unregisterListener(framework, listener, CLASS_ID);
    }

    /**
     * Unregister a listener from updates to this class from the
     * default framework instance
     * 
     * @param listener The listener to unregister.
     */
    static void unregisterListener(
        opflex::modb::ObjectListener* listener)
    {
        unregisterListener(opflex::ofcore::OFFramework::defaultInstance(), listener);
    }

    /**
     * Construct an instance of ExternalSubnet.
     * This should not typically be called from user code.
     */
    ExternalSubnet(
        opflex::ofcore::OFFramework& framework,
        const opflex::modb::URI& uri,
        const boost::shared_ptr<const opflex::modb::mointernal::ObjectInstance>& oi)
        : MO(framework, CLASS_ID, uri, oi) { }
}; // class ExternalSubnet

} // namespace gbp
} // namespace modelgbp
#endif // GI_GBP_EXTERNALSUBNET_HPP
