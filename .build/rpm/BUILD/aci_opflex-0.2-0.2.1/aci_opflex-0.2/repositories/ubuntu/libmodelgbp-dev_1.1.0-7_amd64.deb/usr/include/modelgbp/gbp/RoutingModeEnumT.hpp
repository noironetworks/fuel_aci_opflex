/**
 * 
 * SOME COPYRIGHT
 * 
 * RoutingModeEnumT.hpp
 * 
 * generated RoutingModeEnumT.hpp file genie code generation framework free of license.
 *  
 */
#include <boost/cstdint.hpp>
#include <cstddef>
namespace modelgbp {
namespace gbp {
    struct RoutingModeEnumT {
        static const uint8_t CONST_DISABLED = 0;
        static const uint8_t CONST_ENABLED = 1;
    };
}
}
