/**
 * 
 * SOME COPYRIGHT
 * 
 * DirectionEnumT.hpp
 * 
 * generated DirectionEnumT.hpp file genie code generation framework free of license.
 *  
 */
#include <boost/cstdint.hpp>
#include <cstddef>
namespace modelgbp {
namespace gbp {
    struct DirectionEnumT {
        static const uint8_t CONST_BIDIRECTIONAL = 0;
        static const uint8_t CONST_IN = 1;
        static const uint8_t CONST_OUT = 2;
    };
}
}
