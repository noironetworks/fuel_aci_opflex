/**
 * 
 * SOME COPYRIGHT
 * 
 * TcpFlagsEnumT.hpp
 * 
 * generated TcpFlagsEnumT.hpp file genie code generation framework free of license.
 *  
 */
#include <boost/cstdint.hpp>
#include <cstddef>
namespace modelgbp {
namespace l4 {
    struct TcpFlagsEnumT {
        static const uint32_t CONST_ACK = 0x02;
        static const uint32_t CONST_FIN = 0x04;
        static const uint32_t CONST_RST = 0x08;
        static const uint32_t CONST_SYN = 0x01;
        static const uint32_t CONST_ESTABLISHED = 0x10;
        static const uint32_t CONST_UNSPECIFIED = 0x00;
    };
}
}
