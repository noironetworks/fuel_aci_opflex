/**
 * 
 * SOME COPYRIGHT
 * 
 * TargetTypeEnumT.hpp
 * 
 * generated TargetTypeEnumT.hpp file genie code generation framework free of license.
 *  
 */
#include <boost/cstdint.hpp>
#include <cstddef>
namespace modelgbp {
namespace dci {
    struct TargetTypeEnumT {
        static const uint8_t CONST_FABRICEXPORT = 1;
        static const uint8_t CONST_FABRICIMPORT = 0;
    };
}
}
