var modules =
[
    [ "RapidJSON configuration", "group___r_a_p_i_d_j_s_o_n___c_o_n_f_i_g.html", "group___r_a_p_i_d_j_s_o_n___c_o_n_f_i_g" ],
    [ "RapidJSON error handling", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s.html", "group___r_a_p_i_d_j_s_o_n___e_r_r_o_r_s" ]
];