var searchData=
[
  ['validate',['Validate',['../structrapidjson_1_1_transcoder.html#ae9178e512e99394a38785e73927140da',1,'rapidjson::Transcoder']]]
];
