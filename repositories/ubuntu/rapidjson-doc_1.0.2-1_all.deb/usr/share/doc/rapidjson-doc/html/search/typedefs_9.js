var searchData=
[
  ['reader',['Reader',['../namespacerapidjson.html#a4eaef42a208413d1f2c8d4655ecec52d',1,'rapidjson']]],
  ['reference',['Reference',['../classrapidjson_1_1_generic_member_iterator.html#a915a1b6f0a0bbe6a1df69571a789e348',1,'rapidjson::GenericMemberIterator']]]
];
