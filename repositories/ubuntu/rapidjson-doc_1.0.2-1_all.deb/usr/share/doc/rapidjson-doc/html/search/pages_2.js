var searchData=
[
  ['faq',['FAQ',['../md_doc_faq.html',1,'']]],
  ['features',['Features',['../md_doc_features.html',1,'']]]
];
