var searchData=
[
  ['encoding',['Encoding',['../md_doc_encoding.html',1,'']]]
];
