var searchData=
[
  ['编码',['编码',['../md_doc_encoding_8zh-cn.html',1,'']]],
  ['特点',['特点',['../md_doc_features_8zh-cn.html',1,'']]]
];
