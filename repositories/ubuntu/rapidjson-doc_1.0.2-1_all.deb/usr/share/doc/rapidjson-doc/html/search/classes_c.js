var searchData=
[
  ['transcoder',['Transcoder',['../structrapidjson_1_1_transcoder.html',1,'rapidjson']]],
  ['transcoder_3c_20encoding_2c_20encoding_20_3e',['Transcoder&lt; Encoding, Encoding &gt;',['../structrapidjson_1_1_transcoder_3_01_encoding_00_01_encoding_01_4.html',1,'rapidjson']]]
];
